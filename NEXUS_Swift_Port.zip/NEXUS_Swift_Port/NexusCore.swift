#if canImport(SwiftUI)
import Foundation
import SwiftUI
import AVFoundation
import CryptoKit
import UniformTypeIdentifiers

// MARK: - Navigation and catalog

enum NexusTab: String, CaseIterable, Identifiable, Hashable {
    case home, search, assistant, weather, timer, stopwatch, bgm, memo, translate, todo, calendar
    case network, music, calculator, drawing, news, board, codeBridge, garbler
    case security, urlChecker, privacy, backup, sleep, developer, settings, games, monitor, about

    var id: String { rawValue }
    var title: String {
        switch self {
        case .home: "ホーム"
        case .search: "検索・URL入力"
        case .assistant: "NEXUS Assistant+"
        case .weather: "天気・47都道府県"
        case .timer: "タイマー"
        case .stopwatch: "ストップウォッチ"
        case .bgm: "BGMプレイヤー"
        case .memo: "メモ・ノート"
        case .translate: "翻訳"
        case .todo: "今日のTodo"
        case .calendar: "予定表・カレンダー"
        case .network: "ネットワーク速度"
        case .music: "ミュージックプレーヤー"
        case .calculator: "電卓"
        case .drawing: "お絵かきスタジオ"
        case .news: "今日のニュース"
        case .board: "掲示板記録"
        case .codeBridge: "CodeBridge"
        case .garbler: "文字化けラボ"
        case .security: "セキュリティ診断"
        case .urlChecker: "URLチェッカー"
        case .privacy: "プライバシー設定"
        case .backup: "バックアップ・復元"
        case .sleep: "おやすみ制限"
        case .developer: "開発者モード"
        case .settings: "カスタマイズ"
        case .games: "ミニゲーム"
        case .monitor: "システムモニター"
        case .about: "利用規約・著作権"
        }
    }
    var symbol: String {
        switch self {
        case .home: "house.fill"
        case .search: "magnifyingglass"
        case .assistant: "sparkles"
        case .weather: "cloud.sun.fill"
        case .timer: "timer"
        case .stopwatch: "stopwatch"
        case .bgm: "waveform"
        case .memo: "note.text"
        case .translate: "translate"
        case .todo: "checklist"
        case .calendar: "calendar"
        case .network: "speedometer"
        case .music: "music.note.list"
        case .calculator: "calculator"
        case .drawing: "paintbrush.pointed.fill"
        case .news: "newspaper"
        case .board: "text.book.closed"
        case .codeBridge: "chevron.left.forwardslash.chevron.right"
        case .garbler: "character.textbox"
        case .security: "shield.lefthalf.filled"
        case .urlChecker: "link.badge.plus"
        case .privacy: "hand.raised.fill"
        case .backup: "externaldrive.fill.badge.clock"
        case .sleep: "moon.zzz.fill"
        case .developer: "wrench.and.screwdriver.fill"
        case .settings: "slider.horizontal.3"
        case .games: "gamecontroller.fill"
        case .monitor: "chart.bar.xaxis"
        case .about: "doc.text"
        }
    }
    var group: String {
        switch self {
        case .home, .search, .assistant: "WORKSPACE"
        case .weather, .news, .network: "LIVE INFORMATION"
        case .memo, .board, .todo, .calendar: "DAILY WORK"
        case .translate, .codeBridge, .garbler: "LANGUAGE & CODE"
        case .timer, .stopwatch, .bgm, .music, .calculator, .drawing, .games: "TOOLS"
        case .security, .urlChecker, .privacy, .backup, .sleep, .developer, .settings, .monitor, .about: "SYSTEM"
        }
    }
}

struct NexusLink: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var url: String
    var symbol: String = "arrow.up.right.square"
}

struct NexusLinkGroup: Identifiable {
    var id: String { name }
    var name: String
    var links: [NexusLink]
}

enum NexusCatalog {
    static let linkGroups: [NexusLinkGroup] = [
        .init(name: "Google", links: [
            .init(name: "Gmail", url: "https://mail.google.com", symbol: "envelope.fill"),
            .init(name: "ドキュメント", url: "https://docs.google.com/document", symbol: "doc.text"),
            .init(name: "スライド", url: "https://docs.google.com/presentation", symbol: "rectangle.on.rectangle"),
            .init(name: "スプレッドシート", url: "https://docs.google.com/spreadsheets", symbol: "tablecells"),
            .init(name: "ドライブ", url: "https://drive.google.com", symbol: "externaldrive.fill"),
            .init(name: "Colab", url: "https://colab.research.google.com", symbol: "terminal"),
            .init(name: "カレンダー", url: "https://calendar.google.com", symbol: "calendar"),
            .init(name: "マップ", url: "https://maps.google.com", symbol: "map"),
            .init(name: "フォト", url: "https://photos.google.com", symbol: "photo"),
            .init(name: "Meet", url: "https://meet.google.com", symbol: "video"),
            .init(name: "フォーム", url: "https://docs.google.com/forms", symbol: "list.clipboard"),
            .init(name: "Keep", url: "https://keep.google.com", symbol: "lightbulb"),
            .init(name: "翻訳", url: "https://translate.google.com", symbol: "translate"),
            .init(name: "Sites", url: "https://sites.google.com", symbol: "globe"),
            .init(name: "Gemini", url: "https://gemini.google.com", symbol: "sparkles"),
            .init(name: "Classroom", url: "https://classroom.google.com", symbol: "graduationcap")
        ]),
        .init(name: "Microsoft", links: [
            .init(name: "Word", url: "https://www.office.com/launch/word", symbol: "doc.richtext"),
            .init(name: "Excel", url: "https://www.office.com/launch/excel", symbol: "tablecells"),
            .init(name: "PowerPoint", url: "https://www.office.com/launch/powerpoint", symbol: "rectangle.on.rectangle"),
            .init(name: "Teams", url: "https://teams.microsoft.com", symbol: "person.3"),
            .init(name: "Outlook", url: "https://outlook.live.com", symbol: "envelope"),
            .init(name: "OneNote", url: "https://www.onenote.com", symbol: "note.text"),
            .init(name: "Clipchamp", url: "https://clipchamp.com", symbol: "film"),
            .init(name: "Copilot", url: "https://copilot.microsoft.com", symbol: "sparkles"),
            .init(name: "OneDrive", url: "https://onedrive.live.com", symbol: "cloud"),
            .init(name: "Microsoft 365", url: "https://www.microsoft365.com", symbol: "square.grid.2x2")
        ]),
        .init(name: "AI", links: [
            .init(name: "ChatGPT", url: "https://chatgpt.com", symbol: "bubble.left.and.bubble.right"),
            .init(name: "Claude", url: "https://claude.ai", symbol: "sparkles"),
            .init(name: "Perplexity", url: "https://www.perplexity.ai", symbol: "magnifyingglass"),
            .init(name: "Gemini", url: "https://gemini.google.com", symbol: "sparkles"),
            .init(name: "Grok", url: "https://grok.com", symbol: "atom"),
            .init(name: "Suno", url: "https://suno.com", symbol: "music.note"),
            .init(name: "Sora", url: "https://sora.com", symbol: "video"),
            .init(name: "Runway", url: "https://runwayml.com", symbol: "film"),
            .init(name: "Cursor", url: "https://cursor.com", symbol: "cursorarrow")
        ]),
        .init(name: "SNS・動画", links: [
            .init(name: "X", url: "https://x.com", symbol: "bubble.left"),
            .init(name: "NOTE", url: "https://note.com", symbol: "note.text"),
            .init(name: "TikTok", url: "https://www.tiktok.com", symbol: "music.note"),
            .init(name: "YouTube", url: "https://www.youtube.com", symbol: "play.rectangle.fill"),
            .init(name: "Netflix", url: "https://www.netflix.com", symbol: "tv"),
            .init(name: "Twitch", url: "https://www.twitch.tv", symbol: "gamecontroller"),
            .init(name: "Reddit", url: "https://www.reddit.com", symbol: "bubble.left.and.bubble.right"),
            .init(name: "Instagram", url: "https://www.instagram.com", symbol: "camera"),
            .init(name: "LINE", url: "https://line.me", symbol: "message"),
            .init(name: "Discord", url: "https://discord.com", symbol: "bubble.left.and.bubble.right"),
            .init(name: "Spotify", url: "https://open.spotify.com", symbol: "music.note.list")
        ]),
        .init(name: "クラウド", links: [
            .init(name: "Dropbox", url: "https://www.dropbox.com"),
            .init(name: "iCloud", url: "https://www.icloud.com"),
            .init(name: "Box", url: "https://www.box.com"),
            .init(name: "MEGA", url: "https://mega.nz"),
            .init(name: "Proton", url: "https://proton.me"),
            .init(name: "Adobe", url: "https://www.adobe.com")
        ]),
        .init(name: "開発・ゲーム", links: [
            .init(name: "GitHub", url: "https://github.com", symbol: "chevron.left.forwardslash.chevron.right"),
            .init(name: "Unity", url: "https://unity.com"),
            .init(name: "Steam", url: "https://store.steampowered.com", symbol: "gamecontroller"),
            .init(name: "Epic Games", url: "https://store.epicgames.com", symbol: "gamecontroller"),
            .init(name: "Vercel", url: "https://vercel.com"),
            .init(name: "Scratch", url: "https://scratch.mit.edu"),
            .init(name: "TurboWarp", url: "https://turbowarp.org")
        ]),
        .init(name: "ネット・Office", links: [
            .init(name: "Amazon", url: "https://www.amazon.co.jp"),
            .init(name: "楽天市場", url: "https://www.rakuten.co.jp"),
            .init(name: "Yahoo! JAPAN", url: "https://www.yahoo.co.jp"),
            .init(name: "メルカリ", url: "https://jp.mercari.com"),
            .init(name: "Wikipedia", url: "https://ja.wikipedia.org"),
            .init(name: "NHK", url: "https://www3.nhk.or.jp"),
            .init(name: "Zoom", url: "https://zoom.us"),
            .init(name: "Slack", url: "https://slack.com"),
            .init(name: "Notion", url: "https://www.notion.so"),
            .init(name: "Canva", url: "https://www.canva.com"),
            .init(name: "Figma", url: "https://www.figma.com"),
            .init(name: "Trello", url: "https://trello.com"),
            .init(name: "Pixiv", url: "https://www.pixiv.net"),
            .init(name: "Zenn", url: "https://zenn.dev"),
            .init(name: "Qiita", url: "https://qiita.com")
        ]),
        .init(name: "学習・便利", links: [
            .init(name: "Khan Academy", url: "https://ja.khanacademy.org"),
            .init(name: "NHK for School", url: "https://www.nhk.or.jp/school"),
            .init(name: "GeoGebra", url: "https://www.geogebra.org"),
            .init(name: "Desmos", url: "https://www.desmos.com"),
            .init(name: "TypingClub", url: "https://www.typingclub.com"),
            .init(name: "寿司打", url: "https://sushida.net"),
            .init(name: "e-typing", url: "https://www.e-typing.ne.jp"),
            .init(name: "DeepL", url: "https://www.deepl.com"),
            .init(name: "Internet Archive", url: "https://archive.org"),
            .init(name: "Photopea", url: "https://www.photopea.com"),
            .init(name: "Excalidraw", url: "https://excalidraw.com"),
            .init(name: "CodePen", url: "https://codepen.io")
        ])
    ]

    static let newsLinks: [NexusLink] = [
        .init(name: "NHK NEWS", url: "https://www3.nhk.or.jp/news/", symbol: "newspaper"),
        .init(name: "Yahoo!ニュース", url: "https://news.yahoo.co.jp/", symbol: "newspaper"),
        .init(name: "BBC News Japan", url: "https://www.bbc.com/japanese", symbol: "globe"),
        .init(name: "神戸新聞", url: "https://www.kobe-np.co.jp/", symbol: "newspaper"),
        .init(name: "ITmedia NEWS", url: "https://www.itmedia.co.jp/news/", symbol: "cpu")
    ]
}

// MARK: - Japanese prefectures and representative forecast coordinates

struct NexusPrefecture: Identifiable, Hashable {
    var id: String
    var name: String
    var latitude: Double
    var longitude: Double
    var representative: String
}

enum NexusPrefectures {
    static let all: [NexusPrefecture] = [
        .init(id:"hokkaido",name:"北海道",latitude:43.0642,longitude:141.3469,representative:"札幌市付近"),
        .init(id:"aomori",name:"青森県",latitude:40.8244,longitude:140.7400,representative:"青森市付近"),
        .init(id:"iwate",name:"岩手県",latitude:39.7036,longitude:141.1527,representative:"盛岡市付近"),
        .init(id:"miyagi",name:"宮城県",latitude:38.2682,longitude:140.8694,representative:"仙台市付近"),
        .init(id:"akita",name:"秋田県",latitude:39.7186,longitude:140.1024,representative:"秋田市付近"),
        .init(id:"yamagata",name:"山形県",latitude:38.2404,longitude:140.3633,representative:"山形市付近"),
        .init(id:"fukushima",name:"福島県",latitude:37.7503,longitude:140.4676,representative:"福島市付近"),
        .init(id:"ibaraki",name:"茨城県",latitude:36.3418,longitude:140.4468,representative:"水戸市付近"),
        .init(id:"tochigi",name:"栃木県",latitude:36.5657,longitude:139.8836,representative:"宇都宮市付近"),
        .init(id:"gunma",name:"群馬県",latitude:36.3907,longitude:139.0604,representative:"前橋市付近"),
        .init(id:"saitama",name:"埼玉県",latitude:35.8617,longitude:139.6455,representative:"さいたま市付近"),
        .init(id:"chiba",name:"千葉県",latitude:35.6073,longitude:140.1063,representative:"千葉市付近"),
        .init(id:"tokyo",name:"東京都",latitude:35.6895,longitude:139.6917,representative:"新宿区付近"),
        .init(id:"kanagawa",name:"神奈川県",latitude:35.4478,longitude:139.6425,representative:"横浜市付近"),
        .init(id:"niigata",name:"新潟県",latitude:37.9026,longitude:139.0236,representative:"新潟市付近"),
        .init(id:"toyama",name:"富山県",latitude:36.6953,longitude:137.2113,representative:"富山市付近"),
        .init(id:"ishikawa",name:"石川県",latitude:36.5944,longitude:136.6256,representative:"金沢市付近"),
        .init(id:"fukui",name:"福井県",latitude:36.0652,longitude:136.2216,representative:"福井市付近"),
        .init(id:"yamanashi",name:"山梨県",latitude:35.6642,longitude:138.5684,representative:"甲府市付近"),
        .init(id:"nagano",name:"長野県",latitude:36.6513,longitude:138.1810,representative:"長野市付近"),
        .init(id:"gifu",name:"岐阜県",latitude:35.3912,longitude:136.7223,representative:"岐阜市付近"),
        .init(id:"shizuoka",name:"静岡県",latitude:34.9769,longitude:138.3831,representative:"静岡市付近"),
        .init(id:"aichi",name:"愛知県",latitude:35.1802,longitude:136.9066,representative:"名古屋市付近"),
        .init(id:"mie",name:"三重県",latitude:34.7303,longitude:136.5086,representative:"津市付近"),
        .init(id:"shiga",name:"滋賀県",latitude:35.0179,longitude:135.8546,representative:"大津市付近"),
        .init(id:"kyoto",name:"京都府",latitude:35.0116,longitude:135.7681,representative:"京都市付近"),
        .init(id:"osaka",name:"大阪府",latitude:34.6863,longitude:135.5200,representative:"大阪市付近"),
        .init(id:"hyogo",name:"兵庫県",latitude:34.6913,longitude:135.1830,representative:"神戸市付近"),
        .init(id:"nara",name:"奈良県",latitude:34.6851,longitude:135.8329,representative:"奈良市付近"),
        .init(id:"wakayama",name:"和歌山県",latitude:34.2260,longitude:135.1675,representative:"和歌山市付近"),
        .init(id:"tottori",name:"鳥取県",latitude:35.5039,longitude:134.2377,representative:"鳥取市付近"),
        .init(id:"shimane",name:"島根県",latitude:35.4723,longitude:133.0505,representative:"松江市付近"),
        .init(id:"okayama",name:"岡山県",latitude:34.6618,longitude:133.9344,representative:"岡山市付近"),
        .init(id:"hiroshima",name:"広島県",latitude:34.3963,longitude:132.4596,representative:"広島市付近"),
        .init(id:"yamaguchi",name:"山口県",latitude:34.1861,longitude:131.4705,representative:"山口市付近"),
        .init(id:"tokushima",name:"徳島県",latitude:34.0658,longitude:134.5593,representative:"徳島市付近"),
        .init(id:"kagawa",name:"香川県",latitude:34.3401,longitude:134.0434,representative:"高松市付近"),
        .init(id:"ehime",name:"愛媛県",latitude:33.8416,longitude:132.7657,representative:"松山市付近"),
        .init(id:"kochi",name:"高知県",latitude:33.5597,longitude:133.5311,representative:"高知市付近"),
        .init(id:"fukuoka",name:"福岡県",latitude:33.6064,longitude:130.4183,representative:"福岡市付近"),
        .init(id:"saga",name:"佐賀県",latitude:33.2494,longitude:130.2988,representative:"佐賀市付近"),
        .init(id:"nagasaki",name:"長崎県",latitude:32.7448,longitude:129.8737,representative:"長崎市付近"),
        .init(id:"kumamoto",name:"熊本県",latitude:32.7898,longitude:130.7417,representative:"熊本市付近"),
        .init(id:"oita",name:"大分県",latitude:33.2382,longitude:131.6126,representative:"大分市付近"),
        .init(id:"miyazaki",name:"宮崎県",latitude:31.9111,longitude:131.4239,representative:"宮崎市付近"),
        .init(id:"kagoshima",name:"鹿児島県",latitude:31.5602,longitude:130.5581,representative:"鹿児島市付近"),
        .init(id:"okinawa",name:"沖縄県",latitude:26.2124,longitude:127.6809,representative:"那覇市付近")
    ]
}

// MARK: - Persistent models

struct NexusSettings: Codable {
    var isDark = true
    var accentHex = "#37D8FF"
    var wallpaper = "宇宙空間"
    var iconSize = 76.0
    var glassBlur = 12.0
    var autoWeatherNetwork = false
    var screenProtection = false
    var anonymousCommunication = false
    var blurOnBackground = false
    var sleepEnabled = false
    var sleepStart = "22:00"
    var sleepEnd = "07:00"
    var selectedPrefecture = "hyogo"
    var hiddenTabs: [String] = []
    var musicVolume = 0.7
}

struct NexusNote: Identifiable, Codable, Hashable {
    var id = UUID()
    var title: String
    var body: String
    var isPinned = false
    var updatedAt = Date()
}

struct NexusTodo: Identifiable, Codable, Hashable {
    var id = UUID()
    var text: String
    var isDone = false
    var createdAt = Date()
}

struct NexusEvent: Identifiable, Codable, Hashable {
    var id = UUID()
    var title: String
    var date: Date
    var notes: String = ""
}

struct NexusBoardEntry: Identifiable, Codable, Hashable {
    var id = UUID()
    var category: String
    var title: String
    var body: String
    var createdAt = Date()
}

struct NexusAppData: Codable {
    var version = "3.1-swift"
    var settings: NexusSettings
    var notes: [NexusNote]
    var todos: [String: [NexusTodo]]
    var events: [NexusEvent]
    var boardEntries: [NexusBoardEntry]
    var customLinks: [NexusLink]
    var drawingData: String? = nil
}

@MainActor
final class NexusStore: ObservableObject {
    @Published var selectedTab: NexusTab = .home
    @Published var settings: NexusSettings { didSet { persist(settings, key: "nexus.settings") } }
    @Published var notes: [NexusNote] { didSet { persist(notes, key: "nexus.notes") } }
    @Published var todos: [String: [NexusTodo]] { didSet { persist(todos, key: "nexus.todos") } }
    @Published var events: [NexusEvent] { didSet { persist(events, key: "nexus.events") } }
    @Published var boardEntries: [NexusBoardEntry] { didSet { persist(boardEntries, key: "nexus.board") } }
    @Published var customLinks: [NexusLink] { didSet { persist(customLinks, key: "nexus.links") } }
    @Published var alertMessage: String?
    @Published var isDeveloperEnabled = false
    @Published var isAdminEnabled = false

    private let defaults = UserDefaults.standard

    init() {
        settings = Self.read(NexusSettings.self, key: "nexus.settings") ?? NexusSettings()
        notes = Self.read([NexusNote].self, key: "nexus.notes") ?? []
        todos = Self.read([String: [NexusTodo]].self, key: "nexus.todos") ?? [:]
        events = Self.read([NexusEvent].self, key: "nexus.events") ?? []
        boardEntries = Self.read([NexusBoardEntry].self, key: "nexus.board") ?? []
        customLinks = Self.read([NexusLink].self, key: "nexus.links") ?? []
    }

    private static func read<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }
    private func persist<T: Encodable>(_ value: T, key: String) {
        guard let data = try? JSONEncoder().encode(value) else { return }
        defaults.set(data, forKey: key)
    }

    var todayKey: String { Self.dateKey(Date()) }
    static func dateKey(_ date: Date) -> String {
        let f = DateFormatter(); f.calendar = Calendar(identifier: .gregorian); f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = .current; f.dateFormat = "yyyy-MM-dd"
        return f.string(from: date)
    }
    func todos(for date: Date) -> [NexusTodo] { todos[Self.dateKey(date), default: []] }
    func addTodo(_ text: String, on date: Date) {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return }
        let key = Self.dateKey(date); todos[key, default: []].insert(NexusTodo(text: value), at: 0)
    }
    func toggleTodo(_ todo: NexusTodo, on date: Date) {
        let key = Self.dateKey(date)
        guard let index = todos[key]?.firstIndex(where: { $0.id == todo.id }) else { return }
        todos[key]?[index].isDone.toggle()
    }
    func deleteTodo(_ todo: NexusTodo, on date: Date) {
        let key = Self.dateKey(date); todos[key]?.removeAll { $0.id == todo.id }
    }
    func clearCompletedTodos(on date: Date) {
        let key = Self.dateKey(date); todos[key]?.removeAll(where: \.isDone)
    }

    func addNote(title: String, body: String, pinned: Bool = false, id: UUID? = nil) {
        let name = title.trimmingCharacters(in: .whitespacesAndNewlines)
        let text = body.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty || !text.isEmpty else { return }
        if let id, let index = notes.firstIndex(where: { $0.id == id }) {
            notes[index].title = name.isEmpty ? "無題" : name; notes[index].body = body; notes[index].updatedAt = Date(); notes[index].isPinned = pinned
        } else {
            notes.insert(NexusNote(title: name.isEmpty ? "無題" : name, body: body, isPinned: pinned), at: 0)
        }
    }
    func deleteNote(_ note: NexusNote) { notes.removeAll { $0.id == note.id } }
    func addEvent(title: String, date: Date, notes: String = "") {
        guard !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        events.append(NexusEvent(title: title, date: date, notes: notes)); events.sort { $0.date < $1.date }
    }
    func deleteEvent(_ event: NexusEvent) { events.removeAll { $0.id == event.id } }
    func addBoardEntry(category: String, title: String, body: String) {
        guard !body.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        boardEntries.insert(NexusBoardEntry(category: category, title: title.isEmpty ? category : title, body: body), at: 0)
    }
    func deleteBoardEntry(_ entry: NexusBoardEntry) { boardEntries.removeAll { $0.id == entry.id } }

    func makeBackupData() throws -> Data {
        let payload = NexusAppData(settings: settings, notes: notes, todos: todos, events: events, boardEntries: boardEntries, customLinks: customLinks,
                                   drawingData: UserDefaults.standard.string(forKey: "nexus.drawing.elements"))
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]; encoder.dateEncodingStrategy = .iso8601
        return try encoder.encode(payload)
    }
    func restoreBackup(_ data: Data) throws {
        let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        let payload = try decoder.decode(NexusAppData.self, from: data)
        settings = payload.settings; notes = payload.notes; todos = payload.todos; events = payload.events
        boardEntries = payload.boardEntries; customLinks = payload.customLinks
        if let drawingData = payload.drawingData { defaults.set(drawingData, forKey: "nexus.drawing.elements") }
    }
    func clearAllData() {
        settings = NexusSettings(); notes = []; todos = [:]; events = []; boardEntries = []; customLinks = []
        defaults.removeObject(forKey: "nexus.drawing.elements")
    }
}

// MARK: - Weather data service

struct NexusWeatherSnapshot: Decodable {
    struct Current: Decodable {
        var time: String?
        var temperature_2m: Double?
        var relative_humidity_2m: Double?
        var apparent_temperature: Double?
        var precipitation: Double?
        var weather_code: Int?
        var wind_speed_10m: Double?
        var wind_direction_10m: Double?
    }
    struct Hourly: Decodable {
        var time: [String]?
        var precipitation: [Double]?
        var precipitation_probability: [Double]?
    }
    struct Daily: Decodable {
        var time: [String]?
        var temperature_2m_max: [Double]?
        var temperature_2m_min: [Double]?
        var precipitation_probability_max: [Double]?
    }
    var current: Current?
    var hourly: Hourly?
    var daily: Daily?
}

@MainActor
final class NexusWeatherService: ObservableObject {
    @Published var snapshot: NexusWeatherSnapshot?
    @Published var isLoading = false
    @Published var message = "「更新」を押すと選択した都道府県の予報を取得します。"
    @Published var lastUpdated: Date?

    func load(prefecture: NexusPrefecture, anonymousMode: Bool) async {
        guard !anonymousMode else { message = "通信匿名モード中は外部通信を停止しています。"; return }
        guard let url = URL(string: "https://api.open-meteo.com/v1/forecast?latitude=\(prefecture.latitude)&longitude=\(prefecture.longitude)&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_direction_10m&hourly=precipitation,precipitation_probability&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&wind_speed_unit=ms&timezone=Asia%2FTokyo&past_days=1&forecast_days=2") else { message = "天気APIのURLを作成できません。"; return }
        isLoading = true; message = "天気データを取得中…"
        defer { isLoading = false }
        do {
            var request = URLRequest(url: url); request.timeoutInterval = 15; request.cachePolicy = .reloadIgnoringLocalCacheData
            let (data, response) = try await URLSession.shared.data(for: request)
            guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
            let decoded = try JSONDecoder().decode(NexusWeatherSnapshot.self, from: data)
            guard decoded.current?.temperature_2m != nil else { throw URLError(.cannotParseResponse) }
            snapshot = decoded; lastUpdated = Date(); message = "Open-Meteoの予報を取得しました。代表地点：\(prefecture.representative)"
        } catch {
            message = "天気を取得できませんでした。通信環境を確認して再試行してください。 (\(error.localizedDescription))"
        }
    }

    static func weatherLabel(_ code: Int?) -> (String, String) {
        switch code ?? -1 {
        case 0: ("sun.max.fill", "快晴")
        case 1: ("sun.max", "晴れ")
        case 2: ("cloud.sun", "一部曇り")
        case 3: ("cloud.fill", "曇り")
        case 45, 48: ("cloud.fog.fill", "霧")
        case 51, 53, 55, 56, 57: ("cloud.drizzle.fill", "霧雨")
        case 61, 63, 65, 66, 67: ("cloud.rain.fill", "雨")
        case 71, 73, 75, 77, 85, 86: ("cloud.snow.fill", "雪")
        case 80, 81, 82: ("cloud.heavyrain.fill", "にわか雨")
        case 95, 96, 99: ("cloud.bolt.rain.fill", "雷雨")
        default: ("cloud.sun", "天気情報あり")
        }
    }
}

// MARK: - URL checker

struct NexusURLReport {
    var score: Int
    var level: String
    var findings: [String]
    var host: String
}

enum NexusURLChecker {
    static func inspect(_ text: String) -> NexusURLReport {
        let raw = text.trimmingCharacters(in: .whitespacesAndNewlines)
        var findings: [String] = []; var score = 0
        guard raw.count <= 2048, !raw.isEmpty else { return .init(score: 100, level: "入力エラー", findings: ["URLが空、または長すぎます。"], host: "") }
        let candidate = raw.contains("://") ? raw : "https://" + raw
        guard let components = URLComponents(string: candidate), let scheme = components.scheme?.lowercased(), let host = components.host?.lowercased(), !host.isEmpty else {
            return .init(score: 90, level: "形式を確認", findings: ["URLとして解析できません。"], host: "")
        }
        if scheme != "https" { score += 25; findings.append("HTTPSではありません。") }
        if components.user != nil || components.password != nil { score += 25; findings.append("URLにユーザー名またはパスワードが含まれています。") }
        if host.contains("xn--") { score += 20; findings.append("国際化ドメイン（Punycode）が含まれています。表示名を慎重に確認してください。") }
        if host.filter({ $0 == "-" }).count >= 3 { score += 8; findings.append("ホスト名にハイフンが多く含まれています。") }
        if host.split(separator: ".").count >= 5 { score += 10; findings.append("サブドメインが多く含まれています。") }
        if let port = components.port, ![80, 443].contains(port) { score += 8; findings.append("標準以外のポート番号が指定されています。") }
        if let query = components.percentEncodedQuery, query.range(of: #"(?i)(token|password|passwd|secret|api[_-]?key)="#, options: .regularExpression) != nil {
            score += 12; findings.append("機密情報らしい名前のクエリパラメータがあります。")
        }
        if host.contains("@") { score += 20; findings.append("ホスト部分に不自然な記号があります。") }
        score = min(100, max(0, score))
        let level = score >= 55 ? "注意度 高" : score >= 25 ? "注意度 中" : "注意度 低"
        if findings.isEmpty { findings.append("形式上の大きな警告は見つかりませんでした。サイトの安全性を保証するものではありません。") }
        return .init(score: score, level: level, findings: findings, host: host)
    }
}

// MARK: - Safe local arithmetic parser (no eval)

struct NexusExpressionParser {
    private var tokens: [String] = []
    private var index = 0
    init(_ expression: String) {
        let pattern = #"\d+(?:\.\d+)?|[()+\-*/%]"#
        let normalized = expression.replacingOccurrences(of: "×", with: "*").replacingOccurrences(of: "÷", with: "/")
            .replacingOccurrences(of: "−", with: "-").filter { !$0.isWhitespace }
        tokens = normalized.matches(for: pattern)
        if tokens.joined() != normalized { tokens = [] }
    }
    mutating func parse() throws -> Double {
        guard !tokens.isEmpty else { throw ParseError.invalid }
        let value = try expression()
        guard index == tokens.count, value.isFinite else { throw ParseError.invalid }
        return value
    }
    private mutating func expression() throws -> Double {
        var value = try term()
        while index < tokens.count {
            if take("+") { value += try term() }
            else if take("-") { value -= try term() }
            else { break }
        }
        return value
    }
    private mutating func term() throws -> Double {
        var value = try factor()
        while index < tokens.count {
            if take("*") { value *= try factor() }
            else if take("/") { let d = try factor(); guard d != 0 else { throw ParseError.divisionByZero }; value /= d }
            else if take("%") { let d = try factor(); guard d != 0 else { throw ParseError.divisionByZero }; value = value.truncatingRemainder(dividingBy: d) }
            else { break }
        }
        return value
    }
    private mutating func factor() throws -> Double {
        if take("+") { return try factor() }
        if take("-") { return -(try factor()) }
        if take("(") { let value = try expression(); guard take(")") else { throw ParseError.invalid }; return value }
        guard index < tokens.count, let value = Double(tokens[index]) else { throw ParseError.invalid }
        index += 1; return value
    }
    private mutating func take(_ value: String) -> Bool {
        guard index < tokens.count, tokens[index] == value else { return false }
        index += 1; return true
    }
    enum ParseError: Error { case invalid, divisionByZero }
}

private extension String {
    func matches(for pattern: String) -> [String] {
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }
        let range = NSRange(startIndex..., in: self)
        return regex.matches(in: self, range: range).compactMap { Range($0.range, in: self).map { String(self[$0]) } }
    }
}

// MARK: - Encrypted backup helpers

enum NexusBackupCrypto {
    static func encrypt(_ clear: Data, passphrase: String) throws -> Data {
        guard passphrase.count >= 12 else { throw BackupError.shortPassphrase }
        let salt = Data((0..<16).map { _ in UInt8.random(in: 0...255) })
        let key = deriveKey(passphrase: passphrase, salt: salt)
        let box = try AES.GCM.seal(clear, using: key)
        var output = Data("NEXUSAES1".utf8); output.append(salt); output.append(box.combined ?? Data())
        return output
    }
    static func decrypt(_ encrypted: Data, passphrase: String) throws -> Data {
        let prefix = Data("NEXUSAES1".utf8)
        guard encrypted.starts(with: prefix), encrypted.count > prefix.count + 16 else { throw BackupError.invalidFile }
        let saltStart = prefix.count; let salt = encrypted.subdata(in: saltStart..<(saltStart + 16))
        let combined = encrypted.subdata(in: (saltStart + 16)..<encrypted.count)
        let key = deriveKey(passphrase: passphrase, salt: salt)
        let box = try AES.GCM.SealedBox(combined: combined)
        return try AES.GCM.open(box, using: key)
    }
    private static func deriveKey(passphrase: String, salt: Data) -> SymmetricKey {
        // PBKDF2-HMAC-SHA256; the passphrase itself is never stored.
        let passwordKey = SymmetricKey(data: Data(passphrase.utf8))
        var blockInput = salt
        blockInput.append(contentsOf: [0, 0, 0, 1])
        var u = Data(HMAC<SHA256>.authenticationCode(for: blockInput, using: passwordKey))
        var result = u
        for _ in 1..<310_000 {
            u = Data(HMAC<SHA256>.authenticationCode(for: u, using: passwordKey))
            for i in result.indices { result[i] ^= u[i] }
        }
        return SymmetricKey(data: result.prefix(32))
    }
    enum BackupError: Error { case shortPassphrase, invalidFile }
}

// MARK: - Drawing / media helpers

struct NexusStroke: Identifiable, Codable {
    var id = UUID()
    var points: [CGPointCodable]
    var colorHex: String
    var width: Double
}
struct CGPointCodable: Codable {
    var x: Double
    var y: Double
}

struct NexusFileDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json, .data, .plainText] }
    var data: Data
    init(data: Data = Data()) { self.data = data }
    init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws { FileWrapper(regularFileWithContents: data) }
}

#endif
