#if canImport(SwiftUI)
import SwiftUI
import AVFoundation
import UniformTypeIdentifiers

// MARK: - Weather (all 47 Japanese prefectures)

struct WeatherView: View {
    @EnvironmentObject private var store: NexusStore
    @StateObject private var service = NexusWeatherService()
    private var prefecture: NexusPrefecture { NexusPrefectures.all.first { $0.id == store.settings.selectedPrefecture } ?? NexusPrefectures.all[27] }

    var body: some View {
        VStack(spacing: 16) {
            NexusCard("都道府県別の天気", symbol: "cloud.sun.fill") {
                Picker("都道府県", selection: $store.settings.selectedPrefecture) {
                    ForEach(NexusPrefectures.all) { Text($0.name).tag($0.id) }
                }
                .pickerStyle(.menu)
                HStack(alignment: .center, spacing: 16) {
                    let condition = NexusWeatherService.weatherLabel(service.snapshot?.current?.weather_code)
                    Image(systemName: condition.0).symbolRenderingMode(.palette).foregroundStyle(.yellow, .cyan)
                        .font(.system(size: 52))
                    VStack(alignment: .leading, spacing: 3) {
                        Text(prefecture.name).font(.headline)
                        Text(service.snapshot?.current?.temperature_2m.map { String(format: "%.1f°C", $0) } ?? "--°C")
                            .font(.system(size: 36, weight: .light, design: .rounded)).monospacedDigit()
                        Text(condition.1).font(.subheadline).foregroundStyle(.secondary)
                    }
                    Spacer()
                    if service.isLoading { ProgressView() }
                }
                if let current = service.snapshot?.current {
                    Grid(alignment: .leading, horizontalSpacing: 18, verticalSpacing: 10) {
                        GridRow { metric("体感温度", value(current.apparent_temperature, suffix: "°C")); metric("湿度", value(current.relative_humidity_2m, suffix: "%")) }
                        GridRow { metric("降水量", value(current.precipitation, suffix: " mm")); metric("風速", value(current.wind_speed_10m, suffix: " m/s")) }
                        GridRow { metric("風向", windDirection(current.wind_direction_10m)); metric("更新時刻", current.time?.replacingOccurrences(of: "T", with: " ") ?? "--") }
                    }
                    .padding(.vertical, 6)
                }
                Text(service.message).font(.caption).foregroundStyle(.secondary)
                Text("予報地点は各都道府県の代表地点（行政庁所在地付近）です。Open-Meteoのデータを使用します。")
                    .font(.caption2).foregroundStyle(.secondary)
                HStack {
                    NexusActionButton(title: "天気を更新", symbol: "arrow.clockwise") { Task { await service.load(prefecture: prefecture, anonymousMode: store.settings.anonymousCommunication) } }
                    if let date = service.lastUpdated { Text("取得：\(date.formatted(date: .omitted, time: .shortened))").font(.caption2).foregroundStyle(.secondary) }
                }
            }
            if let snapshot = service.snapshot {
                NexusCard("24時間の降水量・時間別予報", symbol: "cloud.rain.fill") {
                    let hourly = Array(zip(snapshot.hourly?.time ?? [], snapshot.hourly?.precipitation ?? []).prefix(24))
                    let sum = hourly.reduce(0.0) { $0 + $1.1 }
                    HStack {
                        VStack(alignment: .leading) { Text("時間別予報の合計").font(.caption).foregroundStyle(.secondary); Text(String(format: "%.1f mm", sum)).font(.title2.bold()) }
                        Spacer()
                        VStack(alignment: .trailing) { Text("予報地点").font(.caption).foregroundStyle(.secondary); Text(prefecture.representative).font(.subheadline) }
                    }
                    if hourly.isEmpty { Text("時間別データがありません。").foregroundStyle(.secondary) }
                    else {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(alignment: .bottom, spacing: 8) {
                                ForEach(Array(hourly.enumerated()), id: \.offset) { item in
                                    let entry = item.element
                                    VStack(spacing: 4) {
                                        Text(String(format: "%.1f", entry.1)).font(.system(size: 9, design: .rounded))
                                        RoundedRectangle(cornerRadius: 4).fill(Color.cyan.opacity(0.75))
                                            .frame(width: 18, height: max(4, CGFloat(entry.1) * 8))
                                        Text(String(entry.0.suffix(5))).font(.system(size: 9)).foregroundStyle(.secondary)
                                    }.frame(width: 28, height: 72, alignment: .bottom)
                                }
                            }
                        }
                    }
                    Text("時間別のモデル予報値であり、観測所の確定実測値ではありません。").font(.caption2).foregroundStyle(.secondary)
                }
            }
            NexusCard("通信設定", symbol: "hand.raised") {
                Toggle("天気の自動取得を許可", isOn: $store.settings.autoWeatherNetwork)
                Text("初期設定はオフです。オンにすると、この画面を開いたときに天気を取得できます。通信先にはIPアドレス等が伝わります。通信匿名モード中は取得しません。")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .onAppear {
            if store.settings.autoWeatherNetwork { Task { await service.load(prefecture: prefecture, anonymousMode: store.settings.anonymousCommunication) } }
        }
        .onChange(of: store.settings.selectedPrefecture) { _, _ in
            if store.settings.autoWeatherNetwork { Task { await service.load(prefecture: prefecture, anonymousMode: store.settings.anonymousCommunication) } }
        }
    }

    @ViewBuilder private func metric(_ label: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) { Text(label).font(.caption).foregroundStyle(.secondary); Text(value).font(.subheadline.weight(.medium)) }
    }
    private func value(_ number: Double?, suffix: String) -> String { number.map { String(format: "%.1f%@", $0, suffix) } ?? "--" }
    private func windDirection(_ number: Double?) -> String {
        guard let number else { return "--" }
        let directions = ["北","北北東","北東","東北東","東","東南東","南東","南南東","南","南南西","南西","西南西","西","西北西","北西","北北西"]
        return directions[Int((number / 22.5).rounded()) % 16]
    }
}

// MARK: - Timer and stopwatch

struct TimerToolView: View {
    @State private var minutes = "5"
    @State private var seconds = "0"
    @State private var deadline: Date?
    @State private var remainingWhenPaused: TimeInterval = 0
    @State private var isPaused = false

    var body: some View {
        NexusCard("カウントダウンタイマー", symbol: "timer") {
            TimelineView(.periodic(from: .now, by: 1)) { context in
                let left = displayRemaining(at: context.date)
                Text(timeString(left)).font(.system(size: 54, weight: .light, design: .rounded)).monospacedDigit()
                    .frame(maxWidth: .infinity).foregroundStyle(left == 0 && deadline != nil ? .orange : .primary)
            }
            HStack {
                TextField("分", text: $minutes).keyboardType(.numberPad).textFieldStyle(.roundedBorder)
                Text("分")
                TextField("秒", text: $seconds).keyboardType(.numberPad).textFieldStyle(.roundedBorder)
                Text("秒")
            }
            HStack {
                NexusActionButton(title: deadline == nil ? "スタート" : (isPaused ? "再開" : "一時停止"), symbol: isPaused ? "play.fill" : "pause.fill") { toggle() }
                NexusActionButton(title: "リセット", symbol: "arrow.counterclockwise") { reset() }
            }
            Text("タイマーはこのアプリを開いている間のローカルカウントダウンです。OSの強制アラームではありません。")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
    private func displayRemaining(at date: Date) -> TimeInterval {
        guard let deadline else { return remainingWhenPaused }
        if isPaused { return remainingWhenPaused }
        return max(0, deadline.timeIntervalSince(date))
    }
    private func timeString(_ time: TimeInterval) -> String {
        let total = Int(time.rounded(.up)); return String(format: "%02d:%02d", total / 60, total % 60)
    }
    private func toggle() {
        if deadline == nil {
            remainingWhenPaused = max(0, (Double(minutes) ?? 0) * 60 + (Double(seconds) ?? 0))
            guard remainingWhenPaused > 0 else { return }
            deadline = Date().addingTimeInterval(remainingWhenPaused); isPaused = false
        } else if isPaused {
            deadline = Date().addingTimeInterval(remainingWhenPaused); isPaused = false
        } else {
            remainingWhenPaused = max(0, deadline!.timeIntervalSinceNow); deadline = nil; isPaused = true
        }
    }
    private func reset() { deadline = nil; remainingWhenPaused = 0; isPaused = false }
}

struct StopwatchToolView: View {
    @State private var start: Date?
    @State private var accumulated: TimeInterval = 0
    @State private var laps: [TimeInterval] = []
    var body: some View {
        NexusCard("ストップウォッチ", symbol: "stopwatch") {
            TimelineView(.periodic(from: .now, by: 0.01)) { context in
                Text(elapsedString(start.map { accumulated + context.date.timeIntervalSince($0) } ?? accumulated))
                    .font(.system(size: 50, weight: .light, design: .rounded)).monospacedDigit().frame(maxWidth: .infinity)
            }
            HStack {
                NexusActionButton(title: start == nil ? (accumulated == 0 ? "スタート" : "再開") : "停止", symbol: start == nil ? "play.fill" : "pause.fill") {
                    if let start { accumulated += Date().timeIntervalSince(start); self.start = nil } else { start = Date() }
                }
                NexusActionButton(title: "ラップ", symbol: "flag.fill") { if start != nil { laps.insert(accumulated + Date().timeIntervalSince(start!), at: 0) } }
                NexusActionButton(title: "リセット", symbol: "arrow.counterclockwise") { start = nil; accumulated = 0; laps = [] }
            }
            if !laps.isEmpty {
                Divider()
                ForEach(Array(laps.enumerated()), id: \.offset) { index, lap in
                    HStack { Text("Lap \(laps.count - index)"); Spacer(); Text(elapsedString(lap)).monospacedDigit() }
                        .font(.subheadline).padding(.vertical, 2)
                }
            }
        }
    }
    private func elapsedString(_ value: TimeInterval) -> String {
        let total = max(0, Int(value * 100)); return String(format: "%02d:%02d.%02d", total / 6000, (total / 100) % 60, total % 100)
    }
}

struct BGMToolView: View {
    @StateObject private var audio = NexusProceduralAudio()
    var body: some View {
        NexusCard("ローカルBGMプレイヤー", symbol: "waveform") {
            Text("音源ファイル・外部通信を使わず、端末内で簡単な音のループを生成します。")
                .font(.caption).foregroundStyle(.secondary)
            Picker("トラック", selection: $audio.selectedTrack) { ForEach(audio.tracks, id: \.self) { Text($0) } }.pickerStyle(.menu)
            HStack {
                NexusActionButton(title: "ランダム", symbol: "shuffle") { audio.selectedTrack = audio.tracks.randomElement() ?? audio.tracks[0]; audio.play() }
                NexusActionButton(title: audio.isPlaying ? "再生中" : "再生", symbol: "play.fill") { audio.play() }
                NexusActionButton(title: "停止", symbol: "stop.fill") { audio.stop() }
            }
            HStack { Image(systemName: "speaker"); Slider(value: $audio.volume, in: 0...1); Image(systemName: "speaker.wave.3") }
            Text(audio.isPlaying ? "再生中：\(audio.selectedTrack)" : "停止中").font(.caption).foregroundStyle(.secondary)
        }
        .onDisappear { audio.stop() }
    }
}

// MARK: - Memo, Todo, Calendar

struct MemoView: View {
    @EnvironmentObject private var store: NexusStore
    @State private var selectedID: UUID?
    @State private var title = ""
    @State private var bodyText = ""
    @State private var pinned = false
    @State private var search = ""

    private var filtered: [NexusNote] {
        store.notes.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) || $0.body.localizedCaseInsensitiveContains(search) }
            .sorted { $0.isPinned == $1.isPinned ? $0.updatedAt > $1.updatedAt : $0.isPinned }
    }
    var body: some View {
        VStack(spacing: 16) {
            NexusCard("メモ・ノート", symbol: "note.text") {
                TextField("メモを検索", text: $search).textFieldStyle(.roundedBorder)
                HStack {
                    Text("保存済み：\(store.notes.count)件").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    NexusActionButton(title: "新規", symbol: "plus") { newNote() }
                }
                if filtered.isEmpty { ContentUnavailableView("メモはありません", systemImage: "note.text", description: Text("新規ボタンから作成してください。")) }
                else {
                    ForEach(filtered) { note in
                        Button { select(note) } label: {
                            HStack(spacing: 10) {
                                if note.isPinned { Image(systemName: "pin.fill").foregroundStyle(.orange) }
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(note.title).font(.subheadline.bold()).lineLimit(1)
                                    Text(note.body.isEmpty ? "本文なし" : note.body).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                                }
                                Spacer()
                                Text(note.updatedAt.formatted(date: .numeric, time: .shortened)).font(.caption2).foregroundStyle(.tertiary)
                            }
                            .padding(10).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 10))
                        }.buttonStyle(.plain)
                    }
                }
            }
            NexusCard(selectedID == nil ? "メモを作成" : "メモを編集", symbol: "square.and.pencil") {
                TextField("題名", text: $title).textFieldStyle(.roundedBorder)
                TextEditor(text: $bodyText).frame(minHeight: 160).padding(5).background(.black.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
                Toggle("固定する", isOn: $pinned)
                HStack {
                    NexusActionButton(title: "保存", symbol: "tray.and.arrow.down") { save() }
                    NexusActionButton(title: "クリア", symbol: "xmark") { newNote() }
                    if let id = selectedID, let note = store.notes.first(where: { $0.id == id }) {
                        NexusActionButton(title: "削除", symbol: "trash", role: .destructive) { store.deleteNote(note); newNote() }
                    }
                }
                Text("メモはこのアプリの端末内保存領域に保存されます。外部送信しません。")
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
    }
    private func newNote() { selectedID = nil; title = ""; bodyText = ""; pinned = false }
    private func select(_ note: NexusNote) { selectedID = note.id; title = note.title; bodyText = note.body; pinned = note.isPinned }
    private func save() { store.addNote(title: title, body: bodyText, pinned: pinned, id: selectedID); newNote() }
}

struct TodoView: View {
    @EnvironmentObject private var store: NexusStore
    @State private var selectedDate = Date()
    @State private var newText = ""
    private var list: [NexusTodo] { store.todos(for: selectedDate) }
    private var completed: Int { list.filter(\.isDone).count }
    var body: some View {
        NexusCard("日付別Todo", symbol: "checklist") {
            DatePicker("対象日", selection: $selectedDate, displayedComponents: .date)
            HStack { Text("完了 \(completed) / \(list.count) 件").font(.subheadline.weight(.semibold)); Spacer(); Button("今日に戻る") { selectedDate = Date() }.font(.caption) }
            HStack {
                TextField("Todoを追加してください", text: $newText).textFieldStyle(.roundedBorder).onSubmit(add)
                Button(action: add) { Image(systemName: "plus.circle.fill").font(.title2) }.buttonStyle(.plain)
            }
            if list.isEmpty { Text("この日のTodoはありません。").foregroundStyle(.secondary).padding(.vertical, 12) }
            ForEach(list) { item in
                HStack(spacing: 10) {
                    Button { store.toggleTodo(item, on: selectedDate) } label: {
                        Image(systemName: item.isDone ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(item.isDone ? .green : .secondary).font(.title3)
                    }.buttonStyle(.plain)
                    Text(item.text).strikethrough(item.isDone).foregroundStyle(item.isDone ? .secondary : .primary)
                    Spacer()
                    Button(role: .destructive) { store.deleteTodo(item, on: selectedDate) } label: { Image(systemName: "trash") }.buttonStyle(.borderless)
                }.padding(.vertical, 4)
            }
            if completed > 0 { Button("完了分を削除") { store.clearCompletedTodos(on: selectedDate) }.font(.caption).foregroundStyle(.red) }
            Text("Todoとチェック状態は日付ごとに端末内へ保存されます。")
                .font(.caption2).foregroundStyle(.secondary)
        }
    }
    private func add() { store.addTodo(newText, on: selectedDate); newText = "" }
}

struct CalendarView: View {
    @EnvironmentObject private var store: NexusStore
    @State private var month = Calendar.current.dateInterval(of: .month, for: Date())?.start ?? Date()
    @State private var selectedDate = Date()
    @State private var eventTitle = ""
    @State private var eventTime = Date()
    private var monthEvents: [NexusEvent] { store.events.filter { Calendar.current.isDate($0.date, equalTo: selectedDate, toGranularity: .day) }.sorted { $0.date < $1.date } }
    private var days: [Date?] {
        let cal = Calendar.current
        guard let range = cal.range(of: .day, in: .month, for: month), let first = cal.dateInterval(of: .month, for: month)?.start else { return [] }
        let leading = (cal.component(.weekday, from: first) - cal.firstWeekday + 7) % 7
        return Array(repeating: nil, count: leading) + range.compactMap { cal.date(byAdding: .day, value: $0 - 1, to: first) }
    }
    var body: some View {
        VStack(spacing: 16) {
            NexusCard("予定表・カレンダー", symbol: "calendar") {
                HStack {
                    Button { shiftMonth(-1) } label: { Image(systemName: "chevron.left") }
                    Spacer(); Text(month.formatted(.dateTime.year().month())).font(.headline); Spacer()
                    Button { shiftMonth(1) } label: { Image(systemName: "chevron.right") }
                }
                let labels = Calendar.current.shortWeekdaySymbols
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 3), count: 7), spacing: 5) {
                    ForEach(labels, id: \.self) { label in Text(label).font(.caption.bold()).foregroundStyle(.secondary).frame(maxWidth: .infinity) }
                    ForEach(Array(days.enumerated()), id: \.offset) { _, date in
                        if let date {
                            let hasEvent = store.events.contains { Calendar.current.isDate($0.date, inSameDayAs: date) }
                            Button { selectedDate = date; eventTime = date } label: {
                                VStack(spacing: 2) {
                                    Text("\(Calendar.current.component(.day, from: date))").font(.subheadline)
                                    Circle().fill(hasEvent ? Color.cyan : .clear).frame(width: 4, height: 4)
                                }
                                .frame(maxWidth: .infinity, minHeight: 38)
                                .background(Calendar.current.isDate(date, inSameDayAs: selectedDate) ? Color.cyan.opacity(0.24) : .clear, in: RoundedRectangle(cornerRadius: 8))
                            }.buttonStyle(.plain)
                        } else { Color.clear.frame(height: 38) }
                    }
                }
                Divider()
                Text("選択日：\(selectedDate.formatted(date: .long, time: .omitted))").font(.subheadline.weight(.semibold))
                HStack {
                    TextField("予定", text: $eventTitle).textFieldStyle(.roundedBorder)
                    DatePicker("時刻", selection: $eventTime, displayedComponents: .hourAndMinute).labelsHidden()
                }
                Button("予定を追加") {
                    let date = Calendar.current.date(bySettingHour: Calendar.current.component(.hour, from: eventTime), minute: Calendar.current.component(.minute, from: eventTime), second: 0, of: selectedDate) ?? selectedDate
                    store.addEvent(title: eventTitle, date: date); eventTitle = ""
                }.buttonStyle(.borderedProminent)
            }
            NexusCard("選択日の予定", symbol: "list.bullet.rectangle") {
                if monthEvents.isEmpty { Text("この日の予定はありません。").foregroundStyle(.secondary) }
                ForEach(monthEvents) { event in
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(event.title).font(.subheadline.bold())
                            Text(event.date.formatted(date: .omitted, time: .shortened)).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button(role: .destructive) { store.deleteEvent(event) } label: { Image(systemName: "trash") }.buttonStyle(.borderless)
                    }
                }
            }
        }
    }
    private func shiftMonth(_ amount: Int) {
        month = Calendar.current.date(byAdding: .month, value: amount, to: month) ?? month
    }
}

// MARK: - Translation / external news

struct TranslateView: View {
    @EnvironmentObject private var store: NexusStore
    @Environment(\.openURL) private var openURL
    @StateObject private var speech = NexusSpeechService()
    @State private var input = ""
    @State private var targetLanguage = "英語"
    @State private var status = "翻訳サイトを開くと、選択したサービスへ文章が送信されます。"
    private var languageCode: String { targetLanguage == "日本語" ? "ja" : targetLanguage == "韓国語" ? "ko" : targetLanguage == "中国語" ? "zh-CN" : targetLanguage == "フランス語" ? "fr" : targetLanguage == "ドイツ語" ? "de" : "en" }
    var body: some View {
        NexusCard("翻訳・読み上げ", symbol: "translate") {
            Picker("翻訳先", selection: $targetLanguage) { ForEach(["英語", "日本語", "中国語", "韓国語", "フランス語", "ドイツ語"], id: \.self) { Text($0) } }.pickerStyle(.menu)
            TextEditor(text: $input).frame(minHeight: 150).padding(5).background(.black.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
            HStack {
                NexusActionButton(title: "Google 翻訳", symbol: "globe") { openTranslator("google") }
                NexusActionButton(title: "DeepL", symbol: "character.book.closed") { openTranslator("deepl") }
                NexusActionButton(title: "Bing", symbol: "translate") { openTranslator("bing") }
            }
            HStack {
                NexusActionButton(title: "読み上げ", symbol: "speaker.wave.2") { speech.speak(input, language: "ja-JP") }
                NexusActionButton(title: "停止", symbol: "stop.fill") { speech.stop() }
                ShareLink(item: input) { Label("共有", systemImage: "square.and.arrow.up") }.buttonStyle(.bordered)
            }
            Text(status).font(.caption).foregroundStyle(.secondary)
            Text("このSwift版では端末内の自動翻訳エンジンを同梱していません。翻訳サービスを開く操作をした場合のみ、入力文が外部サービスへ送信されます。")
                .font(.caption2).foregroundStyle(.secondary)
        }
    }
    private func openTranslator(_ service: String) {
        guard !store.settings.anonymousCommunication else { status = "通信匿名モード中は外部サイトを開けません。"; return }
        let encoded = input.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? input
        let urlString: String = switch service {
        case "deepl": "https://www.deepl.com/translator#ja/\(languageCode)/\(encoded)"
        case "bing": "https://www.bing.com/translator?from=ja&to=\(languageCode)&text=\(encoded)"
        default: "https://translate.google.com/?sl=auto&tl=\(languageCode)&text=\(encoded)"
        }
        if let url = URL(string: urlString) { openURL(url); status = "\(service)を開きました。" }
    }
}

struct NewsView: View {
    @EnvironmentObject private var store: NexusStore
    @Environment(\.openURL) private var openURL
    @State private var query = ""
    private let categories: [(String, String, String)] = [
        ("最新ニュース・速報", "bolt.fill", "https://news.google.com/topstories?hl=ja&gl=JP&ceid=JP:ja"),
        ("国内ニュース", "flag.fill", "https://news.google.com/search?q=国内&hl=ja&gl=JP&ceid=JP:ja"),
        ("世界のニュース", "globe.asia.australia.fill", "https://news.google.com/search?q=世界&hl=ja&gl=JP&ceid=JP:ja"),
        ("科学・AI・IT", "cpu.fill", "https://news.google.com/search?q=AI%20科学%20テクノロジー&hl=ja&gl=JP&ceid=JP:ja"),
        ("兵庫・関西", "mappin.and.ellipse", "https://news.google.com/search?q=兵庫県&hl=ja&gl=JP&ceid=JP:ja"),
        ("スポーツ", "sportscourt.fill", "https://news.google.com/search?q=スポーツ&hl=ja&gl=JP&ceid=JP:ja")
    ]
    var body: some View {
        VStack(spacing: 16) {
            NexusCard("ニュース検索", symbol: "newspaper.fill") {
                HStack {
                    TextField("ニュースを検索", text: $query).textFieldStyle(.roundedBorder).onSubmit(search)
                    Button("検索", action: search).buttonStyle(.borderedProminent)
                }
                ForEach(categories, id: \.0) { item in
                    Button { open(item.2) } label: {
                        Label(item.0, systemImage: item.1).frame(maxWidth: .infinity, alignment: .leading).padding(11)
                            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 10))
                    }.buttonStyle(.plain)
                }
            }
            NexusCard("ニュース提供元", symbol: "bookmark") {
                ForEach(NexusCatalog.newsLinks) { link in
                    Button { open(link.url) } label: { Label(link.name, systemImage: link.symbol).frame(maxWidth: .infinity, alignment: .leading) }.buttonStyle(.plain)
                }
                Text("ニュース本文をこのアプリ内で収集せず、提供元ページを開く方式です。最新記事の内容・掲載時刻はリンク先で確認してください。")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }
    private func search() {
        let text = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query
        open("https://news.google.com/search?q=\(text)&hl=ja&gl=JP&ceid=JP:ja")
    }
    private func open(_ raw: String) {
        guard !store.settings.anonymousCommunication else { store.alertMessage = "通信匿名モード中は外部サイトを開けません。"; return }
        if let url = URL(string: raw), url.scheme == "https" { openURL(url) }
    }
}

// MARK: - Network measurement and local file music player

struct NetworkTestView: View {
    @EnvironmentObject private var store: NexusStore
    @State private var isTesting = false
    @State private var speed: Double?
    @State private var status = "速度測定は手動操作のみです。Cloudflareから約5MBを取得します。"
    var body: some View {
        NexusCard("ネットワーク速度測定", symbol: "speedometer") {
            Text(speed.map { String(format: "%.1f Mbps", $0) } ?? "-- Mbps")
                .font(.system(size: 46, weight: .light, design: .rounded)).frame(maxWidth: .infinity)
            if isTesting { ProgressView() }
            Button(isTesting ? "測定中…" : "速度を実測（約5MB）") { Task { await runTest() } }
                .buttonStyle(.borderedProminent).disabled(isTesting)
            Text(status).font(.caption).foregroundStyle(.secondary)
            Text("下り速度の簡易推定です。アップロード速度や回線品質全体は測定しません。測定先にIPアドレス等が伝わります。")
                .font(.caption2).foregroundStyle(.secondary)
        }
    }
    private func runTest() async {
        guard !store.settings.anonymousCommunication else { status = "通信匿名モード中は測定できません。"; return }
        guard let url = URL(string: "https://speed.cloudflare.com/__down?bytes=5000000&nexus=swift") else { return }
        isTesting = true; speed = nil; status = "ダウンロード中…"
        defer { isTesting = false }
        do {
            var request = URLRequest(url: url); request.timeoutInterval = 30; request.cachePolicy = .reloadIgnoringLocalCacheData
            let start = Date(); let (data, response) = try await URLSession.shared.data(for: request); let duration = Date().timeIntervalSince(start)
            guard (response as? HTTPURLResponse)?.statusCode == 200, duration > 0 else { throw URLError(.badServerResponse) }
            speed = Double(data.count * 8) / duration / 1_000_000
            status = "測定完了：\(ByteCountFormatter.string(fromByteCount: Int64(data.count), countStyle: .file))を\(String(format: "%.2f", duration))秒で受信しました。"
        } catch { status = "測定できませんでした：\(error.localizedDescription)" }
    }
}

struct MusicPlayerView: View {
    @StateObject private var player = NexusFileAudioPlayer()
    @State private var showImporter = false
    @State private var importError: String?
    var body: some View {
        NexusCard("端末内ミュージックプレーヤー", symbol: "music.note.list") {
            Text(player.title).font(.headline).lineLimit(1)
            HStack { Text(time(player.currentTime)); Spacer(); Text(time(player.duration)) }.font(.caption.monospacedDigit()).foregroundStyle(.secondary)
            Slider(value: Binding(get: { player.currentTime }, set: { player.seek($0) }), in: 0...max(1, player.duration))
            HStack {
                NexusActionButton(title: player.isPlaying ? "一時停止" : "再生", symbol: player.isPlaying ? "pause.fill" : "play.fill") { player.toggle() }
                NexusActionButton(title: "停止", symbol: "stop.fill") { player.stop() }
                NexusActionButton(title: "ファイル選択", symbol: "folder") { showImporter = true }
            }
            HStack { Image(systemName: "speaker"); Slider(value: $player.volume, in: 0...1); Image(systemName: "speaker.wave.3") }
            if let importError { Text(importError).font(.caption).foregroundStyle(.red) }
            Text("対応形式は端末のAVFoundationが再生できる音声ファイルです。ファイルへのアクセスは選択操作で許可された場合のみです。")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.audio], allowsMultipleSelection: false) { result in
            do { if let url = try result.get().first { try player.load(url: url); importError = nil } }
            catch { importError = error.localizedDescription }
        }
        .onDisappear { player.stop() }
    }
    private func time(_ value: TimeInterval) -> String { String(format: "%d:%02d", Int(value) / 60, Int(value) % 60) }
}

// MARK: - Calculator

struct CalculatorView: View {
    @State private var expression = ""
    @State private var display = "0"
    @State private var history: [String] = []
    private let keys = [["7","8","9","÷"],["4","5","6","×"],["1","2","3","−"],["0",".","%","+"],["(",")","⌫","="]]
    var body: some View {
        NexusCard("電卓", symbol: "calculator") {
            Text(display).font(.system(size: 38, weight: .light, design: .rounded)).monospacedDigit()
                .frame(maxWidth: .infinity, minHeight: 65, alignment: .trailing).lineLimit(1).minimumScaleFactor(0.5)
                .padding(.horizontal, 8).background(.black.opacity(0.22), in: RoundedRectangle(cornerRadius: 12))
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 7), count: 4), spacing: 7) {
                ForEach(keys.flatMap { $0 }, id: \.self) { key in
                    Button { tap(key) } label: {
                        Text(key).font(.title2.weight(.medium)).frame(maxWidth: .infinity, minHeight: 55)
                            .background(["=","+","−","×","÷"].contains(key) ? Color.cyan.opacity(0.28) : .white.opacity(0.09), in: RoundedRectangle(cornerRadius: 12))
                    }.buttonStyle(.plain)
                }
            }
            HStack { Button("AC") { expression = ""; display = "0" }; Spacer(); Text("計算履歴").font(.caption.bold()) }
            ForEach(history.prefix(5), id: \.self) { Text($0).font(.caption.monospaced()).foregroundStyle(.secondary) }
        }
    }
    private func tap(_ key: String) {
        if key == "AC" { expression = ""; display = "0"; return }
        if key == "⌫" { expression = String(expression.dropLast()); display = expression.isEmpty ? "0" : expression; return }
        if key == "=" {
            do {
                var parser = NexusExpressionParser(expression); let result = try parser.parse()
                let text = result.rounded() == result ? String(Int(result)) : String(result)
                history.insert("\(expression) = \(text)", at: 0); display = text; expression = text
            } catch { display = "計算エラー" }
            return
        }
        expression.append(key); display = expression
    }
}

// MARK: - Bulletin board

struct BulletinBoardView: View {
    @EnvironmentObject private var store: NexusStore
    @State private var category = "主の最近の感想"
    @State private var title = ""
    @State private var bodyText = ""
    private let categories = ["主の最近の感想", "近況・日記", "お知らせ", "アイデア・ひらめき", "その他"]
    var body: some View {
        VStack(spacing: 16) {
            NexusCard("記録を書く", symbol: "square.and.pencil") {
                Picker("記録の種類", selection: $category) { ForEach(categories, id: \.self) { Text($0) } }.pickerStyle(.menu)
                TextField("タイトル", text: $title).textFieldStyle(.roundedBorder)
                TextEditor(text: $bodyText).frame(minHeight: 140).padding(5).background(.black.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
                Button("記録を保存") { store.addBoardEntry(category: category, title: title, body: bodyText); title = ""; bodyText = "" }
                    .buttonStyle(.borderedProminent)
                Text("この掲示板の文章は端末内に保存されます。外部には送信しません。")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            NexusCard("最近の記録（\(store.boardEntries.count)件）", symbol: "text.book.closed") {
                if store.boardEntries.isEmpty { Text("まだ記録がありません。").foregroundStyle(.secondary) }
                ForEach(store.boardEntries) { entry in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text(entry.category).font(.caption.bold()).foregroundStyle(.cyan)
                            Spacer()
                            Text(entry.createdAt.formatted(date: .numeric, time: .shortened)).font(.caption2).foregroundStyle(.secondary)
                        }
                        Text(entry.title).font(.headline)
                        Text(entry.body).font(.subheadline).textSelection(.enabled)
                        HStack { Spacer(); Button(role: .destructive) { store.deleteBoardEntry(entry) } label: { Label("削除", systemImage: "trash") }.font(.caption) }
                    }
                    .padding(11).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
                }
                if !store.boardEntries.isEmpty {
                    ShareLink(item: store.boardEntries.map { "[\($0.category)] \($0.title)\n\($0.body)\n\($0.createdAt.formatted())" }.joined(separator: "\n\n---\n\n")) {
                        Label("TXTとして共有", systemImage: "square.and.arrow.up")
                    }.buttonStyle(.bordered)
                }
            }
        }
    }
}

// MARK: - System monitor

struct SystemMonitorView: View {
    @State private var refreshed = Date()
    var body: some View {
        NexusCard("NEXUS SYSTEM MONITOR", symbol: "chart.bar.xaxis") {
            metric("OS", value: ProcessInfo.processInfo.operatingSystemVersionString)
            metric("CPUコア数", value: "\(ProcessInfo.processInfo.processorCount)（論理）")
            metric("物理メモリ", value: ByteCountFormatter.string(fromByteCount: Int64(ProcessInfo.processInfo.physicalMemory), countStyle: .memory))
            metric("プロセスID", value: "\(ProcessInfo.processInfo.processIdentifier)")
            metric("言語", value: Locale.current.identifier)
            metric("最終更新", value: refreshed.formatted(date: .numeric, time: .standard))
            Button("状態を更新") { refreshed = Date() }.buttonStyle(.borderedProminent)
            Text("表示できるOS情報のみをローカルで表示します。ブラウザ専用のメモリ値やWi-Fi情報など、OSが公開していない値は取得しません。")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
    private func metric(_ title: String, value: String) -> some View {
        HStack(alignment: .firstTextBaseline) { Text(title).foregroundStyle(.secondary); Spacer(); Text(value).font(.subheadline.monospaced()).multilineTextAlignment(.trailing) }
    }
}

#endif
