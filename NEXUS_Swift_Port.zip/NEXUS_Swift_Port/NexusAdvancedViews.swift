#if canImport(SwiftUI)
import SwiftUI
import UniformTypeIdentifiers
import CryptoKit

// MARK: - Drawing studio

struct NexusPoint: Codable { var x: Double; var y: Double }
struct NexusDrawingElement: Codable, Identifiable {
    var id = UUID()
    var kind: String
    var points: [NexusPoint]
    var color: String
    var width: Double
    var text: String = ""
}

struct DrawingStudioView: View {
    @AppStorage("nexus.drawing.elements") private var encodedDrawing = "[]"
    @State private var elements: [NexusDrawingElement] = []
    @State private var active: NexusDrawingElement?
    @State private var tool = "ペン"
    @State private var color = "#12DFFF"
    @State private var width = 4.0
    @State private var textToDraw = ""
    @State private var showTextPrompt = false
    private let tools = ["ペン", "蛍光", "ネオン", "消しゴム", "直線", "四角", "円", "文字"]
    private let palette = ["#12DFFF", "#FF69D4", "#A78BFA", "#FFFFFF", "#FFB347", "#69F0AE", "#111111"]

    var body: some View {
        VStack(spacing: 16) {
            NexusCard("お絵かきスタジオ", symbol: "paintbrush.pointed.fill") {
                Picker("ツール", selection: $tool) { ForEach(tools, id: \.self) { Text($0) } }.pickerStyle(.menu)
                HStack {
                    ForEach(palette, id: \.self) { c in
                        Button { color = c } label: {
                            Circle().fill(Color(hex: c)).frame(width: 25, height: 25)
                                .overlay(Circle().stroke(color == c ? .primary : .clear, lineWidth: 2))
                        }.buttonStyle(.plain)
                    }
                    Spacer()
                    Text("太さ \(Int(width))").font(.caption)
                }
                Slider(value: $width, in: 1...22)
                if tool == "文字" {
                    TextField("キャンバスに書く文字", text: $textToDraw).textFieldStyle(.roundedBorder)
                }
                GeometryReader { geo in
                    Canvas { context, size in
                        context.fill(Path(CGRect(origin: .zero, size: size)), with: .color(.white))
                        for element in elements { draw(element, in: &context) }
                        if let active { draw(active, in: &context) }
                    }
                    .background(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .gesture(DragGesture(minimumDistance: 0).onChanged { value in
                        let point = NexusPoint(x: value.location.x, y: value.location.y)
                        if active == nil {
                            active = NexusDrawingElement(kind: tool, points: [point], color: tool == "消しゴム" ? "#FFFFFF" : color, width: tool == "蛍光" ? width * 3 : width, text: textToDraw)
                        } else if active?.points.last?.x != point.x || active?.points.last?.y != point.y {
                            active?.points.append(point)
                        }
                    }.onEnded { _ in
                        if let active { elements.append(active); persist() }
                        active = nil
                    })
                    .onTapGesture { location in
                        if tool == "文字", !textToDraw.isEmpty {
                            let point = NexusPoint(x: location.x, y: location.y)
                            elements.append(NexusDrawingElement(kind: "文字", points: [point], color: color, width: width, text: textToDraw)); persist()
                        }
                    }
                }
                .frame(height: 340)
                HStack {
                    NexusActionButton(title: "元に戻す", symbol: "arrow.uturn.backward") { if !elements.isEmpty { elements.removeLast(); persist() } }
                    NexusActionButton(title: "全消去", symbol: "trash", role: .destructive) { elements = []; persist() }
                    NexusActionButton(title: "保存", symbol: "tray.and.arrow.down") { persist() }
                }
                Text("描画データはアプリ内に保存します。線・蛍光・消しゴム・直線・四角・円・文字を利用できます。")
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
        .onAppear { load() }
    }

    private func draw(_ element: NexusDrawingElement, in context: inout GraphicsContext) {
        guard let first = element.points.first else { return }
        if element.kind == "文字" {
            let text = Text(element.text).font(.system(size: max(14, element.width * 4), weight: .bold)).foregroundColor(Color(hex: element.color))
            context.draw(text, at: CGPoint(x: first.x, y: first.y), anchor: .topLeading)
            return
        }
        var path = Path()
        if ["四角", "円"].contains(element.kind), let last = element.points.last {
            let rect = CGRect(x: min(first.x, last.x), y: min(first.y, last.y), width: abs(last.x - first.x), height: abs(last.y - first.y))
            if element.kind == "円" { path.addEllipse(in: rect) } else { path.addRect(rect) }
        } else if element.kind == "直線", let last = element.points.last {
            path.move(to: CGPoint(x: first.x, y: first.y)); path.addLine(to: CGPoint(x: last.x, y: last.y))
        } else {
            path.move(to: CGPoint(x: first.x, y: first.y))
            for point in element.points.dropFirst() { path.addLine(to: CGPoint(x: point.x, y: point.y)) }
        }
        let lineColor = Color(hex: element.color)
        if element.kind == "ネオン" {
            var glow = context
            glow.addFilter(.blur(radius: 7))
            glow.stroke(path, with: .color(lineColor.opacity(0.5)), lineWidth: element.width * 2.2)
        }
        context.stroke(path, with: .color(element.kind == "蛍光" ? lineColor.opacity(0.35) : lineColor),
                       style: StrokeStyle(lineWidth: element.width, lineCap: .round, lineJoin: .round))
    }
    private func persist() {
        if let data = try? JSONEncoder().encode(elements) { encodedDrawing = data.base64EncodedString() }
    }
    private func load() {
        guard let data = Data(base64Encoded: encodedDrawing), let decoded = try? JSONDecoder().decode([NexusDrawingElement].self, from: data) else { elements = []; return }
        elements = decoded
    }
}

// MARK: - CodeBridge and language workshop

struct CodeBridgeView: View {
    @EnvironmentObject private var store: NexusStore
    @State private var sourceLanguage = "Python"
    @State private var targetLanguage = "Swift"
    @State private var inputCode = "print(\"Hello, NEXUS!\")"
    @State private var outputCode = ""
    @State private var workLanguage = "Swift"
    @State private var workName = "MyProgram"
    @State private var workRequest = ""
    @State private var workCode = ""
    @State private var workPrompt = ""
    @State private var assistantTab = "変換"
    @State private var languageName = "NEXUS-L"
    @State private var paradigm = "マルチパラダイム"
    @State private var typing = "静的型付け（型推論あり）"
    @State private var syntax = "C系（波括弧とセミコロン）"
    @State private var description = "安全で読みやすい汎用プログラミング言語"
    @State private var features = "非同期処理, モジュール, エラー処理"
    @State private var generatedSpec = ""
    private let languages = ["Python", "JavaScript", "Java", "Go", "R", "TypeScript", "C", "C#", "C++", "Cython", "Rust", "PHP", "HTML", "BASIC", "SQL", "Elixir", "Haskell", "Swift"]

    var body: some View {
        VStack(spacing: 16) {
            NexusCard("CodeBridge", symbol: "chevron.left.forwardslash.chevron.right") {
                Picker("機能", selection: $assistantTab) { Text("言語間コード変換").tag("変換"); Text("プログラム作成").tag("作成"); Text("Assistant+ 言語工房").tag("言語工房") }.pickerStyle(.segmented)
                if assistantTab == "変換" { converter }
                else if assistantTab == "作成" { workspace }
                else { languageWorkshop }
            }
            NexusCard("対応言語", symbol: "list.bullet.rectangle") {
                Text(languages.joined(separator: " / ")).font(.caption).foregroundStyle(.secondary)
                Text("ローカルの基本パターン変換です。大規模な構文・ライブラリ・型・実行環境を完全に変換するコンパイラではありません。変換結果は必ず確認してください。")
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
    }

    private var converter: some View {
        VStack(alignment: .leading, spacing: 10) {
            Picker("変換元", selection: $sourceLanguage) { ForEach(languages, id: \.self) { Text($0) } }.pickerStyle(.menu)
            HStack {
                Image(systemName: "arrow.down")
                Picker("変換先", selection: $targetLanguage) { ForEach(languages, id: \.self) { Text($0) } }.pickerStyle(.menu)
                Button("入替") { let old = sourceLanguage; sourceLanguage = targetLanguage; targetLanguage = old }
            }
            Text("変換元コード").font(.caption.bold())
            TextEditor(text: $inputCode).frame(minHeight: 150).padding(5).background(.black.opacity(0.12), in: RoundedRectangle(cornerRadius: 10)).font(.system(.body, design: .monospaced))
            HStack {
                NexusActionButton(title: "サンプル", symbol: "flask") { inputCode = Self.sample(for: sourceLanguage) }
                NexusActionButton(title: "変換", symbol: "bolt.fill") { outputCode = NexusCodeConverter.convert(inputCode, from: sourceLanguage, to: targetLanguage) }
                NexusActionButton(title: "クリア", symbol: "trash") { inputCode = ""; outputCode = "" }
            }
            Text("変換結果").font(.caption.bold())
            TextEditor(text: $outputCode).frame(minHeight: 150).padding(5).background(.black.opacity(0.12), in: RoundedRectangle(cornerRadius: 10)).font(.system(.body, design: .monospaced))
            if !outputCode.isEmpty { ShareLink(item: outputCode) { Label("結果を共有・保存", systemImage: "square.and.arrow.up") }.buttonStyle(.bordered) }
        }
    }

    private var workspace: some View {
        VStack(alignment: .leading, spacing: 10) {
            Picker("プログラム言語", selection: $workLanguage) { ForEach(languages, id: \.self) { Text($0) } }.pickerStyle(.menu)
            TextField("ファイル名", text: $workName).textFieldStyle(.roundedBorder)
            TextField("作成・修正したい内容", text: $workRequest).textFieldStyle(.roundedBorder)
            TextEditor(text: $workCode).frame(minHeight: 220).padding(5).background(.black.opacity(0.12), in: RoundedRectangle(cornerRadius: 10)).font(.system(.body, design: .monospaced))
            HStack {
                NexusActionButton(title: "サンプル", symbol: "flask") { workCode = Self.sample(for: workLanguage) }
                NexusActionButton(title: "AI生成依頼文", symbol: "sparkles") { workPrompt = prompt(mode: "新規生成") }
                NexusActionButton(title: "修正依頼文", symbol: "wrench") { workPrompt = prompt(mode: "既存コードの修正") }
            }
            if !workPrompt.isEmpty {
                Text("AIに渡す依頼文（自動送信されません）").font(.caption.bold())
                TextEditor(text: $workPrompt).frame(minHeight: 140).padding(5).background(.black.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
                ShareLink(item: workPrompt) { Label("依頼文を共有", systemImage: "square.and.arrow.up") }.buttonStyle(.bordered)
            }
            if !workCode.isEmpty { ShareLink(item: workCode) { Label("コードを共有・保存", systemImage: "square.and.arrow.up") }.buttonStyle(.bordered) }
        }
    }

    private var languageWorkshop: some View {
        VStack(alignment: .leading, spacing: 10) {
            TextField("言語名", text: $languageName).textFieldStyle(.roundedBorder)
            Picker("パラダイム", selection: $paradigm) { ForEach(["マルチパラダイム", "手続き型", "オブジェクト指向", "関数型", "データ指向・並列処理", "教育向け"], id: \.self) { Text($0) } }.pickerStyle(.menu)
            Picker("型システム", selection: $typing) { ForEach(["静的型付け（型推論あり）", "動的型付け", "静的型付け（明示宣言）", "段階的型付け"], id: \.self) { Text($0) } }.pickerStyle(.menu)
            Picker("構文", selection: $syntax) { ForEach(["C系（波括弧とセミコロン）", "Python風（インデント）", "シンプルなインデント構文", "Lisp風（S式）"], id: \.self) { Text($0) } }.pickerStyle(.menu)
            TextField("言語の説明", text: $description).textFieldStyle(.roundedBorder)
            TextField("機能（カンマ区切り）", text: $features).textFieldStyle(.roundedBorder)
            Button("言語仕様を生成") { generatedSpec = buildSpec() }.buttonStyle(.borderedProminent)
            if !generatedSpec.isEmpty {
                TextEditor(text: $generatedSpec).frame(minHeight: 230).padding(5).background(.black.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
                ShareLink(item: generatedSpec) { Label("仕様を共有・保存", systemImage: "square.and.arrow.up") }.buttonStyle(.bordered)
                Button("外部AI向けプロンプトを作成") { workPrompt = "以下の言語仕様をもとに、構文・コンパイラ設計・テスト・トランスパイラの実装案を提案してください。\n\n" + generatedSpec }
            }
            if !workPrompt.isEmpty { TextEditor(text: $workPrompt).frame(minHeight: 120); ShareLink(item: workPrompt) { Label("プロンプトを共有", systemImage: "square.and.arrow.up") } }
        }
    }

    private func prompt(mode: String) -> String {
        "あなたは経験豊富なソフトウェアエンジニアです。\n\n依頼：\(mode)\n対象言語：\(workLanguage)\nファイル名：\(workName)\n要件：\(workRequest)\n\n既存コード：\n```\(workLanguage.lowercased())\n\(workCode)\n```\n\n要件を満たす完全なコード、変更点、実行方法、注意点を提示してください。コードは自動送信されていません。"
    }
    private func buildSpec() -> String {
        "# \(languageName) 言語仕様案\n\n## 概要\n\(description)\n\n## 設計\n- パラダイム：\(paradigm)\n- 型システム：\(typing)\n- 構文：\(syntax)\n- 主な機能：\(features)\n\n## 基本構文案\n\(syntax.contains("Python") || syntax.contains("インデント") ? "func greet(name: String):\n    print(\"Hello, \" + name)" : syntax.contains("Lisp") ? "(define (greet name)\n  (print name))" : "func greet(name: String) {\n    print(\"Hello, \\(name)\");\n}")\n\n## 型・エラー・モジュール\n具体的な型規則、例外モデル、モジュール境界、標準ライブラリを今後定義する。\n\n※これは設計のたたき台であり、実装済みコンパイラではありません。"
    }
    private static func sample(for language: String) -> String {
        switch language {
        case "Python": "def greet(name):\n    print(f\"Hello, {name}!\")\n\ngreet(\"NEXUS\")"
        case "JavaScript", "TypeScript": "function greet(name) {\n  console.log(`Hello, ${name}!`);\n}\n\ngreet('NEXUS');"
        case "Swift": "func greet(_ name: String) {\n    print(\"Hello, \\(name)!\")\n}\n\ngreet(\"NEXUS\")"
        case "Go": "package main\nimport \"fmt\"\nfunc main() { fmt.Println(\"Hello, NEXUS!\") }"
        case "Rust": "fn main() {\n    println!(\"Hello, NEXUS!\");\n}"
        case "C#": "using System;\nConsole.WriteLine(\"Hello, NEXUS!\");"
        case "C", "C++": "#include <stdio.h>\nint main(void) {\n    printf(\"Hello, NEXUS!\\n\");\n    return 0;\n}"
        case "Java": "class Main {\n  public static void main(String[] args) {\n    System.out.println(\"Hello, NEXUS!\");\n  }\n}"
        case "R": "greet <- function(name) {\n  print(paste('Hello,', name))\n}\ngreet('NEXUS')"
        case "PHP": "<?php\necho 'Hello, NEXUS!';\n?>"
        case "SQL": "SELECT 'Hello, NEXUS!' AS message;"
        case "HTML": "<!doctype html>\n<html><body><h1>Hello, NEXUS!</h1></body></html>"
        default: "// Hello, NEXUS!\n// \(language) のコードを入力してください。"
        }
    }
}

enum NexusCodeConverter {
    static func convert(_ code: String, from source: String, to target: String) -> String {
        if source == target { return code }
        if source == "Python" && ["JavaScript", "TypeScript"].contains(target) {
            var result = code.replacingOccurrences(of: "print(", with: "console.log(")
                .replacingOccurrences(of: "True", with: "true").replacingOccurrences(of: "False", with: "false")
                .replacingOccurrences(of: "None", with: "null")
            result = result.replacingOccurrences(of: #"^\s*def\s+(\w+)\s*\((.*?)\)\s*:"#, with: "function $1($2) {", options: .regularExpression)
            result = result.replacingOccurrences(of: #"^\s*return\s+"#, with: "return ", options: .regularExpression)
            result = result.replacingOccurrences(of: #"^\s*if\s+(.+):$"#, with: "if ($1) {", options: .regularExpression)
            return result + "\n\n// TODO: Python固有のインデント・型・例外・ライブラリ呼び出しを確認してください。"
        }
        if ["JavaScript", "TypeScript"].contains(source) && target == "Python" {
            var result = code.replacingOccurrences(of: "console.log(", with: "print(")
                .replacingOccurrences(of: "const ", with: "").replacingOccurrences(of: "let ", with: "")
                .replacingOccurrences(of: "var ", with: "").replacingOccurrences(of: "true", with: "True")
                .replacingOccurrences(of: "false", with: "False").replacingOccurrences(of: "null", with: "None")
            result = result.replacingOccurrences(of: #"\);"#, with: ")", options: .regularExpression)
            return result + "\n\n# TODO: 波括弧・セミコロン・非同期処理・型注釈を確認してください。"
        }
        if target == "Swift" {
            if source == "Python" {
                let result = code.replacingOccurrences(of: "print(", with: "print(")
                    .replacingOccurrences(of: "True", with: "true").replacingOccurrences(of: "False", with: "false")
                    .replacingOccurrences(of: "None", with: "nil")
                return result + "\n\n// TODO: 関数定義、インデント、型、例外処理をSwift構文に調整してください。"
            }
            if source == "JavaScript" { return code.replacingOccurrences(of: "const ", with: "let ").replacingOccurrences(of: "console.log(", with: "print(") + "\n\n// TODO: JavaScriptの動的型・Promise・オブジェクトをSwiftの型へ置き換えてください。" }
        }
        return "// NEXUS CodeBridge: \(source) → \(target)\n// この組み合わせの自動変換テンプレートは限定的です。\n// 元コードを参考として保持します。\n\n\(code)\n\n// TODO: 構文、型、標準ライブラリ、エラー処理を手動で移植してください。"
    }
}

// MARK: - Mojibake lab

struct GarblerView: View {
    @State private var mode = "日本語・文字化け風"
    @State private var input = "NEXUS SUPER3.1"
    @State private var output = ""
    private let modes = ["日本語・文字化け風", "カオス記号ノイズ", "UTF-8 Base64（復元可能）"]
    var body: some View {
        NexusCard("NEXUS 文字化けラボ", symbol: "character.textbox") {
            Picker("変換モード", selection: $mode) { ForEach(modes, id: \.self) { Text($0) } }.pickerStyle(.menu)
            Text("入力テキスト").font(.caption.bold())
            TextEditor(text: $input).frame(minHeight: 140).padding(5).background(.black.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
            HStack {
                NexusActionButton(title: "変換", symbol: "bolt.fill") { convert() }
                NexusActionButton(title: "元に戻す", symbol: "arrow.uturn.backward") { restore() }
                NexusActionButton(title: "出力を入力へ", symbol: "arrow.down") { input = output }
                NexusActionButton(title: "クリア", symbol: "trash") { input = ""; output = "" }
            }
            Text("変換結果").font(.caption.bold())
            TextEditor(text: $output).frame(minHeight: 140).padding(5).background(.black.opacity(0.12), in: RoundedRectangle(cornerRadius: 10)).textSelection(.enabled)
            if !output.isEmpty { ShareLink(item: output) { Label("結果を共有", systemImage: "square.and.arrow.up") }.buttonStyle(.bordered) }
            Text("入力内容はこの画面内で処理し、外部には送信しません。")
                .font(.caption2).foregroundStyle(.secondary)
        }
    }
    private func convert() {
        switch mode {
        case "UTF-8 Base64（復元可能）": output = Data(input.utf8).base64EncodedString()
        case "カオス記号ノイズ":
            let symbols = ["※", "§", "¤", "∴", "〆", "░", "▒", "▓", "Ω", "Ж", "₪", "⟁"]
            output = input.enumerated().map { index, character in String(character) + (index % 2 == 0 ? symbols[index % symbols.count] : "") }.joined()
        default:
            let noise = ["縺", "譁", "蜿", "蟄", "繧", "蜈", "邱", "驥", "莠", "譛"]
            output = input.unicodeScalars.enumerated().map { index, scalar in
                if scalar.value < 128 { return String(scalar) }
                return noise[index % noise.count] + noise[(index * 3 + 1) % noise.count]
            }.joined()
        }
    }
    private func restore() {
        guard let data = Data(base64Encoded: output), let text = String(data: data, encoding: .utf8) else { output = "Base64形式の復元可能なデータではありません。"; return }
        input = text; output = text
    }
}

// MARK: - Security and URL report

struct SecurityView: View {
    @EnvironmentObject private var store: NexusStore
    @State private var scanned = false
    @State private var report = "診断前です。ボタンを押すとアプリの設定とローカル保存の概要を確認します。"
    @State private var score = 0
    var body: some View {
        NexusCard("セキュリティ・プライバシー診断", symbol: "shield.lefthalf.filled") {
            HStack(alignment: .center) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(scanned ? "自己診断スコア" : "未診断").font(.caption).foregroundStyle(.secondary)
                    Text(scanned ? "\(score) / 100" : "--").font(.system(size: 36, weight: .light, design: .rounded))
                }
                Spacer()
                Image(systemName: scanned ? (score >= 80 ? "checkmark.shield.fill" : "exclamationmark.shield.fill") : "shield")
                    .font(.system(size: 44)).foregroundStyle(scanned && score < 80 ? .orange : .cyan)
            }
            Button("今すぐチェック") { runScan() }.buttonStyle(.borderedProminent)
            Text(report).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
            if scanned { ShareLink(item: report) { Label("診断レポートを共有", systemImage: "square.and.arrow.up") }.buttonStyle(.bordered) }
            Text("診断はSwiftアプリ内で確認できる設定項目の自己点検です。OS全体・ネットワーク機器・外部サイトの安全性を検査または保証するものではありません。")
                .font(.caption2).foregroundStyle(.secondary)
        }
    }
    private func runScan() {
        var checks: [(Bool, String)] = []
        checks.append((!store.settings.autoWeatherNetwork, "自動外部通信は \(store.settings.autoWeatherNetwork ? "許可" : "停止")"))
        checks.append((store.settings.anonymousCommunication, "通信匿名モードは \(store.settings.anonymousCommunication ? "有効" : "無効")（IP匿名化ではありません）"))
        checks.append((store.settings.screenProtection, "画面保護表示は \(store.settings.screenProtection ? "有効" : "無効")"))
        checks.append((true, "データはNEXUSアプリのUserDefaults領域に保存"))
        checks.append((true, "診断レポートにはメモ・Todo本文を含めない"))
        checks.append((true, "外部サイトリンクはHTTPSのみ許可"))
        let good = checks.filter { $0.0 }.count
        score = Int(Double(good) / Double(checks.count) * 100)
        report = checks.map { "[\($0.0 ? "OK" : "確認")] \($0.1)" }.joined(separator: "\n")
            + "\n\n診断日時：\(Date().formatted(date: .long, time: .standard))\n保存件数：メモ \(store.notes.count)件／Todo日数 \(store.todos.count)日／予定 \(store.events.count)件／掲示板 \(store.boardEntries.count)件"
        scanned = true
    }
}

struct URLCheckerView: View {
    @State private var input = "https://example.com"
    @State private var result: NexusURLReport?
    var body: some View {
        NexusCard("URLチェッカー", symbol: "link.badge.plus") {
            TextField("検査したいURL", text: $input).textFieldStyle(.roundedBorder).textInputAutocapitalization(.never).autocorrectionDisabled()
            Button("ローカル検査") { result = NexusURLChecker.inspect(input) }.buttonStyle(.borderedProminent)
            if let result {
                HStack {
                    VStack(alignment: .leading) { Text("形式上の注意度").font(.caption).foregroundStyle(.secondary); Text("\(result.score) / 100").font(.system(size: 36, weight: .light)) }
                    Spacer(); Text(result.level).font(.headline).foregroundStyle(result.score >= 55 ? .red : result.score >= 25 ? .orange : .green)
                }
                Text("ホスト名：\(result.host.isEmpty ? "取得できません" : result.host)").font(.subheadline)
                ForEach(Array(result.findings.enumerated()), id: \.offset) { _, finding in Label(finding, systemImage: "exclamationmark.circle").font(.caption) }
                if !result.host.isEmpty { ShareLink(item: result.host) { Label("ホスト名を共有", systemImage: "doc.on.doc") }.buttonStyle(.bordered) }
            }
            Text("URL構文とよくある不審な特徴だけを端末内で確認します。対象URLへの通信や自動アクセスは行いません。安全性を保証するものではありません。")
                .font(.caption2).foregroundStyle(.secondary)
        }
    }
}

// MARK: - Privacy, backups and settings

struct PrivacyView: View {
    @EnvironmentObject private var store: NexusStore
    @State private var confirmClear = false
    var body: some View {
        VStack(spacing: 16) {
            NexusCard("プライバシー強化", symbol: "hand.raised.fill") {
                Toggle("天気の自動取得を許可", isOn: $store.settings.autoWeatherNetwork)
                Toggle("画面保護モード", isOn: $store.settings.screenProtection)
                Toggle("通信匿名モード", isOn: $store.settings.anonymousCommunication)
                Toggle("アプリ外へ移動したときにぼかす設定", isOn: $store.settings.blurOnBackground)
                Text("通信匿名モードはNEXUSからの外部リンク起動やAPI通信を止めるアプリ内設定です。VPNやIPアドレスの匿名化機能ではありません。")
                    .font(.caption).foregroundStyle(.secondary)
                Text("画面保護モードはNEXUS画面を隠すだけです。OSのロックや他アプリのスクリーンショット防止を行うものではありません。")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            NexusCard("アプリ内データの消去", symbol: "trash") {
                Text("メモ、Todo、予定、掲示板、カスタムリンク、設定を削除します。先にバックアップを作成してください。")
                    .font(.caption).foregroundStyle(.secondary)
                Button("NEXUSの保存データを消去", role: .destructive) { confirmClear = true }.buttonStyle(.bordered)
            }
        }
        .confirmationDialog("NEXUSの保存データをすべて削除しますか？", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("すべて削除", role: .destructive) { store.clearAllData() }
            Button("キャンセル", role: .cancel) { }
        } message: { Text("削除したデータはバックアップがない限り復元できません。") }
    }
}

struct BackupView: View {
    @EnvironmentObject private var store: NexusStore
    @State private var passphrase = ""
    @State private var useEncryption = true
    @State private var exportPresented = false
    @State private var importPresented = false
    @State private var document = NexusFileDocument()
    @State private var status = "バックアップは外部送信されません。保存先はユーザーが選択します。"
    var body: some View {
        NexusCard("設定・メモの一括バックアップ", symbol: "externaldrive.fill.badge.clock") {
            Toggle("AES-GCM暗号化バックアップ", isOn: $useEncryption)
            if useEncryption {
                SecureField("バックアップ用パスフレーズ（12文字以上）", text: $passphrase).textFieldStyle(.roundedBorder)
                Text("パスフレーズはNEXUSに保存しません。忘れると復元できません。暗号化はAES-256-GCMを使用します。")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            HStack {
                Button("エクスポート") { prepareExport() }.buttonStyle(.borderedProminent)
                Button("インポート") { importPresented = true }.buttonStyle(.bordered)
            }
            Text(status).font(.caption).foregroundStyle(.secondary)
            Text("対象：設定、メモ、Todo、予定、掲示板記録、カスタムリンク。")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .fileExporter(isPresented: $exportPresented, document: document, contentType: .data, defaultFilename: "NEXUS_Backup_\(NexusStore.dateKey(Date()))") { result in
            switch result { case .success(let url): status = "保存しました：\(url.lastPathComponent)"; case .failure(let error): status = "保存失敗：\(error.localizedDescription)" }
        }
        .fileImporter(isPresented: $importPresented, allowedContentTypes: [.data, .json], allowsMultipleSelection: false) { result in
            do {
                guard let url = try result.get().first else { return }
                let granted = url.startAccessingSecurityScopedResource(); defer { if granted { url.stopAccessingSecurityScopedResource() } }
                var data = try Data(contentsOf: url)
                if data.starts(with: Data("NEXUSAES1".utf8)) {
                    data = try NexusBackupCrypto.decrypt(data, passphrase: passphrase)
                }
                try store.restoreBackup(data)
                status = "バックアップを復元しました。"
            } catch { status = "復元できません：\(error.localizedDescription)" }
        }
    }
    private func prepareExport() {
        do {
            let clear = try store.makeBackupData()
            let data: Data
            if useEncryption { data = try NexusBackupCrypto.encrypt(clear, passphrase: passphrase) } else { data = clear }
            document = NexusFileDocument(data: data); exportPresented = true; status = "保存先を選択してください。"
        } catch { status = "バックアップを作成できません：\(error.localizedDescription)" }
    }
}

struct SettingsView: View {
    @EnvironmentObject private var store: NexusStore
    private let accents = ["#37D8FF", "#A78BFA", "#FF69D4", "#69F0AE", "#FFB347", "#FF6B6B", "#FFFFFF"]
    private let wallpapers = ["落ち着いた背景（既定）", "CPC部（内蔵背景画像）", "宇宙空間", "深宇宙ブルー", "ネオン・グリッド"]
    var body: some View {
        VStack(spacing: 16) {
            NexusCard("表示・外観", symbol: "paintpalette") {
                Toggle("ダークテーマ", isOn: $store.settings.isDark)
                Picker("背景スタイル", selection: $store.settings.wallpaper) { ForEach(wallpapers, id: \.self) { Text($0) } }.pickerStyle(.menu)
                Text("アクセントカラー").font(.caption.bold())
                HStack {
                    ForEach(accents, id: \.self) { hex in
                        Button { store.settings.accentHex = hex } label: {
                            Circle().fill(Color(hex: hex)).frame(width: 28, height: 28)
                                .overlay(Circle().stroke(store.settings.accentHex == hex ? .primary : .clear, lineWidth: 2))
                        }.buttonStyle(.plain)
                    }
                }
                HStack { Text("アイコンサイズ"); Slider(value: $store.settings.iconSize, in: 56...120); Text("\(Int(store.settings.iconSize))") }
                HStack { Text("ガラスのぼかし強度"); Slider(value: $store.settings.glassBlur, in: 0...30); Text("\(Int(store.settings.glassBlur))") }
            }
            NexusCard("表示する機能", symbol: "square.grid.2x2") {
                ForEach(NexusTab.allCases) { tab in
                    Toggle(tab.title, isOn: Binding(get: { !store.settings.hiddenTabs.contains(tab.rawValue) }, set: { visible in
                        if visible { store.settings.hiddenTabs.removeAll { $0 == tab.rawValue } }
                        else { store.settings.hiddenTabs.append(tab.rawValue) }
                    }))
                }
            }
            NexusCard("プライバシー・バックアップ", symbol: "lock.shield") {
                Button("プライバシー設定を開く") { store.selectedTab = .privacy }.buttonStyle(.bordered)
                Button("バックアップ・復元を開く") { store.selectedTab = .backup }.buttonStyle(.bordered)
            }
        }
    }
}

// MARK: - Bedtime self-control

struct SleepRestrictionView: View {
    @EnvironmentObject private var store: NexusStore
    @State private var startTime = Calendar.current.date(from: DateComponents(hour: 22, minute: 0)) ?? Date()
    @State private var endTime = Calendar.current.date(from: DateComponents(hour: 7, minute: 0)) ?? Date()
    @State private var status = "制限はオフです。"
    var body: some View {
        NexusCard("おやすみ制限", symbol: "moon.zzz.fill") {
            Toggle("おやすみ時間の制限を有効にする", isOn: $store.settings.sleepEnabled)
            DatePicker("開始時刻", selection: $startTime, displayedComponents: .hourAndMinute)
            DatePicker("終了時刻", selection: $endTime, displayedComponents: .hourAndMinute)
            Button("設定を保存") {
                store.settings.sleepStart = Self.timeString(startTime)
                store.settings.sleepEnd = Self.timeString(endTime)
                status = store.settings.sleepEnabled ? "\(store.settings.sleepStart)〜\(store.settings.sleepEnd) の制限を有効にしました。" : "制限をオフにしました。"
            }.buttonStyle(.borderedProminent)
            Text(status).font(.caption).foregroundStyle(.secondary)
            Text("指定時間帯にNEXUS画面へ休憩オーバーレイを表示するセルフコントロール機能です。OS全体の利用制限や保護者制限ではありません。")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .onAppear {
            startTime = Self.date(store.settings.sleepStart, fallback: 22)
            endTime = Self.date(store.settings.sleepEnd, fallback: 7)
        }
    }
    private static func timeString(_ date: Date) -> String {
        let formatter = DateFormatter(); formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
    private static func date(_ string: String, fallback: Int) -> Date {
        let parts = string.split(separator: ":").compactMap { Int($0) }
        return Calendar.current.date(from: DateComponents(hour: parts.first ?? fallback, minute: parts.count > 1 ? parts[1] : 0)) ?? Date()
    }
}

struct SleepLockOverlay: View {
    var onBreak: () -> Void
    var onSettings: () -> Void
    var body: some View {
        ZStack {
            Color.black.opacity(0.96).ignoresSafeArea()
            VStack(spacing: 16) {
                Image(systemName: "moon.stars.fill").font(.system(size: 54)).foregroundStyle(.cyan)
                Text("おやすみ制限中").font(.largeTitle.bold())
                Text("設定した休憩時間です。画面から離れて、目と体を休めましょう。")
                    .multilineTextAlignment(.center).foregroundStyle(.white.opacity(0.78))
                Button("5分だけ一時解除", action: onBreak).buttonStyle(.borderedProminent)
                Button("設定を見直す", action: onSettings).buttonStyle(.bordered)
                Text("この機能は自主的な休憩を助けるもので、端末全体をロックしません。")
                    .font(.caption2).foregroundStyle(.white.opacity(0.55))
            }.padding(28).frame(maxWidth: 420)
        }.zIndex(999)
    }
}

// MARK: - Developer mode (session scoped, allow-listed commands only)

struct DeveloperView: View {
    @EnvironmentObject private var store: NexusStore
    @State private var report = "開発者モードを有効にすると診断を実行できます。"
    @State private var command = "help"
    @State private var output = "NEXUS ADMIN SHELL — 許可リスト方式"
    @State private var showAdminConfirm = false
    @State private var showClearConfirm = false
    var body: some View {
        VStack(spacing: 16) {
            NexusCard("開発者モード", symbol: "wrench.and.screwdriver.fill") {
                Text("開発者向けのローカル診断とアプリ管理です。任意のコード実行、外部シェル、OS全体の設定変更は行いません。")
                    .font(.caption).foregroundStyle(.secondary)
                HStack {
                    Button(store.isDeveloperEnabled ? "開発者モードを停止" : "開発者モードを有効化") {
                        store.isDeveloperEnabled.toggle(); if !store.isDeveloperEnabled { store.isAdminEnabled = false }
                    }.buttonStyle(.borderedProminent)
                    Text(store.isDeveloperEnabled ? "有効" : "停止中").font(.caption.bold()).foregroundStyle(store.isDeveloperEnabled ? .green : .secondary)
                }
                if store.isDeveloperEnabled {
                    HStack {
                        Button("診断を実行") { runDiagnostic() }.buttonStyle(.bordered)
                        Button("管理者権限を有効化") { showAdminConfirm = true }.buttonStyle(.bordered)
                    }
                    Text(report).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                    ShareLink(item: report) { Label("診断レポートを共有", systemImage: "square.and.arrow.up") }.buttonStyle(.bordered)
                }
            }
            if store.isDeveloperEnabled && store.isAdminEnabled {
                NexusCard("NEXUS ADMINISTRATOR", symbol: "lock.open.fill") {
                    Text("ADMIN ACTIVE · THIS SESSION").font(.caption.bold()).foregroundStyle(.green)
                    HStack {
                        TextField("許可コマンド", text: $command).textFieldStyle(.roundedBorder).onSubmit(runCommand)
                        Button("実行", action: runCommand).buttonStyle(.borderedProminent)
                    }
                    Text(output).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                    Text("コマンド：help / scan / export / clear / theme dark|light / anon on|off / network on|off")
                        .font(.caption2).foregroundStyle(.secondary)
                    Button("管理者権限を解除") { store.isAdminEnabled = false }.buttonStyle(.bordered)
                }
            }
        }
        .confirmationDialog("管理者権限をこのセッションだけ有効にしますか？", isPresented: $showAdminConfirm) {
            Button("有効化") { store.isAdminEnabled = true }
            Button("キャンセル", role: .cancel) { }
        } message: { Text("保存データの消去・設定の強制変更を含む操作が可能になります。") }
    }

    private func runDiagnostic() {
        let keys = ["nexus.settings", "nexus.notes", "nexus.todos", "nexus.events", "nexus.board", "nexus.links", "nexus.drawing.elements"]
        report = "NEXUS Swift diagnostic\n日時：\(Date().formatted())\nDeveloper=ON / Admin=\(store.isAdminEnabled ? "ON" : "OFF")\n"
            + "保存キー（既知）：\(keys.joined(separator: ", "))\n"
            + "メモ：\(store.notes.count)件 / Todo日付：\(store.todos.count) / 予定：\(store.events.count)件 / 掲示板：\(store.boardEntries.count)件\n"
            + "自動天気通信：\(store.settings.autoWeatherNetwork) / 通信匿名モード：\(store.settings.anonymousCommunication) / 画面保護：\(store.settings.screenProtection)\n"
            + "任意コード実行：なし / 診断値の外部送信：なし"
    }
    private func runCommand() {
        let parts = command.split(separator: " ", maxSplits: 1).map(String.init)
        let cmd = parts.first?.lowercased() ?? ""
        let arg = parts.count > 1 ? parts[1].lowercased() : ""
        switch cmd {
        case "help": output = "help / scan / export / clear / theme dark|light / anon on|off / network on|off"
        case "scan": runDiagnostic(); output = report
        case "export":
            do { output = "バックアップデータを生成しました（\((try store.makeBackupData()).count) bytes）。バックアップ画面でファイル保存してください。" }
            catch { output = "エクスポート失敗：\(error.localizedDescription)" }
        case "clear": output = "安全のため、データ消去はプライバシー設定画面の確認操作から実行してください。"
        case "theme":
            if arg == "dark" { store.settings.isDark = true; output = "theme=dark" }
            else if arg == "light" { store.settings.isDark = false; output = "theme=light" }
            else { output = "使い方：theme dark|light" }
        case "anon":
            if arg == "on" || arg == "off" { store.settings.anonymousCommunication = arg == "on"; output = "通信匿名モード=\(arg)（VPNではありません）" }
            else { output = "使い方：anon on|off" }
        case "network":
            if arg == "on" || arg == "off" { store.settings.autoWeatherNetwork = arg == "on"; output = "自動天気通信=\(arg)" }
            else { output = "使い方：network on|off" }
        default: output = "不明なコマンドです。helpを入力してください。"
        }
        command = ""
    }
}

// MARK: - Mini-games

struct MiniGamesView: View {
    @State private var mode = "ターゲット"
    @State private var score = 0
    @State private var lane = 1
    @State private var target = Int.random(in: 0..<12)
    @State private var snake = [5, 6, 7]
    private let modes = ["ドライブ", "スネーク", "ターゲット"]
    var body: some View {
        NexusCard("ミニゲーム", symbol: "gamecontroller.fill") {
            Picker("ゲーム", selection: $mode) { ForEach(modes, id: \.self) { Text($0) } }.pickerStyle(.segmented)
            HStack { Text("スコア").foregroundStyle(.secondary); Spacer(); Text("\(score)").font(.title.bold().monospacedDigit()) }
            if mode == "ターゲット" {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 4), spacing: 8) {
                    ForEach(0..<12, id: \.self) { index in
                        Button {
                            if index == target { score += 1; target = Int.random(in: 0..<12) } else { score = max(0, score - 1) }
                        } label: {
                            RoundedRectangle(cornerRadius: 12).fill(index == target ? Color.cyan.opacity(0.8) : .white.opacity(0.09))
                                .frame(height: 65).overlay(Image(systemName: index == target ? "scope" : "circle").font(.title2))
                        }.buttonStyle(.plain)
                    }
                }
                Text("光っているターゲットをタップしてください。").font(.caption).foregroundStyle(.secondary)
            } else if mode == "ドライブ" {
                VStack(spacing: 10) {
                    HStack { Spacer(); Image(systemName: "car.side.fill").font(.system(size: 38)).foregroundStyle(.cyan).offset(x: CGFloat(lane - 1) * 55); Spacer() }
                    Text("レーン \(lane + 1) / 3").font(.caption).foregroundStyle(.secondary)
                    HStack { Button("← 左") { lane = max(0, lane - 1); score += 1 }; Spacer(); Button("右 →") { lane = min(2, lane + 1); score += 1 } }
                }.padding(.vertical, 22)
                Text("左右に移動してコースを走る簡易ドライブモードです。").font(.caption).foregroundStyle(.secondary)
            } else {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 4), count: 6), spacing: 4) {
                    ForEach(0..<36, id: \.self) { index in
                        RoundedRectangle(cornerRadius: 5).fill(snake.contains(index) ? Color.green : .white.opacity(0.08)).frame(height: 31)
                    }
                }
                HStack {
                    Button("←") { moveSnake(-1) }; Button("↑") { moveSnake(-6) }; Button("↓") { moveSnake(6) }; Button("→") { moveSnake(1) }
                }.buttonStyle(.bordered)
                Text("方向ボタンでスネークを移動させる簡易グリッド版です。").font(.caption).foregroundStyle(.secondary)
            }
            Button("ゲームをリセット") { score = 0; lane = 1; snake = [5, 6, 7]; target = Int.random(in: 0..<12) }.buttonStyle(.bordered)
        }
    }
    private func moveSnake(_ delta: Int) {
        guard let head = snake.last else { return }
        let next = (head + delta + 36) % 36
        if snake.contains(next) { score = 0; snake = [5, 6, 7]; return }
        snake.append(next); if snake.count > 5 { snake.removeFirst() }; score += 1
    }
}


// MARK: - NEXUS Assistant+ local command router

struct NexusAssistantView: View {
    @EnvironmentObject private var store: NexusStore
    @Environment(\.openURL) private var openURL
    @State private var input = ""
    @State private var reply = "こんにちは！メモ・Todo・予定・天気・翻訳などを手伝います。例：「メモ: アイデアを書く」「Todo: 明日の準備」「予定 2026-11-08 14:00 歯医者」"
    @State private var history: [String] = []

    var body: some View {
        VStack(spacing: 16) {
            NexusCard("NEXUS Assistant+", symbol: "sparkles") {
                Text(reply).font(.subheadline).frame(maxWidth: .infinity, alignment: .leading)
                    .padding(12).background(.black.opacity(0.18), in: RoundedRectangle(cornerRadius: 12))
                HStack {
                    TextField("依頼やコマンドを入力", text: $input).textFieldStyle(.roundedBorder).onSubmit { execute() }
                    Button("実行", action: execute).buttonStyle(.borderedProminent)
                }
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 112))], spacing: 7) {
                    quick("天気", "cloud.sun.fill") { store.selectedTab = .weather }
                    quick("予定", "calendar") { store.selectedTab = .calendar }
                    quick("Todo", "checklist") { store.selectedTab = .todo }
                    quick("メモ", "note.text") { store.selectedTab = .memo }
                    quick("翻訳", "translate") { store.selectedTab = .translate }
                    quick("文字化け", "character.textbox") { store.selectedTab = .garbler }
                }
            }
            NexusCard("AI・Webへの引き継ぎ", symbol: "arrow.up.right.square") {
                Text("自由な質問や最新情報は外部サービスで確認できます。ボタンを押すと外部サイトが開きます。入力文は自動送信しません。")
                    .font(.caption).foregroundStyle(.secondary)
                HStack {
                    Button("ChatGPT") { openExternal("https://chatgpt.com") }
                    Button("Gemini") { openExternal("https://gemini.google.com") }
                    Button("Web検索") { openExternal("https://www.google.com/search?q=" + encode(input)) }
                }.buttonStyle(.bordered)
            }
            if !history.isEmpty {
                NexusCard("このセッションの操作履歴", symbol: "clock.arrow.circlepath") {
                    ForEach(history, id: \.self) { Text($0).font(.caption).foregroundStyle(.secondary) }
                }
            }
        }
    }

    @ViewBuilder private func quick(_ title: String, _ symbol: String, action: @escaping () -> Void) -> some View {
        Button(action: action) { Label(title, systemImage: symbol).frame(maxWidth: .infinity).padding(8).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 9)) }.buttonStyle(.plain)
    }

    private func execute() {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        let lower = text.lowercased()
        if lower.hasPrefix("メモ:") || lower.hasPrefix("メモ：") {
            let body = String(text.dropFirst(3)).trimmingCharacters(in: .whitespacesAndNewlines)
            store.addNote(title: "Assistant+からのメモ", body: body)
            reply = "メモを端末内に保存しました。"
            store.selectedTab = .memo
        } else if lower.hasPrefix("todo:") || lower.hasPrefix("todo：") || lower.hasPrefix("todo ") {
            let body = text.replacingOccurrences(of: #"(?i)^todo[:： ]*"#, with: "", options: .regularExpression)
            store.addTodo(body, on: Date()); reply = "今日のTodoに追加しました。"; store.selectedTab = .todo
        } else if text.hasPrefix("予定 ") || text.hasPrefix("予定　") {
            let body = String(text.dropFirst(2)).trimmingCharacters(in: .whitespacesAndNewlines)
            let formatter = DateFormatter(); formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.timeZone = .current; formatter.dateFormat = "yyyy-MM-dd HH:mm"
            let parts = body.split(separator: " ", maxSplits: 2).map(String.init)
            if parts.count >= 3, let date = formatter.date(from: parts[0] + " " + parts[1]) {
                store.addEvent(title: parts[2], date: date); reply = "予定「\(parts[2])」を追加しました。"
            } else { reply = "予定の形式は「予定 YYYY-MM-DD HH:mm 内容」です。" }
            store.selectedTab = .calendar
        } else if lower.contains("天気") {
            store.selectedTab = .weather; reply = "天気画面を開きました。都道府県を選び、更新ボタンで予報を取得してください。"
        } else if lower.hasPrefix("翻訳:") || lower.hasPrefix("翻訳：") {
            store.selectedTab = .translate; reply = "翻訳画面へ移動しました。翻訳先を選び、外部サービスを開く操作を行ってください。入力文は自動送信されません。"
        } else if lower.contains("ニュース") {
            store.selectedTab = .news; reply = "ニュースリンクを開きました。最新記事は各提供元で確認してください。"
        } else if lower.contains("セキュリティ") || lower.contains("診断") {
            store.selectedTab = .security; reply = "セキュリティ診断画面を開きました。"
        } else if lower.contains("バックアップ") {
            store.selectedTab = .backup; reply = "バックアップ画面を開きました。"
        } else {
            reply = "ローカル操作で処理できる指示ではありません。ChatGPT・Gemini・Web検索から外部サービスへ引き継げます。"
        }
        history.insert("\(Date().formatted(date: .omitted, time: .shortened))  \(text)", at: 0)
        history = Array(history.prefix(8)); input = ""
    }
    private func openExternal(_ string: String) {
        guard !store.settings.anonymousCommunication else { reply = "通信匿名モード中は外部サイトを開けません。"; return }
        guard let url = URL(string: string), url.scheme == "https" else { return }
        openURL(url)
    }
    private func encode(_ value: String) -> String { value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? value }
}

// MARK: - Terms and attribution carried from the HTML release

struct AboutView: View {
    var body: some View {
        VStack(spacing: 14) {
            NexusCard("利用規約", symbol: "doc.text") {
                Text("制定日：2026年10月25日").font(.caption).foregroundStyle(.secondary)
                DisclosureGroup("第1条（提供内容）") {
                    Text("本ツールは、検索、ブックマーク、時計、天気、メモ、Todo、予定表、翻訳、音楽・BGM、お絵かき、ゲームなどの機能をひとつの画面で提供します。機能は予告なく追加・変更・終了することがあります。")
                }
                DisclosureGroup("第2条（利用範囲）") {
                    Text("本ツールは、個人の非営利目的での利用を想定しています。天気データの提供元の利用条件を確認し、商用利用は行わないでください。")
                }
                DisclosureGroup("第3条（禁止事項）") {
                    Text("法令または公序良俗に反する行為、他者の著作権・プライバシーその他の権利を侵害する行為、本ツールの無断での再配布・販売または改変物の公開、外部サービスに過度な負荷をかける行為、他者になりすます行為、不正アクセスその他運営を妨げる行為を禁止します。")
                    Text("本ツールのプログラム、画面デザイン、文章の著作権は、GitHubアカウント『kinokokenatto』に帰属します。")
                }
                DisclosureGroup("第4条（データの取り扱い）") {
                    Text("メモ、Todo、予定、設定、描画などのデータは、このアプリの端末内保存領域に保存されます。本アプリ自身は、これらのデータを制作者や第三者のサーバーへ送信しません。")
                    Text("アプリ内の保存データは通常時に暗号化されません。共有端末ではパスワード・カード番号などの秘密情報を保存しないでください。必要なデータはバックアップしてください。")
                    Text("天気情報は、利用者が更新操作をした場合、または自動取得を許可した場合にOpen-Meteoへ直接通信します。このときIPアドレスや通信に必要な情報が提供元に伝わります。")
                    Text("翻訳サイトのボタンを押すと、入力した文章が選択した外部サービスへ送られます。パスワードなどの秘密情報は入力しないでください。")
                }
                DisclosureGroup("第5条（外部サービス・リンク）") {
                    Text("本ツールから開く外部サイト・サービスは各提供者のものです。その内容、利用条件、個人情報の取り扱いは各提供者の定めに従います。本ツールと各社との間に提携・後援・推奨などの関係はありません。")
                }
                DisclosureGroup("第6条（情報の正確性）") {
                    Text("天気、ニュースなどの表示内容は参考情報であり、正確性・完全性・即時性を保証しません。")
                }
                DisclosureGroup("第7条（免責）") {
                    Text("本ツールは現状のまま提供され、動作、安全性、特定の目的への適合性を保証しません。本ツールの利用または利用できないことにより生じた損害（データの消失などを含みます）について、法令で許される範囲で制作者は責任を負いません。")
                }
                DisclosureGroup("第8条（規約の変更）") {
                    Text("本規約は必要に応じて変更することがあります。変更後の規約は、本ツール上に掲示した時点から効力を生じます。")
                }
                DisclosureGroup("第9条（準拠法）") { Text("本規約は日本法に準拠します。") }
            }
            NexusCard("著作権・出典", symbol: "c.circle") {
                Text("本ツールのプログラム、画面デザイン、文章の著作権は、GitHubアカウント『kinokokenatto』に帰属します。個人利用を超える複製・再配布・改変しての公開は、制作者の許可なく行えません。利用者が作成したメモ・予定・描画などの権利は、利用者に帰属します。")
                Text("Google、Microsoft、YouTube、DeepL、Bing、ChatGPT、Claude、GitHubなどの名称・ロゴは各社の商標または登録商標です。本ツールは各社と提携・後援・承認の関係にありません。")
                Text("天気：Weather data by Open-Meteo.com（CC BY 4.0）。ニュース：各報道機関の記事へのリンクのみを掲載。内蔵BGM：このアプリ内で生成する音声です。")
                Text("Open-Meteo利用条件：https://open-meteo.com/en/terms")
                Text("Creative Commons BY 4.0：https://creativecommons.org/licenses/by/4.0/")
            }
            NexusCard("Swift版について", symbol: "swift") {
                Text("このビルドは、提供されたNEXUS SUPER3.1 HTML版の機能構成をSwiftUIネイティブアプリとして再実装したものです。HTML、CSS、JavaScript、WKWebViewは使用していません。")
                Text("一部の機能（翻訳、ニュース、外部AI）は提供元のアプリ／Webページを開く方式です。CodeBridgeは基本的な変換パターンに限定され、完全なコンパイラではありません。")
            }
        }
    }
}

#endif
