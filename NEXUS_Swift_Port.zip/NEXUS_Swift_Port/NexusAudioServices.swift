#if canImport(SwiftUI)
import Foundation
import AVFoundation
import SwiftUI

@MainActor
final class NexusProceduralAudio: ObservableObject {
    @Published private(set) var isPlaying = false
    @Published var volume: Double = 0.65 { didSet { player?.volume = Float(volume) } }
    @Published var selectedTrack = "Cosmic Ambient"
    let tracks = ["Cosmic Ambient", "Neon Pulse", "Soft Piano", "Digital Rain"]
    private var player: AVAudioPlayer?

    func play() {
        do {
            let data = makeLoop(track: selectedTrack)
            let newPlayer = try AVAudioPlayer(data: data)
            newPlayer.numberOfLoops = -1
            newPlayer.volume = Float(volume)
            newPlayer.prepareToPlay()
            newPlayer.play()
            player?.stop()
            player = newPlayer
            isPlaying = true
        } catch {
            isPlaying = false
        }
    }
    func stop() { player?.stop(); player = nil; isPlaying = false }

    private func makeLoop(track: String) -> Data {
        let sampleRate = 22_050
        let seconds = 8.0
        let sampleCount = Int(Double(sampleRate) * seconds)
        let noteSets: [[Double]] = switch track {
        case "Neon Pulse": [[110, 164.81, 220, 164.81], [329.63, 261.63, 392, 329.63]]
        case "Soft Piano": [[261.63, 329.63, 392, 329.63], [220, 261.63, 329.63, 261.63]]
        case "Digital Rain": [[146.83, 220, 293.66, 220], [196, 246.94, 293.66, 246.94]]
        default: [[110, 164.81, 220, 329.63], [130.81, 196, 261.63, 392]]
        }
        var pcm = Data(capacity: sampleCount * 2)
        for i in 0..<sampleCount {
            let t = Double(i) / Double(sampleRate)
            let bar = Int(t / 2.0) % 4
            let chord = noteSets[bar % noteSets.count]
            let local = t.truncatingRemainder(dividingBy: 2.0)
            let envelope = min(1.0, local / 0.12) * min(1.0, (2.0 - local) / 0.25)
            var sample = 0.0
            for (n, frequency) in chord.enumerated() {
                let amplitude = n == 0 ? 0.17 : 0.07
                let phase = 2 * Double.pi * frequency * t
                sample += sin(phase) * amplitude
                if track == "Digital Rain" { sample += sin(phase * 2.01) * 0.018 }
            }
            if track == "Neon Pulse" { sample *= 0.7 + 0.3 * sin(2 * Double.pi * 2 * t) }
            let value = Int16(max(-1, min(1, sample * envelope)) * 30_000)
            var little = value.littleEndian
            withUnsafeBytes(of: &little) { pcm.append(contentsOf: $0) }
        }
        var header = Data()
        func append<T: FixedWidthInteger>(_ value: T) { var v = value.littleEndian; withUnsafeBytes(of: &v) { header.append(contentsOf: $0) } }
        header.append(contentsOf: Array("RIFF".utf8)); append(UInt32(36 + pcm.count)); header.append(contentsOf: Array("WAVEfmt ".utf8))
        append(UInt32(16)); append(UInt16(1)); append(UInt16(1)); append(UInt32(sampleRate)); append(UInt32(sampleRate * 2)); append(UInt16(2)); append(UInt16(16))
        header.append(contentsOf: Array("data".utf8)); append(UInt32(pcm.count)); header.append(pcm)
        return header
    }
}

@MainActor
final class NexusFileAudioPlayer: ObservableObject {
    @Published private(set) var isPlaying = false
    @Published private(set) var title = "ファイル未選択"
    @Published private(set) var duration: TimeInterval = 0
    @Published private(set) var currentTime: TimeInterval = 0
    @Published var volume: Double = 0.8 { didSet { player?.volume = Float(volume) } }
    private var player: AVAudioPlayer?
    private var timer: Timer?

    func load(url: URL) throws {
        let granted = url.startAccessingSecurityScopedResource()
        defer { if granted { url.stopAccessingSecurityScopedResource() } }
        let audio = try AVAudioPlayer(contentsOf: url)
        audio.volume = Float(volume)
        audio.prepareToPlay()
        player?.stop(); player = audio
        duration = audio.duration; currentTime = 0
        title = url.lastPathComponent
        isPlaying = false
    }
    func toggle() {
        guard let player else { return }
        if player.isPlaying { player.pause(); isPlaying = false }
        else { player.play(); isPlaying = true; startProgressTimer() }
    }
    func stop() { player?.stop(); player?.currentTime = 0; currentTime = 0; isPlaying = false; timer?.invalidate() }
    func seek(_ value: Double) { player?.currentTime = min(duration, max(0, value)); currentTime = player?.currentTime ?? 0 }
    private func startProgressTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self, let player = self.player else { return }
                self.currentTime = player.currentTime
                if !player.isPlaying { self.isPlaying = false; self.timer?.invalidate() }
            }
        }
    }
}

@MainActor
final class NexusSpeechService: ObservableObject {
    private let synthesizer = AVSpeechSynthesizer()
    func speak(_ text: String, language: String = "ja-JP") {
        synthesizer.stopSpeaking(at: .immediate)
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: language)
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate
        synthesizer.speak(utterance)
    }
    func stop() { synthesizer.stopSpeaking(at: .immediate) }
}

#endif
