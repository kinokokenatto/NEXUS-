#if canImport(SwiftUI)
import SwiftUI
import AVFoundation
import UniformTypeIdentifiers

@main
struct NEXUSApp: App {
    @StateObject private var store = NexusStore()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .preferredColorScheme(store.settings.isDark ? .dark : .light)
        }
    }
}

// MARK: - Root shell

struct ContentView: View {
    @EnvironmentObject private var store: NexusStore
    @Environment(\.openURL) private var openURL
    @State private var showScreenProtection = false
    @State private var sleepPauseUntil: Date?
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        NavigationSplitView {
            List {
                ForEach(["WORKSPACE", "LIVE INFORMATION", "DAILY WORK", "LANGUAGE & CODE", "TOOLS", "SYSTEM"], id: \.self) { group in
                    Section(group) {
                        ForEach(NexusTab.allCases.filter { $0.group == group && !store.settings.hiddenTabs.contains($0.rawValue) }) { tab in
                            Button { store.selectedTab = tab } label: {
                                HStack {
                                    Label(tab.title, systemImage: tab.symbol)
                                    Spacer(minLength: 4)
                                    if store.selectedTab == tab { Image(systemName: "checkmark").font(.caption.bold()).foregroundStyle(Color(hex: store.settings.accentHex)) }
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .listRowBackground(store.selectedTab == tab ? Color(hex: store.settings.accentHex).opacity(0.13) : Color.clear)
                        }
                    }
                }
            }
            .listStyle(.sidebar)
            .navigationTitle("NEXUS SUPER3.1")
            .navigationSplitViewColumnWidth(min: 210, ideal: 245)
        } detail: {
            ZStack {
                NexusBackground(wallpaper: store.settings.wallpaper)
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        HStack(spacing: 10) {
                            VStack(alignment: .leading, spacing: 3) {
                                Text("NEXUS SUPER3.1")
                                    .font(.system(size: 13, weight: .black, design: .rounded))
                                    .tracking(2.2)
                                    .foregroundStyle(Color(hex: store.settings.accentHex))
                                Text(store.selectedTab.title)
                                    .font(.largeTitle.bold())
                            }
                            Spacer()
                            Button { store.selectedTab = .settings } label: {
                                Image(systemName: "slider.horizontal.3").font(.title3).padding(10)
                                    .background(.ultraThinMaterial, in: Circle())
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(.top, 10)

                        featureView
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 40)
                    .frame(maxWidth: 1120, alignment: .leading)
                    .frame(maxWidth: .infinity)
                }
            }
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button {
                        store.selectedTab = .search
                    } label: { Label("検索", systemImage: "magnifyingglass") }
                }
                ToolbarItem(placement: .primaryAction) {
                    Button {
                        store.selectedTab = .board
                    } label: { Label("掲示板", systemImage: "text.book.closed") }
                }
            }
            .overlay {
                if store.settings.screenProtection || showScreenProtection {
                    ScreenProtectionOverlay {
                        showScreenProtection = false
                        store.settings.screenProtection = false
                    }
                } else {
                    TimelineView(.periodic(from: .now, by: 15)) { context in
                        if isInsideSleepWindow(context.date) && (sleepPauseUntil ?? .distantPast) <= context.date {
                            SleepLockOverlay(onBreak: { sleepPauseUntil = Date().addingTimeInterval(300) }, onSettings: {
                                sleepPauseUntil = Date().addingTimeInterval(300)
                                store.selectedTab = .sleep
                            })
                        }
                    }
                }
            }
            .alert("NEXUS", isPresented: Binding(get: { store.alertMessage != nil }, set: { if !$0 { store.alertMessage = nil } })) {
                Button("OK", role: .cancel) { store.alertMessage = nil }
            } message: { Text(store.alertMessage ?? "") }
            .onChange(of: scenePhase) { _, phase in
                if store.settings.blurOnBackground && phase != .active { showScreenProtection = true }
                if phase == .active && store.settings.blurOnBackground { showScreenProtection = false }
            }
        }
        .navigationSplitViewStyle(.balanced)
        .tint(Color(hex: store.settings.accentHex))
    }

    private func isInsideSleepWindow(_ date: Date) -> Bool {
        guard store.settings.sleepEnabled else { return false }
        func minutes(_ value: String) -> Int? {
            let pieces = value.split(separator: ":").compactMap { Int($0) }
            guard pieces.count == 2, (0...23).contains(pieces[0]), (0...59).contains(pieces[1]) else { return nil }
            return pieces[0] * 60 + pieces[1]
        }
        guard let start = minutes(store.settings.sleepStart), let end = minutes(store.settings.sleepEnd), start != end else { return false }
        let parts = Calendar.current.dateComponents([.hour, .minute], from: date)
        let now = (parts.hour ?? 0) * 60 + (parts.minute ?? 0)
        return start < end ? (now >= start && now < end) : (now >= start || now < end)
    }

    @ViewBuilder private var featureView: some View {
        switch store.selectedTab {
        case .home: DashboardView()
        case .search: SearchLauncherView()
        case .assistant: NexusAssistantView()
        case .weather: WeatherView()
        case .timer: TimerToolView()
        case .stopwatch: StopwatchToolView()
        case .bgm: BGMToolView()
        case .memo: MemoView()
        case .translate: TranslateView()
        case .todo: TodoView()
        case .calendar: CalendarView()
        case .network: NetworkTestView()
        case .music: MusicPlayerView()
        case .calculator: CalculatorView()
        case .drawing: DrawingStudioView()
        case .news: NewsView()
        case .board: BulletinBoardView()
        case .codeBridge: CodeBridgeView()
        case .garbler: GarblerView()
        case .security: SecurityView()
        case .urlChecker: URLCheckerView()
        case .privacy: PrivacyView()
        case .backup: BackupView()
        case .sleep: SleepRestrictionView()
        case .developer: DeveloperView()
        case .settings: SettingsView()
        case .games: MiniGamesView()
        case .monitor: SystemMonitorView()
        case .about: AboutView()
        }
    }
}

// MARK: - Reusable design elements

struct NexusCard<Content: View>: View {
    var title: String
    var symbol: String
    let content: Content
    @EnvironmentObject private var store: NexusStore

    init(_ title: String, symbol: String = "sparkles", @ViewBuilder content: () -> Content) {
        self.title = title; self.symbol = symbol; self.content = content()
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label(title, systemImage: symbol)
                .font(.headline.weight(.semibold))
                .foregroundStyle(Color(hex: store.settings.accentHex))
            content
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color(hex: store.settings.accentHex).opacity(0.34), lineWidth: 1))
        .shadow(color: Color(hex: store.settings.accentHex).opacity(0.10), radius: 18, y: 5)
    }
}

struct NexusBackground: View {
    var wallpaper: String
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                LinearGradient(colors: backgroundColors, startPoint: .topLeading, endPoint: .bottomTrailing)
                RadialGradient(colors: [Color.blue.opacity(0.23), .clear], center: .topTrailing, startRadius: 12, endRadius: proxy.size.width * 0.9)
                RadialGradient(colors: [Color.purple.opacity(0.26), .clear], center: .bottomLeading, startRadius: 8, endRadius: proxy.size.width * 0.8)
                Canvas { context, size in
                    for i in 0..<110 {
                        let x = CGFloat((i * 79) % 997) / 997 * size.width
                        let y = CGFloat((i * 137) % 991) / 991 * size.height
                        let rect = CGRect(x: x, y: y, width: i % 8 == 0 ? 2 : 1, height: i % 8 == 0 ? 2 : 1)
                        context.fill(Path(ellipseIn: rect), with: .color(.white.opacity(i % 8 == 0 ? 0.55 : 0.22)))
                    }
                }
                Circle().fill(RadialGradient(colors: [.cyan.opacity(0.65), .blue.opacity(0.38), .indigo.opacity(0.16), .clear], center: .topLeading, startRadius: 8, endRadius: 180))
                    .frame(width: 240, height: 240).overlay(Circle().stroke(.cyan.opacity(0.35), lineWidth: 2))
                    .overlay(Ellipse().stroke(.cyan.opacity(0.30), lineWidth: 2).frame(width: 340, height: 65).rotationEffect(.degrees(-18)))
                    .offset(x: proxy.size.width * 0.42, y: -proxy.size.height * 0.31)
                    .blur(radius: 1)
            }
            .ignoresSafeArea()
        }
    }
    private var backgroundColors: [Color] {
        switch wallpaper {
        case "落ち着いた背景（既定）": [Color(red: 0.04, green: 0.07, blue: 0.12), Color(red: 0.08, green: 0.12, blue: 0.19)]
        case "深宇宙ブルー": [Color(red: 0.00, green: 0.02, blue: 0.10), Color(red: 0.02, green: 0.08, blue: 0.25)]
        case "ネオン・グリッド": [Color(red: 0.01, green: 0.02, blue: 0.08), Color(red: 0.10, green: 0.02, blue: 0.18)]
        default: [Color(red: 0.01, green: 0.01, blue: 0.06), Color(red: 0.03, green: 0.02, blue: 0.15)]
        }
    }
}

struct NexusActionButton: View {
    var title: String
    var symbol: String = "arrow.right"
    var role: ButtonRole? = nil
    var action: () -> Void
    var body: some View {
        Button(role: role, action: action) {
            Label(title, systemImage: symbol)
                .font(.subheadline.weight(.semibold))
                .padding(.horizontal, 13).padding(.vertical, 9)
                .background(.thinMaterial, in: Capsule())
        }
        .buttonStyle(.plain)
    }
}

struct ScreenProtectionOverlay: View {
    var onResume: () -> Void
    var body: some View {
        ZStack {
            Color.black.opacity(0.94).ignoresSafeArea()
            VStack(spacing: 14) {
                Image(systemName: "lock.shield.fill").font(.system(size: 48)).foregroundStyle(.cyan)
                Text("画面保護中").font(.title.bold())
                Text("NEXUS画面を一時的に隠しています。OS全体の画面ロックやスクリーンショット防止機能ではありません。")
                    .font(.footnote).multilineTextAlignment(.center).foregroundStyle(.white.opacity(0.75))
                Button("画面の表示を再開", action: onResume).buttonStyle(.borderedProminent)
            }
            .padding(28).frame(maxWidth: 420)
        }
        .zIndex(1000)
    }
}

extension Color {
    init(hex: String) {
        let cleaned = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        let value = UInt64(cleaned, radix: 16) ?? 0x37D8FF
        self.init(.sRGB, red: Double((value >> 16) & 0xFF) / 255,
                  green: Double((value >> 8) & 0xFF) / 255,
                  blue: Double(value & 0xFF) / 255, opacity: 1)
    }
}

// MARK: - Home dashboard

struct DashboardView: View {
    @EnvironmentObject private var store: NexusStore
    @State private var query = ""
    @Environment(\.openURL) private var openURL

    var body: some View {
        VStack(spacing: 16) {
            NexusCard("NEXUS CLOCK", symbol: "clock") {
                TimelineView(.periodic(from: .now, by: 1)) { context in
                    HStack(alignment: .center, spacing: 20) {
                        AnalogClock(date: context.date)
                            .frame(width: 98, height: 98)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(context.date.formatted(date: .omitted, time: .standard))
                                .font(.system(size: 40, weight: .light, design: .rounded)).monospacedDigit()
                                .minimumScaleFactor(0.55).lineLimit(1)
                            Text(context.date.formatted(.dateTime.year().month().day().weekday(.wide)))
                                .font(.footnote.weight(.medium)).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 0)
                    }
                    .frame(maxWidth: .infinity, alignment: .center)
                }
            }
            NexusCard("クイック検索", symbol: "magnifyingglass") {
                HStack(spacing: 8) {
                    TextField("検索ワードまたはURLを入力", text: $query)
                        .textFieldStyle(.roundedBorder)
                        .submitLabel(.search)
                        .onSubmit { performSearch() }
                    Button(action: performSearch) { Image(systemName: "arrow.up.right").padding(10) }
                        .buttonStyle(.borderedProminent)
                }
                Text("Google検索、またはhttps://で始まるURLを開きます。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 145), spacing: 10)], spacing: 10) {
                DashboardShortcut(tab: .weather, detail: "47都道府県の予報")
                DashboardShortcut(tab: .todo, detail: "日付ごとのチェック")
                DashboardShortcut(tab: .memo, detail: "ローカル保存")
                DashboardShortcut(tab: .calendar, detail: "予定とカレンダー")
                DashboardShortcut(tab: .codeBridge, detail: "コード変換・設計")
                DashboardShortcut(tab: .security, detail: "ローカル診断")
            }
            NexusCard("アプリランチャー", symbol: "square.grid.2x2.fill") {
                ForEach(NexusCatalog.linkGroups) { group in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(group.name).font(.subheadline.bold()).foregroundStyle(.secondary)
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 105), spacing: 8)], spacing: 8) {
                            ForEach(group.links) { link in
                                Button { openLink(link.url) } label: {
                                    Label(link.name, systemImage: link.symbol)
                                        .font(.caption.weight(.medium)).lineLimit(1)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .padding(9).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 10))
                                }.buttonStyle(.plain)
                            }
                        }
                    }
                    if group.id != NexusCatalog.linkGroups.last?.id { Divider().opacity(0.25) }
                }
            }
            NexusCard("NEXUS 更新ニュース", symbol: "sparkles") {
                Text("3.1 Swiftネイティブ版")
                    .font(.headline)
                Text("元HTML版の主要機能をSwiftUIへ移植。データは端末内に保存し、外部通信は機能ごとの操作時に行います。")
                    .font(.subheadline).foregroundStyle(.secondary)
                Button("更新履歴・ニュースを開く") { store.selectedTab = .news }
                    .buttonStyle(.bordered)
            }
        }
    }

    private func performSearch() {
        let value = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return }
        if value.lowercased().hasPrefix("https://"), let url = URL(string: value), url.host != nil {
            openLink(value)
        } else {
            let encoded = value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? value
            openLink("https://www.google.com/search?q=" + encoded)
        }
    }
    private func openLink(_ value: String) {
        guard !store.settings.anonymousCommunication else { store.alertMessage = "通信匿名モード中は外部サイトを開けません。"; return }
        guard let url = URL(string: value), url.scheme == "https" else { store.alertMessage = "安全のためHTTPSのURLのみ開けます。"; return }
        openURL(url)
    }
}

struct DashboardShortcut: View {
    @EnvironmentObject private var store: NexusStore
    var tab: NexusTab
    var detail: String
    var body: some View {
        Button { store.selectedTab = tab } label: {
            HStack(spacing: 10) {
                Image(systemName: tab.symbol).font(.title2).foregroundStyle(Color(hex: store.settings.accentHex))
                VStack(alignment: .leading, spacing: 3) {
                    Text(tab.title).font(.subheadline.bold()).foregroundStyle(.primary)
                    Text(detail).font(.caption2).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            .padding(12).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 13))
        }.buttonStyle(.plain)
    }
}

struct AnalogClock: View {
    var date: Date
    var body: some View {
        GeometryReader { geo in
            let size = min(geo.size.width, geo.size.height)
            ZStack {
                Circle().fill(.ultraThinMaterial)
                Circle().stroke(.cyan.opacity(0.5), lineWidth: 1.2)
                ForEach(0..<60, id: \.self) { tick in
                    Capsule().fill(.primary.opacity(tick % 5 == 0 ? 0.75 : 0.25))
                        .frame(width: tick % 5 == 0 ? 2 : 1, height: tick % 5 == 0 ? 7 : 3)
                        .offset(y: -size * 0.44)
                        .rotationEffect(.degrees(Double(tick) * 6))
                }
                let c = Calendar.current
                let hour = Double(c.component(.hour, from: date) % 12) + Double(c.component(.minute, from: date)) / 60
                let minute = Double(c.component(.minute, from: date)) + Double(c.component(.second, from: date)) / 60
                let second = Double(c.component(.second, from: date))
                clockHand(length: size * 0.24, width: 4, angle: hour * 30).foregroundStyle(.primary)
                clockHand(length: size * 0.34, width: 2.5, angle: minute * 6).foregroundStyle(.primary)
                clockHand(length: size * 0.38, width: 1, angle: second * 6).foregroundStyle(.cyan)
                Circle().fill(.cyan).frame(width: 6, height: 6)
            }
        }
    }
    private func clockHand(length: CGFloat, width: CGFloat, angle: Double) -> some View {
        Capsule().frame(width: width, height: length).offset(y: -length / 2).rotationEffect(.degrees(angle))
    }
}

// MARK: - Search and launcher

struct SearchLauncherView: View {
    @EnvironmentObject private var store: NexusStore
    @Environment(\.openURL) private var openURL
    @State private var query = ""
    @State private var newName = ""
    @State private var newURL = ""
    @State private var searchEngine = "Google"
    private let engines = ["Google", "Yahoo", "DuckDuckGo", "Bing", "Brave", "Ecosia"]

    var body: some View {
        VStack(spacing: 16) {
            NexusCard("検索", symbol: "magnifyingglass") {
                Picker("検索エンジン", selection: $searchEngine) { ForEach(engines, id: \.self) { Text($0) } }.pickerStyle(.segmented)
                HStack {
                    TextField("検索ワードまたはhttps://URL", text: $query).textFieldStyle(.roundedBorder).onSubmit(search)
                    Button("検索", action: search).buttonStyle(.borderedProminent)
                }
                Text("URLを開く場合はHTTPSを使用してください。HTTPはHTTPSに置き換えて検査します。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            NexusCard("カスタムリンクを追加", symbol: "plus.circle") {
                TextField("名前", text: $newName).textFieldStyle(.roundedBorder)
                TextField("URL（例：example.com）", text: $newURL).textFieldStyle(.roundedBorder).textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("追加") {
                    let name = newName.trimmingCharacters(in: .whitespacesAndNewlines)
                    let raw = newURL.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !name.isEmpty, !raw.isEmpty else { return }
                    let url = raw.contains("://") ? raw : "https://" + raw
                    guard let parsed = URL(string: url), parsed.scheme == "https", parsed.host != nil else { store.alertMessage = "有効なHTTPS URLを入力してください。"; return }
                    store.customLinks.append(NexusLink(name: name, url: parsed.absoluteString)); newName = ""; newURL = ""
                }.buttonStyle(.borderedProminent)
            }
            if !store.customLinks.isEmpty {
                NexusCard("この端末に保存したリンク", symbol: "bookmark.fill") {
                    ForEach(store.customLinks) { link in
                        HStack {
                            Label(link.name, systemImage: link.symbol)
                            Spacer()
                            Button("開く") { open(link.url) }.buttonStyle(.bordered)
                            Button(role: .destructive) { store.customLinks.removeAll { $0.id == link.id } } label: { Image(systemName: "trash") }.buttonStyle(.borderless)
                        }
                    }
                }
            }
            ForEach(NexusCatalog.linkGroups) { group in
                NexusCard(group.name, symbol: "square.grid.2x2") {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 120), spacing: 8)], spacing: 8) {
                        ForEach(group.links) { link in
                            Button { open(link.url) } label: { Label(link.name, systemImage: link.symbol).font(.caption).frame(maxWidth: .infinity, alignment: .leading).padding(10).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 10)) }.buttonStyle(.plain)
                        }
                    }
                }
            }
        }
    }
    private func search() {
        let value = query.trimmingCharacters(in: .whitespacesAndNewlines); guard !value.isEmpty else { return }
        if value.lowercased().hasPrefix("https://") { open(value); return }
        let base: String = switch searchEngine {
        case "Yahoo": "https://search.yahoo.co.jp/search?p="
        case "DuckDuckGo": "https://duckduckgo.com/?q="
        case "Bing": "https://www.bing.com/search?q="
        case "Brave": "https://search.brave.com/search?q="
        case "Ecosia": "https://www.ecosia.org/search?q="
        default: "https://www.google.com/search?q="
        }
        open(base + (value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? value))
    }
    private func open(_ value: String) {
        guard !store.settings.anonymousCommunication else { store.alertMessage = "通信匿名モード中は外部サイトを開けません。"; return }
        guard let url = URL(string: value), url.scheme == "https" else { store.alertMessage = "HTTPSのURLのみ開けます。"; return }
        openURL(url)
    }
}

#endif
