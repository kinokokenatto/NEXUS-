# NEXUS SUPER3.1 — Swift Native Port

NEXUS SUPER3.1 の提供HTML版をベースに、SwiftUI / Swift / AVFoundation / CryptoKit で再実装した iOS・iPadOS アプリのソースです。HTML、CSS、JavaScript、WKWebView をアプリ本体に含めていません。

## 開発環境

- Xcode 15.0 以降を推奨
- iOS / iPadOS 17.0 以降
- Swift 5.9
- 追加の外部Swift Packageは不要

## 起動方法

1. `NEXUS_Swift_Port.xcodeproj` をXcodeで開きます。
2. `NEXUS_Swift_Port` ターゲットを選び、Signing & Capabilitiesで開発チームを設定します（実機で実行する場合）。
3. iPhone / iPad Simulator または実機を選択して Run します。

## ソース構成

| ファイル | 内容 |
|---|---|
| `NEXUSApp.swift` | SwiftUIアプリのエントリーポイント、ナビゲーション、ダッシュボード、宇宙背景、共通UI |
| `NexusCore.swift` | データモデル、47都道府県データ、UserDefaults保存、天気通信、URL検査、電卓パーサー、暗号化バックアップ |
| `NexusAudioServices.swift` | AVAudioPlayerによるローカル音楽再生、生成BGM、読み上げ |
| `NexusFeatureViews.swift` | 天気、タイマー、ストップウォッチ、BGM、メモ、Todo、カレンダー、翻訳、ニュース、速度測定、音楽、電卓、掲示板、モニター |
| `NexusAdvancedViews.swift` | 描画、CodeBridge、文字化けラボ、セキュリティ、URL検査、プライバシー、バックアップ、設定、開発者機能、ミニゲーム、Assistant+、規約 |

## 実装範囲と注意点

- 画面・状態管理・保存・暗号化バックアップ・描画・音声・タイマー類はSwiftネイティブで実装しています。
- 天気は利用者が更新操作を行ったときにOpen-Meteoへ通信します。自動更新は初期状態で無効です。通信先にはIPアドレス等が伝わる場合があります。
- 翻訳は翻訳先サービスを明示的に開く方式です。元HTMLのブラウザ内蔵翻訳エンジンそのものはiOS APIに存在しないため、内蔵エンジンとしては移植していません。
- CodeBridgeは限定的なテンプレート変換です。汎用コンパイラや全言語対応の完全な意味保存変換ではありません。
- ミニゲーム、描画ツール、セキュリティ診断、システムモニターはネイティブ版として再構成・簡略化しています。HTML DOM / CSP / JavaScript実行環境を対象にする元版の静的検査機能は、そのままネイティブアプリへは移植できません。
- 元HTMLのブラウザ `localStorage` と本アプリの `UserDefaults` は保存形式が異なります。既存ブラウザデータの自動取り込みは行いません。本アプリのバックアップは本アプリ用JSON形式です。
- 元HTMLに埋め込まれた壁紙画像、HTMLソース編集機能、ブラウザ固有権限の検査、ブラウザの画面キャプチャ抑止などは、ネイティブOSの仕組みが異なるため同一機能としては再現していません。
- 外部リンクはHTTPSのみ許可し、匿名通信モード中は外部リンク起動を止めます。

## セキュリティ

バックアップ暗号化はCryptoKitのAES-GCMを使用し、パスフレーズからPBKDF2-HMAC-SHA256（310,000反復）で鍵を導出します。復号パスフレーズを忘れた場合、バックアップは復元できません。アプリ内データは端末のアプリ領域に保存されます。

## 検証

この作業環境ではSwift構文解析（`swiftc -frontend -parse`）を実行しています。Xcode / iOS SDKがない環境のため、iOSターゲットの完全な型検査・リンク・実機署名は未実施です。最初にXcodeでビルドし、コンパイル診断に応じて調整してください。
