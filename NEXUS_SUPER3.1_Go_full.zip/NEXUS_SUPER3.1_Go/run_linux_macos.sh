#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ "$(uname -s)" = "Linux" ] && [ "$(uname -m)" = "x86_64" ] && [ -x ./NEXUS_SUPER3.1_Go_linux_amd64 ]; then
  exec ./NEXUS_SUPER3.1_Go_linux_amd64
fi
exec go run .
