// Minimal Go WebAssembly runtime bootstrap. All application behavior lives in wasm/main.go.
(async () => {
  const go = new Go();
  const response = await fetch('/nexus.wasm');
  if (!response.ok) throw new Error(`NEXUS Go module load failed: ${response.status}`);
  const bytes = await response.arrayBuffer();
  const { instance } = await WebAssembly.instantiate(bytes, go.importObject);
  go.run(instance);
})().catch((error) => {
  const node = document.createElement('pre');
  node.textContent = `NEXUS Go/WASM 起動エラー: ${error}`;
  node.style.cssText = 'position:fixed;inset:12px;z-index:999999;background:#240b18;color:#fff;padding:16px;white-space:pre-wrap';
  document.body.appendChild(node);
});
