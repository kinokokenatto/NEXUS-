module nexus-super31-go

go 1.23
