@echo off
cd /d "%~dp0"
if exist NEXUS_SUPER3.1_Go.exe (
  NEXUS_SUPER3.1_Go.exe
) else (
  go run .
)
pause
