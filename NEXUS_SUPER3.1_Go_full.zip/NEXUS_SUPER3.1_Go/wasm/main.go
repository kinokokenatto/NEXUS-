//go:build js && wasm

// NEXUS SUPER3.1 browser application logic, compiled from Go to WebAssembly.
// The HTML and CSS are retained as the browser's presentation layer. No
// application feature logic is implemented in JavaScript; boot.js only starts
// the Go WebAssembly runtime.
package main

import (
	"encoding/json"
	"fmt"
	"html"
	"math"
	"net/url"
	"strings"
	"syscall/js"
	"time"
)

var (
	win                 = js.Global()
	doc                 = win.Get("document")
	funcs               []js.Func
	cfg                 Config
	bookmarks           []AppLink
	groups              []AppGroup
	activeGroup         int
	editing             bool
	memos               []Memo
	selectedMemo        string
	todos               map[string][]Todo
	todoDate            string
	events              []Event
	calendarMonth       time.Time
	calendarSelected    string
	timerDeadline       time.Time
	timerRunning        bool
	stopwatchRunning    bool
	stopwatchStart      time.Time
	stopwatchElapsed    time.Duration
	stopwatchLaps       []time.Duration
	calcState           calculatorState
	privacyAnonymous    bool
	screenProtected     bool
	developerEnabled    bool
	adminEnabled        bool
	newsOpen            bool
	assistantOpen       bool
	lastAssistantPrompt string
	bgmContext          js.Value
	bgmOsc              js.Value
	bgmGain             js.Value
	bgmPlaying          bool
	drawCanvas          js.Value
	drawCtx             js.Value
	drawDown            bool
	drawX, drawY        float64
	drawUndo            []string
	drawRedo            []string
)

type Config struct {
	Theme        string  `json:"th"`
	Hue          float64 `json:"h"`
	Blur         float64 `json:"bl"`
	Size         float64 `json:"sz"`
	Contrast     float64 `json:"ct"`
	Brightness   float64 `json:"br"`
	Wallpaper    string  `json:"bgMode"`
	Background   string  `json:"bg"`
	Layout       string  `json:"layoutMode"`
	AutoNetwork  bool    `json:"privacyAutoNetwork"`
	BlurPrivacy  bool    `json:"privacyBlur"`
	Visible      []int   `json:"w"`
	SearchEngine int     `json:"en"`
	City         string  `json:"city"`
}
type AppLink struct {
	Name string `json:"name"`
	URL  string `json:"url"`
}
type AppGroup struct {
	Name  string
	Items []AppLink
}
type Memo struct {
	ID    string `json:"id"`
	Title string `json:"title"`
	Body  string `json:"body"`
	Pin   bool   `json:"pin"`
	T     int64  `json:"t"`
	C     int64  `json:"c"`
}
type Todo struct {
	Text        string `json:"text"`
	Done        bool   `json:"done"`
	Created     string `json:"created"`
	CompletedAt string `json:"completedAt,omitempty"`
}
type Event struct {
	Date    string `json:"d"`
	Time    string `json:"t"`
	Name    string `json:"n"`
	Done    bool   `json:"x,omitempty"`
	Alerted string `json:"a,omitempty"`
}
type calculatorState struct {
	display  string
	left     float64
	op       string
	newInput bool
	history  string
}

type WeatherResponse struct {
	Current struct {
		Temperature float64 `json:"temperature_2m"`
		Humidity    float64 `json:"relative_humidity_2m"`
		Apparent    float64 `json:"apparent_temperature"`
		Code        int     `json:"weather_code"`
		Wind        float64 `json:"wind_speed_10m"`
	} `json:"current"`
	Hourly struct {
		Time []string  `json:"time"`
		Rain []float64 `json:"precipitation"`
		Temp []float64 `json:"temperature_2m"`
	} `json:"hourly"`
}

func main() {
	if doc.Get("readyState").String() == "loading" {
		cb := js.FuncOf(func(this js.Value, args []js.Value) any { initApp(); return nil })
		funcs = append(funcs, cb)
		doc.Call("addEventListener", "DOMContentLoaded", cb)
	} else {
		initApp()
	}
	select {}
}

func initApp() {
	loadState()
	initSettings()
	initSearchAndApps()
	initClock()
	initTimerStopwatch()
	initMemoTodoCalendar()
	initBoard()
	initCodeBridge()
	initCalculator()
	initMusic()
	initDrawing()
	initWeather()
	initTranslation()
	initGarbler()
	initAssistantNews()
	initBackupSecurity()
	initDeveloperAndSleep()
	initNavigation()
	initCommonKeys()
	refreshSystemMonitor()
	updateTodos()
	updateMemos()
	updateCalendar()
	updateBookmarks()
	updateApps()
	fmtSetText("ftY", time.Now().Format("2006"))
}

func keep(fn js.Func)              { funcs = append(funcs, fn) }
func byID(id string) js.Value      { return doc.Call("getElementById", id) }
func qs(selector string) js.Value  { return doc.Call("querySelector", selector) }
func qsa(selector string) js.Value { return doc.Call("querySelectorAll", selector) }
func on(id, event string, handler func(js.Value)) {
	el := byID(id)
	if el.IsNull() || el.IsUndefined() {
		return
	}
	cb := js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) > 0 {
			handler(args[0])
		}
		return nil
	})
	keep(cb)
	el.Call("addEventListener", event, cb)
}
func onDoc(event string, handler func(js.Value)) {
	cb := js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) > 0 {
			handler(args[0])
		}
		return nil
	})
	keep(cb)
	doc.Call("addEventListener", event, cb)
}
func onWindow(event string, handler func(js.Value)) {
	cb := js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) > 0 {
			handler(args[0])
		}
		return nil
	})
	keep(cb)
	win.Call("addEventListener", event, cb)
}
func prevent(e js.Value) { e.Call("preventDefault") }
func stop(e js.Value)    { e.Call("stopPropagation") }
func val(id string) string {
	v := byID(id)
	if v.IsNull() || v.IsUndefined() {
		return ""
	}
	x := v.Get("value")
	if x.IsUndefined() || x.IsNull() {
		return ""
	}
	return x.String()
}
func setVal(id, s string) {
	v := byID(id)
	if !v.IsNull() && !v.IsUndefined() {
		v.Set("value", s)
	}
}
func text(id string) string {
	v := byID(id)
	if v.IsNull() || v.IsUndefined() {
		return ""
	}
	return v.Get("textContent").String()
}
func fmtSetText(id string, v any) {
	el := byID(id)
	if !el.IsNull() && !el.IsUndefined() {
		el.Set("textContent", fmt.Sprint(v))
	}
}
func setHTML(id, s string) {
	el := byID(id)
	if !el.IsNull() && !el.IsUndefined() {
		el.Set("innerHTML", s)
	}
}
func setHidden(id string, hidden bool) {
	el := byID(id)
	if !el.IsNull() && !el.IsUndefined() {
		el.Set("hidden", hidden)
	}
}
func isHidden(id string) bool {
	el := byID(id)
	return el.IsNull() || el.IsUndefined() || el.Get("hidden").Bool()
}
func setDisabled(id string, v bool) {
	el := byID(id)
	if !el.IsNull() && !el.IsUndefined() {
		el.Set("disabled", v)
	}
}
func setStatus(id, s string) { fmtSetText(id, s) }
func nowDate() string        { return time.Now().Format("2006-01-02") }
func safeJSON(v any) string {
	b, e := json.Marshal(v)
	if e != nil {
		return "null"
	}
	return string(b)
}
func storageGet(key string) (string, bool) {
	ls := win.Get("localStorage")
	if ls.IsUndefined() || ls.IsNull() {
		return "", false
	}
	v := ls.Call("getItem", key)
	if v.IsNull() || v.IsUndefined() {
		return "", false
	}
	return v.String(), true
}
func storageSet(key string, v any) bool {
	raw := safeJSON(v)
	ls := win.Get("localStorage")
	if ls.IsUndefined() || ls.IsNull() {
		return false
	}
	func() { defer func() { _ = recover() }(); ls.Call("setItem", key, raw) }()
	return true
}
func storageRemove(key string) {
	defer func() { _ = recover() }()
	win.Get("localStorage").Call("removeItem", key)
}
func loadJSON(key string, dest any) bool {
	raw, ok := storageGet(key)
	if !ok {
		return false
	}
	return json.Unmarshal([]byte(raw), dest) == nil
}
func jsString(v js.Value) string {
	if v.IsNull() || v.IsUndefined() {
		return ""
	}
	return v.String()
}
func escape(s string) string { return html.EscapeString(s) }
func setAttr(id, name, value string) {
	el := byID(id)
	if !el.IsNull() && !el.IsUndefined() {
		el.Call("setAttribute", name, value)
	}
}
func addClass(id, name string) {
	el := byID(id)
	if !el.IsNull() && !el.IsUndefined() {
		el.Get("classList").Call("add", name)
	}
}
func removeClass(id, name string) {
	el := byID(id)
	if !el.IsNull() && !el.IsUndefined() {
		el.Get("classList").Call("remove", name)
	}
}
func toggleClass(id, name string) bool {
	el := byID(id)
	if el.IsNull() || el.IsUndefined() {
		return false
	}
	return el.Get("classList").Call("toggle", name).Bool()
}
func click(id string) {
	el := byID(id)
	if !el.IsNull() && !el.IsUndefined() {
		el.Call("click")
	}
}
func focus(id string) {
	el := byID(id)
	if !el.IsNull() && !el.IsUndefined() {
		el.Call("focus")
	}
}
func scroll(id string) {
	el := byID(id)
	if !el.IsNull() && !el.IsUndefined() {
		el.Call("scrollIntoView", map[string]any{"behavior": "smooth", "block": "center"})
	}
}
func openModal(id string)     { setHidden(id, false) }
func closeModal(id string)    { setHidden(id, true) }
func confirm(msg string) bool { return win.Call("confirm", msg).Bool() }
func alert(msg string)        { win.Call("alert", msg) }
func copyText(s string, statusID string) {
	cb := win.Get("navigator").Get("clipboard")
	if cb.IsUndefined() || cb.IsNull() {
		if statusID != "" {
			setStatus(statusID, "このブラウザではクリップボードAPIを利用できません。")
		}
		return
	}
	p := cb.Call("writeText", s)
	ok := js.FuncOf(func(this js.Value, args []js.Value) any {
		if statusID != "" {
			setStatus(statusID, "コピーしました。")
		}
		return nil
	})
	ng := js.FuncOf(func(this js.Value, args []js.Value) any {
		if statusID != "" {
			setStatus(statusID, "コピーできませんでした。ブラウザの権限を確認してください。")
		}
		return nil
	})
	keep(ok)
	keep(ng)
	p.Call("then", ok).Call("catch", ng)
}
func download(name, content, mime string) {
	blob := win.Get("Blob").New([]any{content}, map[string]any{"type": mime})
	objURL := win.Get("URL").Call("createObjectURL", blob)
	a := doc.Call("createElement", "a")
	a.Set("href", objURL)
	a.Set("download", name)
	a.Get("style").Set("display", "none")
	doc.Get("body").Call("appendChild", a)
	a.Call("click")
	a.Call("remove")
	win.Call("setTimeout", js.FuncOf(func(this js.Value, args []js.Value) any { win.Get("URL").Call("revokeObjectURL", objURL); return nil }), 1000)
}

// downloadDataURL writes a browser-generated data URL without wrapping it as text.
func downloadDataURL(name, dataURL string) {
	a := doc.Call("createElement", "a")
	a.Set("href", dataURL)
	a.Set("download", name)
	a.Get("style").Set("display", "none")
	doc.Get("body").Call("appendChild", a)
	a.Call("click")
	a.Call("remove")
}
func safeURL(raw string) string {
	raw = strings.TrimSpace(raw)
	if strings.HasPrefix(raw, "#nexus-game-") || raw == "#nexus-garbler" {
		return raw
	}
	if raw == "" || len(raw) > 2048 {
		return ""
	}
	if !strings.Contains(raw, "://") {
		if strings.Contains(raw, ":") {
			return ""
		}
		raw = "https://" + raw
	}
	u, e := url.Parse(raw)
	if e != nil || u.Host == "" || u.User != nil || !(u.Scheme == "https" || u.Scheme == "http") {
		return ""
	}
	u.Scheme = "https"
	return u.String()
}
func openURL(raw string) {
	u := safeURL(raw)
	if u == "" {
		alert("安全のため、このURLは開けません。https:// のURLを指定してください。http:// は自動的に https:// へ切り替えます。")
		return
	}
	if privacyAnonymous && !strings.HasPrefix(u, "#") {
		setStatus("nexusAnonModeStatus", "通信匿名モードにより外部サイトの起動をブロックしました。IPアドレス自体を隠すVPN機能ではありません。")
		return
	}
	w := win.Call("open", u, "_blank", "noopener,noreferrer")
	if !w.IsNull() && !w.IsUndefined() {
		w.Set("opener", js.Null())
	}
}
func loadState() {
	cfg = Config{Theme: "dark", Hue: 190, Blur: 12, Size: 84, Contrast: 1.25, Brightness: 1, Wallpaper: "calm", Layout: "auto", Visible: []int{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, City: "東京"}
	var old Config
	if loadJSON("cfg", &old) {
		if old.Theme != "" {
			cfg.Theme = old.Theme
		}
		if old.Hue != 0 {
			cfg.Hue = old.Hue
		}
		if old.Blur != 0 {
			cfg.Blur = old.Blur
		}
		if old.Size != 0 {
			cfg.Size = old.Size
		}
		if old.Contrast != 0 {
			cfg.Contrast = old.Contrast
		}
		if old.Brightness != 0 {
			cfg.Brightness = old.Brightness
		}
		if old.Wallpaper != "" {
			cfg.Wallpaper = old.Wallpaper
		}
		if old.Background != "" {
			cfg.Background = old.Background
		}
		if old.Layout != "" {
			cfg.Layout = old.Layout
		}
		cfg.AutoNetwork = old.AutoNetwork
		cfg.BlurPrivacy = old.BlurPrivacy
		if len(old.Visible) > 0 {
			cfg.Visible = old.Visible
		}
		cfg.SearchEngine = old.SearchEngine
	}
	if cfg.Theme != "light" {
		cfg.Theme = "dark"
	}
	cfg.Hue = clamp(cfg.Hue, 0, 360, 190)
	cfg.Blur = clamp(cfg.Blur, 0, 30, 12)
	cfg.Size = clamp(cfg.Size, 56, 120, 84)
	cfg.Contrast = clamp(cfg.Contrast, .5, 2, 1.25)
	cfg.Brightness = clamp(cfg.Brightness, .3, 1.5, 1)
	if cfg.Layout != "pc" && cfg.Layout != "mobile" {
		cfg.Layout = "auto"
	}
	if cfg.Wallpaper == "" {
		cfg.Wallpaper = "calm"
	}
	if len(cfg.Visible) != 12 {
		cfg.Visible = []int{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
	}
	privacyAnonymous = false
	var anon bool
	if loadJSON("nexusCommunicationAnonMode", &anon) {
		privacyAnonymous = anon
	}
	screenProtected = false
	var scr bool
	if loadJSON("nexusScreenProtectMode", &scr) {
		screenProtected = scr
	}
	bookmarks = defaultBookmarks()
	var saved []AppLink
	if loadJSON("bm", &saved) && len(saved) > 0 {
		bookmarks = saved
	}
	groups = defaultGroups()
	var savedGroups [][]AppLink
	if loadJSON("apps", &savedGroups) {
		for i := 0; i < len(groups) && i < len(savedGroups); i++ {
			if len(savedGroups[i]) > 0 {
				merged := append([]AppLink{}, savedGroups[i]...)
				for _, d := range groups[i].Items {
					found := false
					for _, s := range savedGroups[i] {
						if s.Name == d.Name {
							found = true
							break
						}
					}
					if !found {
						merged = append(merged, d)
					}
				}
				groups[i].Items = merged
			}
		}
	}
	loadJSON("memos", &memos)
	if len(memos) == 0 {
		var legacy string
		if loadJSON("memo", &legacy) && strings.TrimSpace(legacy) != "" {
			memos = []Memo{{ID: "legacy", Title: "旧メモ", Body: legacy, T: time.Now().UnixMilli(), C: time.Now().UnixMilli()}}
		}
	}
	todos = map[string][]Todo{}
	loadJSON("nexusDailyTodos", &todos)
	todoDate = nowDate()
	loadJSON("ev", &events)
	calendarMonth = time.Now()
	calendarMonth = time.Date(calendarMonth.Year(), calendarMonth.Month(), 1, 0, 0, 0, 0, calendarMonth.Location())
	calcState = calculatorState{display: "0", newInput: true}
}
func clamp(v, min, max, def float64) float64 {
	if math.IsNaN(v) || math.IsInf(v, 0) {
		return def
	}
	if v < min {
		return min
	}
	if v > max {
		return max
	}
	return v
}

func defaultBookmarks() []AppLink {
	names := []string{"Gmail", "ドキュメント", "スライド", "スプレッドシート", "ドライブ", "Word", "Excel", "PowerPoint", "Teams", "Outlook", "OneNote", "Copilot", "Claude", "ChatGPT", "YouTube", "GitHub"}
	urls := map[string]string{"Gmail": "https://mail.google.com", "ドキュメント": "https://docs.google.com/document", "スライド": "https://docs.google.com/presentation", "スプレッドシート": "https://docs.google.com/spreadsheets", "ドライブ": "https://drive.google.com", "Word": "https://www.office.com/launch/word", "Excel": "https://www.office.com/launch/excel", "PowerPoint": "https://www.office.com/launch/powerpoint", "Teams": "https://teams.microsoft.com", "Outlook": "https://outlook.live.com", "OneNote": "https://www.onenote.com", "Copilot": "https://copilot.microsoft.com", "Claude": "https://claude.ai", "ChatGPT": "https://chatgpt.com", "YouTube": "https://www.youtube.com", "GitHub": "https://github.com"}
	out := []AppLink{}
	for _, n := range names {
		out = append(out, AppLink{n, urls[n]})
	}
	return out
}
func defaultGroups() []AppGroup {
	mk := func(raw string) []AppLink {
		out := []AppLink{}
		for _, item := range strings.Split(raw, ";") {
			p := strings.SplitN(item, "|", 2)
			if len(p) == 2 {
				out = append(out, AppLink{p[0], "https://" + p[1]})
			}
		}
		return out
	}
	return []AppGroup{
		{"Google", mk("Gmail|mail.google.com;ドキュメント|docs.google.com/document;スライド|docs.google.com/presentation;スプレッドシート|docs.google.com/spreadsheets;ドライブ|drive.google.com;Colab|colab.research.google.com;カレンダー|calendar.google.com;マップ|maps.google.com;フォト|photos.google.com;Meet|meet.google.com;フォーム|docs.google.com/forms;Keep|keep.google.com;翻訳|translate.google.com;Gemini|gemini.google.com")},
		{"Microsoft", mk("Word|www.office.com/launch/word;Excel|www.office.com/launch/excel;PowerPoint|www.office.com/launch/powerpoint;Teams|teams.microsoft.com;Outlook|outlook.live.com;OneNote|www.onenote.com;Clipchamp|clipchamp.com;Copilot|copilot.microsoft.com;OneDrive|onedrive.live.com;Microsoft 365|www.microsoft365.com;To Do|to-do.office.com;Forms|forms.office.com;Loop|loop.cloud.microsoft;Planner|planner.cloud.microsoft;Designer|designer.microsoft.com;Whiteboard|whiteboard.office.com")},
		{"AI", mk("ChatGPT|chatgpt.com;Claude|claude.ai;Perplexity|www.perplexity.ai;Gemini|gemini.google.com;Copilot|copilot.microsoft.com;Grok|grok.com;Suno|suno.com;Sora|sora.com;Runway|runwayml.com;Cursor|cursor.com;Midjourney|www.midjourney.com")},
		{"SNS", mk("X|x.com;NOTE|note.com;TikTok|www.tiktok.com;YouTube|www.youtube.com;Netflix|www.netflix.com;Twitch|www.twitch.tv;Reddit|www.reddit.com;Facebook|www.facebook.com;Instagram|www.instagram.com;Threads|www.threads.net;LINE|line.me;Discord|discord.com;Pinterest|www.pinterest.com;LinkedIn|www.linkedin.com;Bluesky|bsky.app;Spotify|open.spotify.com")},
		{"クラウド", mk("Dropbox|www.dropbox.com;Google Drive|drive.google.com;OneDrive|onedrive.live.com;iCloud|www.icloud.com;Box|www.box.com;MEGA|mega.nz;Proton|proton.me;Adobe|www.adobe.com")},
		{"開発・ゲーム", mk("GitHub|github.com;Cursor|cursor.com;Unity|unity.com;Steam|store.steampowered.com;Epic Games|store.epicgames.com;Vercel|vercel.com;Scratch|scratch.mit.edu;TurboWarp|turbowarp.org")},
		{"ネット", mk("Amazon|www.amazon.co.jp;楽天市場|www.rakuten.co.jp;Yahoo! JAPAN|www.yahoo.co.jp;メルカリ|jp.mercari.com;Wikipedia|ja.wikipedia.org;Yahoo!ニュース|news.yahoo.co.jp;NHK|www3.nhk.or.jp;Zoom|zoom.us;Slack|slack.com;Notion|www.notion.so;Canva|www.canva.com;Figma|www.figma.com;Trello|trello.com;PayPay|paypay.ne.jp;Apple|www.apple.com")},
		{"Office", mk("Microsoft 365|www.microsoft365.com;Word|www.office.com/launch/word;Excel|www.office.com/launch/excel;PowerPoint|www.office.com/launch/powerpoint;Outlook|outlook.live.com;OneNote|www.onenote.com;OneDrive|onedrive.live.com;Teams|teams.microsoft.com;Forms|forms.office.com;Planner|planner.cloud.microsoft;Clipchamp|clipchamp.com")},
		{"ミニゲーム", []AppLink{{"ドライブ（内蔵）", "#nexus-game-0"}, {"スネーク（内蔵）", "#nexus-game-1"}, {"ターゲット（内蔵）", "#nexus-game-2"}}},
		{"学習", mk("Wikipedia|ja.wikipedia.org;Wiktionary|ja.wiktionary.org;Wikibooks|ja.wikibooks.org;Khan Academy|ja.khanacademy.org;NHK for School|www.nhk.or.jp/school;GeoGebra|www.geogebra.org;Desmos|www.desmos.com;TypingClub|www.typingclub.com;e-typing|www.e-typing.ne.jp")},
		{"ブラウザ・便利", mk("Chrome ウェブストア|chromewebstore.google.com;Firefox|www.mozilla.org/firefox;Brave|brave.com;Opera|www.opera.com;Vivaldi|vivaldi.com;DuckDuckGo|duckduckgo.com;Google翻訳|translate.google.com;DeepL|www.deepl.com;Internet Archive|archive.org;Speedtest|www.speedtest.net;Photopea|www.photopea.com;Excalidraw|excalidraw.com;CodePen|codepen.io")},
		{"文字化けアプリ", []AppLink{{"文字化けメーカー", "#nexus-garbler"}}},
	}
}
