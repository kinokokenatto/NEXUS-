//go:build js && wasm

package main

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"math"
	"math/rand"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"syscall/js"
	"time"
)

func initClock() {
	g := byID("aclt")
	if !g.IsNull() {
		h := ""
		for n := 1; n <= 12; n++ {
			a := float64(n) * 30 * math.Pi / 180
			x := 60 + math.Sin(a)*39
			y := 60 - math.Cos(a)*39 + 3
			h += fmt.Sprintf(`<text x="%.2f" y="%.2f" text-anchor="middle" class="aN">%d</text>`, x, y, n)
		}
		g.Set("innerHTML", h)
	}
	go func() {
		tick := time.NewTicker(time.Second)
		defer tick.Stop()
		for range tick.C {
			updateClock()
			if timerRunning {
				updateTimer()
			}
			sleepCheck()
		}
	}()
	updateClock()
}
func updateClock() {
	now := time.Now()
	fmtSetText("clk", now.Format("15:04:05"))
	fmtSetText("dt", now.Format("2006年1月2日 月曜日"))
	if g := byID("aclS"); !g.IsNull() {
		g.Call("setAttribute", "transform", fmt.Sprintf("rotate(%g 60 60)", float64(now.Second())*6))
	}
	if g := byID("aclM"); !g.IsNull() {
		g.Call("setAttribute", "transform", fmt.Sprintf("rotate(%g 60 60)", float64(now.Minute())*6+float64(now.Second())*.1))
	}
	if g := byID("aclH"); !g.IsNull() {
		g.Call("setAttribute", "transform", fmt.Sprintf("rotate(%g 60 60)", float64(now.Hour()%12)*30+float64(now.Minute())*.5))
	}
	fmtSetText("aclD", fmt.Sprintf("%d/%d（%s）", int(now.Month()), now.Day(), []string{"日", "月", "火", "水", "木", "金", "土"}[now.Weekday()]))
}
func initTimerStopwatch() {
	fmtSetText("td", "05:00")
	on("ts", "click", func(e js.Value) {
		if timerRunning {
			timerRunning = false
			timerDeadline = time.Time{}
			setStatus("td", "タイマー停止")
			return
		}
		mins, _ := strconv.Atoi(val("tm"))
		if mins < 1 {
			mins = 5
		}
		if mins > 999 {
			mins = 999
		}
		timerDeadline = time.Now().Add(time.Duration(mins) * time.Minute)
		timerRunning = true
		updateTimer()
	})
	on("tr", "click", func(e js.Value) {
		timerRunning = false
		mins, _ := strconv.Atoi(val("tm"))
		if mins < 1 {
			mins = 5
		}
		fmtSetText("td", fmt.Sprintf("%02d:00", mins))
	})
	on("swstart", "click", func(e js.Value) {
		if stopwatchRunning {
			stopwatchElapsed += time.Since(stopwatchStart)
			stopwatchRunning = false
			fmtSetText("swstart", "▶ 再開")
		} else {
			stopwatchStart = time.Now()
			stopwatchRunning = true
			fmtSetText("swstart", "⏸ 一時停止")
		}
		paintStopwatch()
	})
	on("swlap", "click", func(e js.Value) {
		elapsed := stopwatchElapsed
		if stopwatchRunning {
			elapsed += time.Since(stopwatchStart)
		}
		if elapsed < 10*time.Millisecond {
			return
		}
		prev := time.Duration(0)
		if len(stopwatchLaps) > 0 {
			prev = stopwatchLaps[len(stopwatchLaps)-1]
		}
		stopwatchLaps = append(stopwatchLaps, elapsed)
		h := byID("swlaps")
		if !h.IsNull() {
			li := doc.Call("createElement", "li")
			li.Set("innerHTML", fmt.Sprintf("<span>ラップ %d</span><span>%s　(%s)</span>", len(stopwatchLaps), formatDuration(elapsed-prev), formatDuration(elapsed)))
			h.Call("prepend", li)
			for h.Get("children").Length() > 50 {
				h.Get("lastElementChild").Call("remove")
			}
		}
	})
	on("swreset", "click", func(e js.Value) {
		stopwatchRunning = false
		stopwatchElapsed = 0
		stopwatchLaps = nil
		setHTML("swlaps", "")
		fmtSetText("swstart", "▶ スタート")
		paintStopwatch()
	})
	go func() {
		t := time.NewTicker(10 * time.Millisecond)
		defer t.Stop()
		for range t.C {
			if stopwatchRunning {
				paintStopwatch()
			}
		}
	}()
	// Web Audio BGM is generated locally from simple Go note patterns.
	on("bgmplay", "click", func(e js.Value) {
		if bgmPlaying {
			pauseBGM()
		} else {
			playBGM()
		}
	})
	on("bgmstop", "click", func(e js.Value) { stopBGM() })
	on("bgmrandom", "click", func(e js.Value) {
		sel := byID("bgmtrack")
		if sel.IsNull() {
			return
		}
		n := sel.Get("options").Length()
		if n > 0 {
			sel.Set("selectedIndex", rand.Intn(n))
			if bgmPlaying {
				stopBGM()
				playBGM()
			}
		}
	})
	on("bgmvol", "input", func(e js.Value) {
		if !bgmGain.IsUndefined() && !bgmGain.IsNull() {
			bgmGain.Get("gain").Set("value", parseNum(val("bgmvol"), 25)/100*.25)
		}
	})
	initMusic()
}
func updateTimer() {
	remain := time.Until(timerDeadline)
	if remain <= 0 {
		timerRunning = false
		fmtSetText("td", "00:00")
		beep()
		alert("タイマーが終了しました。")
		return
	}
	secs := int(remain.Seconds() + .999)
	fmtSetText("td", fmt.Sprintf("%02d:%02d", secs/60, secs%60))
}
func paintStopwatch() {
	d := stopwatchElapsed
	if stopwatchRunning {
		d += time.Since(stopwatchStart)
	}
	fmtSetText("swdisplay", formatDuration(d))
	setDisabled("swlap", d < 10*time.Millisecond)
}
func formatDuration(d time.Duration) string {
	total := int64(d / time.Millisecond)
	cs := total / 10 % 100
	sec := total / 1000 % 60
	min := total / 60000 % 60
	hr := total / 3600000
	if hr > 0 {
		return fmt.Sprintf("%02d:%02d:%02d.%02d", hr, min, sec, cs)
	}
	return fmt.Sprintf("%02d:%02d.%02d", min, sec, cs)
}
func beep() {
	ctx := win.Get("AudioContext")
	if ctx.IsUndefined() {
		ctx = win.Get("webkitAudioContext")
	}
	if ctx.IsUndefined() {
		return
	}
	a := ctx.New()
	o := a.Call("createOscillator")
	g := a.Call("createGain")
	o.Get("frequency").Set("value", 880)
	g.Get("gain").Set("value", .08)
	o.Call("connect", g)
	g.Call("connect", a.Get("destination"))
	o.Call("start")
	o.Call("stop", a.Get("currentTime").Float()+.3)
}
func playBGM() {
	ctx := win.Get("AudioContext")
	if ctx.IsUndefined() {
		ctx = win.Get("webkitAudioContext")
	}
	if ctx.IsUndefined() {
		fmtSetText("bgmstatus", "Web Audio非対応")
		return
	}
	if bgmContext.IsUndefined() || bgmContext.IsNull() {
		bgmContext = ctx.New()
		bgmGain = bgmContext.Call("createGain")
		bgmGain.Get("gain").Set("value", parseNum(val("bgmvol"), 25)/100*.25)
		bgmGain.Call("connect", bgmContext.Get("destination"))
	}
	if bgmContext.Get("state").String() == "suspended" {
		bgmContext.Call("resume")
	}
	bgmPlaying = true
	fmtSetText("bgmplay", "⏸ 一時停止")
	fmtSetText("bgmstatus", "再生中 · Go生成音源")
	if !bgmOsc.IsUndefined() && !bgmOsc.IsNull() {
		return
	}
	osc := bgmContext.Call("createOscillator")
	osc.Set("type", "triangle")
	osc.Get("frequency").Set("value", 220)
	osc.Call("connect", bgmGain)
	osc.Call("start")
	bgmOsc = osc
	go func() {
		scales := []float64{220, 246.94, 293.66, 329.63, 392, 440, 392, 329.63}
		i := 0
		t := time.NewTicker(550 * time.Millisecond)
		defer t.Stop()
		for range t.C {
			if !bgmPlaying {
				return
			}
			if !bgmOsc.IsNull() && !bgmOsc.IsUndefined() {
				bgmOsc.Get("frequency").Set("value", scales[i%len(scales)])
				i++
			}
		}
	}()
}
func pauseBGM() {
	bgmPlaying = false
	if !bgmContext.IsUndefined() && !bgmContext.IsNull() {
		bgmContext.Call("suspend")
	}
	fmtSetText("bgmplay", "▶ 再生")
	fmtSetText("bgmstatus", "一時停止")
}
func stopBGM() {
	bgmPlaying = false
	if !bgmOsc.IsUndefined() && !bgmOsc.IsNull() {
		bgmOsc.Call("stop")
		bgmOsc = js.Null()
	}
	if !bgmContext.IsUndefined() && !bgmContext.IsNull() {
		bgmContext.Call("close")
		bgmContext = js.Null()
		bgmGain = js.Null()
	}
	fmtSetText("bgmplay", "▶ 再生")
	fmtSetText("bgmstatus", "停止中")
}

func initMusic() {
	audio := byID("mpau")
	if audio.IsNull() {
		return
	}
	on("mpo", "click", func(e js.Value) { click("mpf") })
	on("mpf", "change", func(e js.Value) {
		files := byID("mpf").Get("files")
		for i := 0; i < files.Length(); i++ {
			f := files.Index(i)
			if f.Get("size").Int() > 50*1024*1024 {
				continue
			}
			u := win.Get("URL").Call("createObjectURL", f)
			item := doc.Call("createElement", "li")
			item.Set("textContent", f.Get("name").String())
			idx := i
			_ = idx
			item.Set("data-url", u.String())
			item.Set("data-name", f.Get("name").String())
			item.Set("tabIndex", 0)
			item.Set("role", "button")
			item.Set("className", "on")
			byID("mpq").Call("appendChild", item)
		}
		setVal("mpf", "")
		fmtSetText("mpst", fmt.Sprintf("%d曲", byID("mpq").Get("children").Length()))
	})
	on("mpq", "click", func(e js.Value) {
		li := e.Get("target").Call("closest", "li")
		if li.IsNull() {
			return
		}
		audio.Set("src", li.Call("getAttribute", "data-url"))
		audio.Call("play")
		fmtSetText("mpt", "♪ "+li.Call("getAttribute", "data-name").String())
	})
	on("mpl", "click", func(e js.Value) {
		if audio.Get("src").String() == "" {
			click("mpo")
			return
		}
		if audio.Get("paused").Bool() {
			audio.Call("play")
		} else {
			audio.Call("pause")
		}
	})
	on("mpn", "click", func(e js.Value) { moveTrack(1) })
	on("mpp", "click", func(e js.Value) {
		if audio.Get("currentTime").Float() > 3 {
			audio.Set("currentTime", 0)
		} else {
			moveTrack(-1)
		}
	})
	on("mpv", "input", func(e js.Value) { audio.Set("volume", parseNum(val("mpv"), .8)) })
	on("mps", "input", func(e js.Value) {
		d := audio.Get("duration").Float()
		if d > 0 {
			audio.Set("currentTime", parseNum(val("mps"), 0)/1000*d)
		}
	})
	on("mpx", "click", func(e js.Value) {
		audio.Call("pause")
		audio.Set("src", "")
		setHTML("mpq", "")
		fmtSetText("mpt", "—")
		fmtSetText("mpst", "ファイル未選択")
	})
	keep(js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) > 0 {
			fmtSetText("mpl", "▶")
			return nil
		}
		return nil
	}))
	ended := js.FuncOf(func(this js.Value, args []js.Value) any { moveTrack(1); return nil })
	keep(ended)
	audio.Set("onended", ended)
	tick := js.FuncOf(func(this js.Value, args []js.Value) any {
		d := audio.Get("duration").Float()
		cur := audio.Get("currentTime").Float()
		if d > 0 {
			byID("mps").Set("value", cur/d*1000)
		}
		fmtSetText("mpc", fmt.Sprintf("%d:%02d", int(cur)/60, int(cur)%60))
		if d > 0 {
			fmtSetText("mpd", fmt.Sprintf("%d:%02d", int(d)/60, int(d)%60))
		}
		return nil
	})
	keep(tick)
	audio.Set("ontimeupdate", tick)
}
func moveTrack(step int) {
	audio := byID("mpau")
	list := byID("mpq")
	if list.IsNull() || list.Get("children").Length() == 0 {
		return
	}
	idx := 0
	for i := 0; i < list.Get("children").Length(); i++ {
		if list.Get("children").Index(i).Get("classList").Call("contains", "on").Bool() {
			idx = i
			break
		}
	}
	idx = (idx + step + list.Get("children").Length()) % list.Get("children").Length()
	for i := 0; i < list.Get("children").Length(); i++ {
		item := list.Get("children").Index(i)
		item.Get("classList").Call("toggle", "on", i == idx)
	}
	item := list.Get("children").Index(idx)
	audio.Set("src", item.Call("getAttribute", "data-url"))
	audio.Call("play")
	fmtSetText("mpt", "♪ "+item.Call("getAttribute", "data-name").String())
}

// Weather forecasts use the same Open-Meteo service and representative prefectural capital points.
type Prefecture struct {
	Label    string
	Lat, Lon float64
	Note     string
}

var prefectures = map[string]Prefecture{
	"hokkaido": {"北海道", 43.0642, 141.3469, "札幌市付近"}, "aomori": {"青森県", 40.8244, 140.7400, "青森市付近"}, "iwate": {"岩手県", 39.7036, 141.1527, "盛岡市付近"}, "miyagi": {"宮城県", 38.2682, 140.8694, "仙台市付近"}, "akita": {"秋田県", 39.7186, 140.1024, "秋田市付近"}, "yamagata": {"山形県", 38.2404, 140.3633, "山形市付近"}, "fukushima": {"福島県", 37.7503, 140.4676, "福島市付近"}, "ibaraki": {"茨城県", 36.3418, 140.4468, "水戸市付近"}, "tochigi": {"栃木県", 36.5657, 139.8836, "宇都宮市付近"}, "gunma": {"群馬県", 36.3907, 139.0604, "前橋市付近"}, "saitama": {"埼玉県", 35.8617, 139.6455, "さいたま市付近"}, "chiba": {"千葉県", 35.6073, 140.1063, "千葉市付近"}, "tokyo": {"東京都", 35.6895, 139.6917, "新宿区付近"}, "kanagawa": {"神奈川県", 35.4478, 139.6425, "横浜市付近"}, "niigata": {"新潟県", 37.9026, 139.0236, "新潟市付近"}, "toyama": {"富山県", 36.6953, 137.2113, "富山市付近"}, "ishikawa": {"石川県", 36.5944, 136.6256, "金沢市付近"}, "fukui": {"福井県", 36.0652, 136.2216, "福井市付近"}, "yamanashi": {"山梨県", 35.6642, 138.5684, "甲府市付近"}, "nagano": {"長野県", 36.6513, 138.1810, "長野市付近"}, "gifu": {"岐阜県", 35.3912, 136.7223, "岐阜市付近"}, "shizuoka": {"静岡県", 34.9769, 138.3831, "静岡市付近"}, "aichi": {"愛知県", 35.1802, 136.9066, "名古屋市付近"}, "mie": {"三重県", 34.7303, 136.5086, "津市付近"}, "shiga": {"滋賀県", 35.0179, 135.8546, "大津市付近"}, "kyoto": {"京都府", 35.0116, 135.7681, "京都市付近"}, "osaka": {"大阪府", 34.6863, 135.5200, "大阪市付近"}, "hyogo": {"兵庫県", 34.6913, 135.1830, "神戸市付近"}, "nara": {"奈良県", 34.6851, 135.8329, "奈良市付近"}, "wakayama": {"和歌山県", 34.2260, 135.1675, "和歌山市付近"}, "tottori": {"鳥取県", 35.5039, 134.2377, "鳥取市付近"}, "shimane": {"島根県", 35.4723, 133.0505, "松江市付近"}, "okayama": {"岡山県", 34.6618, 133.9344, "岡山市付近"}, "hiroshima": {"広島県", 34.3963, 132.4596, "広島市付近"}, "yamaguchi": {"山口県", 34.1861, 131.4705, "山口市付近"}, "tokushima": {"徳島県", 34.0658, 134.5593, "徳島市付近"}, "kagawa": {"香川県", 34.3401, 134.0434, "高松市付近"}, "ehime": {"愛媛県", 33.8416, 132.7657, "松山市付近"}, "kochi": {"高知県", 33.5597, 133.5311, "高知市付近"}, "fukuoka": {"福岡県", 33.6064, 130.4183, "福岡市付近"}, "saga": {"佐賀県", 33.2494, 130.2988, "佐賀市付近"}, "nagasaki": {"長崎県", 32.7448, 129.8737, "長崎市付近"}, "kumamoto": {"熊本県", 32.7898, 130.7417, "熊本市付近"}, "oita": {"大分県", 33.2382, 131.6126, "大分市付近"}, "miyazaki": {"宮崎県", 31.9111, 131.4239, "宮崎市付近"}, "kagoshima": {"鹿児島県", 31.5602, 130.5581, "鹿児島市付近"}, "okinawa": {"沖縄県", 26.2124, 127.6809, "那覇市付近"},
}

func initWeather() {
	key, ok := storageGet("weatherPrefecture")
	if ok {
		var k string
		_ = json.Unmarshal([]byte(key), &k)
		if _, found := prefectures[k]; found {
			setVal("wxCity", k)
		}
	}
	pref := val("wxCity")
	if pref == "" {
		pref = "hyogo"
		setVal("wxCity", pref)
	}
	if p, ok := prefectures[pref]; ok {
		fmtSetText("wxAreaLabel", "対象："+p.Label+"の代表地点（"+p.Note+"）")
	}
	fmtSetText("wxd", "天気データは手動更新で取得します。")
	on("wxCity", "change", func(e js.Value) {
		storageSet("weatherPrefecture", val("wxCity"))
		if p, ok := prefectures[val("wxCity")]; ok {
			fmtSetText("wxAreaLabel", "対象："+p.Label+"の代表地点（"+p.Note+"）")
		}
		fmtSetText("wxd", "地域を変更しました。更新ボタンを押してください。")
		fmtSetText("wxs", "")
	})
	on("wb", "click", func(e js.Value) { loadWeather(true) })
	on("wmore", "click", func(e js.Value) {
		p := prefectures[val("wxCity")]
		openURL("https://www.google.com/search?q=" + url.QueryEscape(p.Label+" 天気"))
	})
	on("wx24Toggle", "click", func(e js.Value) {
		open := isHidden("wx24Panel")
		setHidden("wx24Panel", !open)
		setAttr("wx24Toggle", "aria-expanded", fmt.Sprint(open))
		if open {
			fmtSetText("wx24Toggle", "☔ 24時間降水量・時間別予報を閉じる　▲")
		} else {
			fmtSetText("wx24Toggle", "☔ 24時間降水量・時間別予報を見る　▼")
		}
	})
	if cfg.AutoNetwork {
		loadWeather(false)
	}
}
func loadWeather(manual bool) {
	if privacyAnonymous {
		fmtSetText("wxd", "通信匿名モードにより外部通信が停止されています。")
		return
	}
	p, ok := prefectures[val("wxCity")]
	if !ok {
		p = prefectures["hyogo"]
	}
	fmtSetText("wxd", "天気を取得しています…")
	query := fmt.Sprintf("https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&hourly=precipitation,temperature_2m&past_days=1&forecast_days=2&timezone=Asia%%2FTokyo", p.Lat, p.Lon)
	promise := win.Call("fetch", query)
	okResp := js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) == 0 {
			return nil
		}
		resp := args[0]
		if !resp.Get("ok").Bool() {
			fmtSetText("wxd", "天気データを取得できませんでした（HTTPエラー）。")
			return nil
		}
		jsonP := resp.Call("json")
		parse := js.FuncOf(func(this js.Value, args []js.Value) any {
			if len(args) == 0 {
				return nil
			}
			raw := win.Get("JSON").Call("stringify", args[0]).String()
			var w WeatherResponse
			if err := json.Unmarshal([]byte(raw), &w); err != nil {
				fmtSetText("wxd", "天気データの形式を読み取れませんでした。")
				return nil
			}
			renderWeather(p, w)
			return nil
		})
		keep(parse)
		jsonP.Call("then", parse)
		return nil
	})
	keep(okResp)
	fail := js.FuncOf(func(this js.Value, args []js.Value) any {
		fmtSetText("wxd", "天気を取得できませんでした。ネットワーク接続を確認して再試行してください。")
		return nil
	})
	keep(fail)
	promise.Call("then", okResp).Call("catch", fail)
}
func renderWeather(p Prefecture, w WeatherResponse) {
	icon, desc := weatherCode(w.Current.Code)
	fmtSetText("wxi", icon)
	fmtSetText("wxt", fmt.Sprintf("%.1f℃", w.Current.Temperature))
	fmtSetText("wxd", desc)
	fmtSetText("wxs", fmt.Sprintf("体感 %.1f℃\n湿度 %.0f%%\n風速 %.1f km/h", w.Current.Apparent, w.Current.Humidity, w.Current.Wind))
	fmtSetText("wxu", "更新："+time.Now().Format("2006-01-02 15:04")+"（Open-Meteo・"+p.Label+"代表地点）")
	past, next := 0.0, 0.0
	now := time.Now().In(time.Local)
	htmlRows := ""
	for i, stamp := range w.Hourly.Time {
		if i >= len(w.Hourly.Rain) {
			break
		}
		t, err := time.ParseInLocation("2006-01-02T15:04", stamp, time.Local)
		if err != nil {
			continue
		}
		if t.Before(now) && t.After(now.Add(-24*time.Hour)) {
			past += w.Hourly.Rain[i]
		} else if !t.Before(now) && t.Before(now.Add(24*time.Hour)) {
			next += w.Hourly.Rain[i]
			htmlRows += fmt.Sprintf(`<div class="wxHour"><b>%s</b><span>降水 %.1f mm</span></div>`, t.Format("15時"), w.Hourly.Rain[i])
		}
	}
	fmtSetText("wx24Past", fmt.Sprintf("%.1f mm", past))
	fmtSetText("wx24Next", fmt.Sprintf("%.1f mm", next))
	setHTML("wx24Hours", htmlRows)
	fmtSetText("wx24Note", "選択した都道府県の代表地点のモデル値です。実際の観測値・県内全域の値ではありません。")
}
func weatherCode(c int) (string, string) {
	switch c {
	case 0:
		return "☀️", "快晴"
	case 1:
		return "🌤️", "晴れ"
	case 2:
		return "⛅", "一部曇り"
	case 3:
		return "☁️", "曇り"
	case 45, 48:
		return "🌫️", "霧"
	case 51, 53, 55, 56, 57:
		return "🌦️", "霧雨"
	case 61, 63, 65, 66, 67:
		return "🌧️", "雨"
	case 71, 73, 75, 77:
		return "🌨️", "雪"
	case 80, 81, 82:
		return "🌧️", "にわか雨"
	case 85, 86:
		return "🌨️", "にわか雪"
	case 95, 96, 99:
		return "⛈️", "雷雨"
	}
	return "🌡️", "天気情報"
}

func initTranslation() {
	langs := []struct{ Code, Name string }{{"ja", "日本語"}, {"en", "英語"}, {"zh", "中国語"}, {"ko", "韓国語"}, {"fr", "フランス語"}, {"de", "ドイツ語"}, {"es", "スペイン語"}, {"it", "イタリア語"}, {"pt", "ポルトガル語"}, {"ru", "ロシア語"}, {"ar", "アラビア語"}, {"hi", "ヒンディー語"}, {"th", "タイ語"}, {"vi", "ベトナム語"}, {"id", "インドネシア語"}, {"nl", "オランダ語"}}
	h := ""
	for _, l := range langs {
		h += fmt.Sprintf(`<option value="%s">%s</option>`, l.Code, escape(l.Name))
	}
	setHTML("trFrom", h)
	setHTML("trTo", h)
	setVal("trFrom", "ja")
	setVal("trTo", "en")
	var pair map[string]string
	if loadJSON("trPair", &pair) {
		if pair["from"] != "" {
			setVal("trFrom", pair["from"])
		}
		if pair["to"] != "" {
			setVal("trTo", pair["to"])
		}
	}
	on("trFrom", "change", func(e js.Value) { storageSet("trPair", map[string]string{"from": val("trFrom"), "to": val("trTo")}) })
	on("trTo", "change", func(e js.Value) { storageSet("trPair", map[string]string{"from": val("trFrom"), "to": val("trTo")}) })
	on("trSwap", "click", func(e js.Value) {
		a, b := val("trFrom"), val("trTo")
		setVal("trFrom", b)
		setVal("trTo", a)
		storageSet("trPair", map[string]string{"from": b, "to": a})
	})
	on("trGo", "click", func(e js.Value) { translateText() })
	on("trClr", "click", func(e js.Value) { setVal("trIn", ""); setVal("trOut", ""); fmtSetText("trMsg", "") })
	on("trCp", "click", func(e js.Value) { copyText(val("trOut"), "trMsg") })
	on("trSp", "click", func(e js.Value) {
		s := val("trOut")
		if s == "" {
			return
		}
		synth := win.Get("speechSynthesis")
		utter := win.Get("SpeechSynthesisUtterance").New(s)
		utter.Set("lang", val("trTo"))
		synth.Call("speak", utter)
	})
	on("trIn", "keydown", func(e js.Value) {
		if e.Get("ctrlKey").Bool() && e.Get("key").String() == "Enter" {
			prevent(e)
			translateText()
		}
	})
	onDoc("click", func(e js.Value) {
		b := e.Get("target").Call("closest", "[data-ext]")
		if b.IsNull() {
			return
		}
		q := url.QueryEscape(val("trIn"))
		switch b.Get("dataset").Get("ext").String() {
		case "g":
			openURL("https://translate.google.com/?sl=" + val("trFrom") + "&tl=" + val("trTo") + "&text=" + q + "&op=translate")
		case "d":
			openURL("https://www.deepl.com/translator#" + val("trFrom") + "/" + val("trTo") + "/" + q)
		case "b":
			openURL("https://www.bing.com/translator?from=" + val("trFrom") + "&to=" + val("trTo") + "&text=" + q)
		}
	})
	fmtSetText("trNote", "ブラウザの内蔵翻訳APIが利用できない場合は、Google／DeepL／Bingの外部サイトを選択してください。入力は自動送信しません。")
}
func translateText() {
	input := val("trIn")
	if strings.TrimSpace(input) == "" {
		fmtSetText("trMsg", "翻訳する文章を入力してください。")
		return
	}
	if privacyAnonymous {
		fmtSetText("trMsg", "通信匿名モードでは外部翻訳を開けません。内蔵翻訳APIが使えるブラウザでお試しください。")
		return
	}
	translator := win.Get("Translator")
	if translator.IsUndefined() || translator.IsNull() || translator.Get("create").Type() != js.TypeFunction {
		fmtSetText("trMsg", "このブラウザでは内蔵翻訳APIが利用できません。下のGoogle／DeepL／Bingから翻訳サイトを開いてください。")
		return
	}
	opts := map[string]any{"sourceLanguage": val("trFrom"), "targetLanguage": val("trTo")}
	promise := translator.Call("create", opts)
	created := js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) == 0 {
			return nil
		}
		instance := args[0]
		translated := instance.Call("translate", input)
		done := js.FuncOf(func(this js.Value, args []js.Value) any {
			if len(args) > 0 {
				setVal("trOut", args[0].String())
				fmtSetText("trMsg", "翻訳しました。入力した文章は端末内で処理されました。")
			}
			return nil
		})
		keep(done)
		fail := js.FuncOf(func(this js.Value, args []js.Value) any {
			fmtSetText("trMsg", "翻訳できませんでした。言語ペアやブラウザ対応状況を確認してください。")
			return nil
		})
		keep(fail)
		translated.Call("then", done).Call("catch", fail)
		return nil
	})
	keep(created)
	failed := js.FuncOf(func(this js.Value, args []js.Value) any {
		fmtSetText("trMsg", "内蔵翻訳モデルを利用できません。外部翻訳サイトをご利用ください。")
		return nil
	})
	keep(failed)
	promise.Call("then", created).Call("catch", failed)
}

func initGarbler() {
	on("nxGarbleRun", "click", func(e js.Value) {
		input := val("nxGarbleIn")
		if input == "" {
			fmtSetText("nxGarbleStatus", "先に入力テキストを入力してください。")
			return
		}
		mode := val("nxGarbleMode")
		var out string
		switch mode {
		case "noise":
			pool := []rune("▓▒░╳ЖЯΩΨЖЩ§※〓∴∞†‡¤฿₿жヿﾇｼﾒ")
			r := []rune(input)
			for i := 0; i < max(12, min(8000, len(r)*2)); i++ {
				out += string(pool[rand.Intn(len(pool))])
				if i%61 == 60 {
					out += "\n"
				}
			}
		case "b64":
			out = "NEXUS_UTF8_B64:" + base64.StdEncoding.EncodeToString([]byte(input))
		default:
			symbols := []rune("縺繧譁蜿髫荳讖螟縲縻鬮驛�￠ƒ∂þæ¤§※〓▒▓░╳ЖЯΩΨжヿﾇｼﾒﾂ∴∞")
			i := 0
			for _, r := range input {
				if r == ' ' || r == '\n' || r == '\t' {
					out += string(r)
					continue
				}
				n := (int(r)*17 + i*13) % len(symbols)
				out += string(symbols[n])
				if i%7 == 3 {
					out += string(symbols[(n+9+i)%len(symbols)])
				}
				i++
			}
		}
		setVal("nxGarbleOut", out)
		fmtSetText("nxGarbleStatus", "変換しました。Base64は「元に戻す」で復元できます。")
	})
	on("nxGarbleRestore", "click", func(e js.Value) {
		s := val("nxGarbleOut")
		if strings.HasPrefix(s, "NEXUS_UTF8_B64:") {
			b, err := base64.StdEncoding.DecodeString(strings.TrimPrefix(s, "NEXUS_UTF8_B64:"))
			if err != nil {
				fmtSetText("nxGarbleStatus", "Base64を復元できませんでした。")
				return
			}
			setVal("nxGarbleIn", string(b))
			fmtSetText("nxGarbleStatus", "復元しました。")
		} else {
			fmtSetText("nxGarbleStatus", "文字化け風・ノイズ変換は復元できません。変換前の文章を保持してください。")
		}
	})
	on("nxGarbleSwap", "click", func(e js.Value) { setVal("nxGarbleIn", val("nxGarbleOut")) })
	on("nxGarbleCopy", "click", func(e js.Value) { copyText(val("nxGarbleOut"), "nxGarbleStatus") })
	on("nxGarbleClear", "click", func(e js.Value) {
		setVal("nxGarbleIn", "")
		setVal("nxGarbleOut", "")
		fmtSetText("nxGarbleStatus", "")
	})
	on("nxGarbleClose", "click", func(e js.Value) { closeModal("nxGarbler") })
}
func openGarbler() { openModal("nxGarbler"); focus("nxGarbleIn"); setHidden("lp", true) }

func initAssistantNews() {
	on("nxAssistantForm", "submit", func(e js.Value) { prevent(e); handleAssistant(val("nxAssistantInput")) })
	on("nxAssistantQuick", "click", func(e js.Value) {
		b := e.Get("target").Call("closest", "[data-nxquick]")
		if b.IsNull() {
			return
		}
		v := b.Get("dataset").Get("nxquick").String()
		switch v {
		case "メモを作成":
			setVal("nxAssistantInput", "メモ: ")
			focus("nxAssistantInput")
		case "文字化けアプリ":
			openGarbler()
		case "翻訳":
			setVal("nxAssistantInput", "翻訳: ")
			focus("nxAssistantInput")
		default:
			handleAssistant(v)
		}
	})
	on("nxAssistantLinks", "click", func(e js.Value) {
		b := e.Get("target").Call("closest", "[data-nxai]")
		if b.IsNull() {
			return
		}
		q := lastAssistantPrompt
		if q == "" {
			q = "この質問に答えてください。"
		}
		switch b.Get("dataset").Get("nxai").String() {
		case "chatgpt":
			openURL("https://chatgpt.com/?q=" + url.QueryEscape(q))
		case "gemini":
			openURL("https://gemini.google.com/app?prompt=" + url.QueryEscape(q))
		case "search":
			openURL("https://www.google.com/search?q=" + url.QueryEscape(q))
		}
	})
	news := []struct{ Name, Query, URL, Desc string }{{"NHK", "NHK ニュース", "https://www3.nhk.or.jp/news/", "国内・速報"}, {"Yahoo!ニュース", "Yahoo ニュース", "https://news.yahoo.co.jp/", "国内外の話題"}, {"Google ニュース", "Google ニュース", "https://news.google.com/", "幅広いニュース"}, {"BBC", "BBC News", "https://www.bbc.com/news", "海外ニュース"}, {"Reuters", "Reuters", "https://www.reuters.com/", "国際・経済"}, {"The Japan Times", "Japan Times", "https://www.japantimes.co.jp/", "英語ニュース"}}
	h := ""
	for _, n := range news {
		h += fmt.Sprintf(`<a href="%s" target="_blank" rel="noopener noreferrer"><b>%s</b><small>%s</small></a>`, n.URL, escape(n.Name), escape(n.Desc))
	}
	setHTML("newsShortcuts", h)
	on("newsSearchForm", "submit", func(e js.Value) {
		prevent(e)
		q := strings.TrimSpace(val("newsQuery"))
		if q != "" {
			openURL("https://news.google.com/search?q=" + url.QueryEscape(q))
		}
	})
	h = ""
	publishers := []struct{ N, U string }{{"NHK", "https://www3.nhk.or.jp/news/"}, {"共同通信", "https://www.kyodonews.jp/"}, {"時事通信", "https://www.jiji.com/"}, {"Reuters", "https://www.reuters.com/"}, {"BBC", "https://www.bbc.com/news"}, {"AP", "https://apnews.com/"}}
	for _, p := range publishers {
		h += fmt.Sprintf(`<a href="%s" target="_blank" rel="noopener noreferrer">%s</a>`, p.U, escape(p.N))
	}
	setHTML("newsPublishers", h)
	refreshNewsDate()
}
func refreshNewsDate() {
	fmtSetText("newsDate", "端末日時："+time.Now().Format("2006年1月2日（月） 15:04")+"。記事は各配信元のページでご確認ください。")
}
func handleAssistant(raw string) {
	q := strings.TrimSpace(raw)
	if q == "" {
		fmtSetText("nxAssistantReply", "質問や指示を入力してください。例：「メモ: アイデア」「Todo: 宿題」「予定 2026-11-10 14:00 会議」「計算: (12+8)*3」")
		return
	}
	lastAssistantPrompt = q
	setHidden("nxAssistantLinks", true)
	low := strings.ToLower(q)
	answer := ""
	if strings.HasPrefix(q, "メモ:") || strings.HasPrefix(q, "メモ：") {
		body := strings.TrimSpace(q[3:])
		if body != "" {
			memos = append(memos, Memo{ID: fmt.Sprintf("%x", time.Now().UnixNano()), Title: "Assistant+メモ", Body: body, T: time.Now().UnixMilli(), C: time.Now().UnixMilli()})
			storageSet("memos", memos)
			updateMemos()
			scroll("memoCard")
			answer = "メモを保存しました：" + body
		}
	}
	if answer == "" && (strings.HasPrefix(low, "todo:") || strings.HasPrefix(q, "Todo：") || strings.HasPrefix(q, "タスク:") || strings.HasPrefix(q, "やること:")) {
		body := strings.TrimSpace(q[strings.Index(q, ":")+1:])
		if body != "" {
			todos[todoDate] = append(dayTodos(), Todo{Text: body, Created: time.Now().Format(time.RFC3339)})
			saveTodos()
			updateTodos()
			scroll("todoCard")
			answer = "今日のTodoに追加しました：" + body
		}
	}
	if answer == "" && (strings.HasPrefix(q, "予定:") || strings.HasPrefix(q, "予定：") || strings.HasPrefix(q, "カレンダー:") || strings.HasPrefix(q, "カレンダー：")) {
		s := strings.TrimSpace(q[strings.IndexAny(q, ":：")+len(string([]rune(q)[strings.IndexAny(q, ":：")])):])
		d := nowDate()
		tm := ""
		re := regexp.MustCompile(`20\d{2}-\d{2}-\d{2}`)
		if m := re.FindString(s); m != "" {
			d = m
			s = strings.Replace(s, m, "", 1)
		}
		rt := regexp.MustCompile(`(?:[01]\d|2[0-3]):[0-5]\d`)
		if m := rt.FindString(s); m != "" {
			tm = m
			s = strings.Replace(s, m, "", 1)
		}
		s = strings.TrimSpace(s)
		if s != "" {
			events = append(events, Event{Date: d, Time: tm, Name: s})
			storageSet("ev", events)
			calendarSelected = d
			updateCalendar()
			answer = "予定表に追加しました：" + d + " " + tm + " " + s
		}
	}
	if answer == "" && (strings.HasPrefix(q, "検索:") || strings.HasPrefix(q, "検索：")) {
		term := strings.TrimSpace(q[3:])
		if term != "" {
			openURL("https://www.google.com/search?q=" + url.QueryEscape(term))
			answer = "検索ページを開きました。"
		}
	}
	if answer == "" && (strings.HasPrefix(q, "計算:") || strings.HasPrefix(q, "計算：")) {
		term := strings.TrimSpace(q[3:])
		v, err := evaluateArithmetic(term)
		if err == nil {
			answer = fmt.Sprintf("計算結果：%s = %s", term, formatFloat(v))
		} else {
			answer = "式を読み取れませんでした。例：(25 + 5) * 3"
		}
	}
	if answer == "" && regexp.MustCompile(`\d\s*[+＋*×/÷-]\s*\d`).MatchString(q) {
		clean := regexp.MustCompile(`[^\d０-９＋－＊×÷．（）().eE+\-*/\s]`).ReplaceAllString(q, "")
		if v, err := evaluateArithmetic(clean); err == nil {
			answer = "計算結果：" + q + " = " + formatFloat(v)
		}
	}
	if answer == "" && (strings.Contains(q, "時刻") || strings.Contains(q, "何時") || strings.Contains(q, "日付")) {
		answer = "現在の日時（端末のローカル時刻）：" + time.Now().Format("2006年1月2日 15:04:05")
	}
	if answer == "" && (strings.Contains(q, "文字化け") || strings.Contains(q, "garble")) {
		openGarbler()
		answer = "文字化けラボを開きました。"
	}
	if answer == "" && strings.Contains(q, "天気") {
		scroll("weatherCard")
		click("wb")
		answer = "選択している都道府県の天気を更新しています。"
	}
	if answer == "" && strings.Contains(q, "翻訳") {
		scroll("trCard")
		answer = "翻訳カードを開きました。文章を入力し、翻訳ボタンを押してください。"
	}
	if answer == "" && strings.Contains(q, "todo") {
		items := dayTodos()
		if len(items) == 0 {
			answer = "今日のTodoはありません。Todo: 内容 の形式で追加できます。"
		} else {
			var b []string
			for _, t := range items {
				mark := "□"
				if t.Done {
					mark = "☑"
				}
				b = append(b, mark+" "+t.Text)
			}
			answer = "今日のTodo：\n" + strings.Join(b, "\n")
		}
	}
	if answer == "" {
		answer = "その質問はローカル機能だけでは回答できません。下のChatGPT／Gemini／Web検索へ手動で引き継げます。\n\n対応例：メモ: 内容 / Todo: 内容 / 予定 2026-11-10 14:00 会議 / 計算: (12+8)*3 / 検索: キーワード"
		setHidden("nxAssistantLinks", false)
	}
	fmtSetText("nxAssistantReply", answer)
}

func evaluateArithmetic(expr string) (float64, error) {
	s := strings.NewReplacer("＋", "+", "－", "-", "＊", "*", "×", "*", "÷", "/", "．", ".", "（", "(", "）", ")").Replace(strings.ReplaceAll(expr, " ", ""))
	if s == "" || len(s) > 120 {
		return 0, fmt.Errorf("invalid")
	}
	i := 0
	var atom func() (float64, error)
	var mul func() (float64, error)
	var add func() (float64, error)
	atom = func() (float64, error) {
		if i < len(s) && (s[i] == '+' || s[i] == '-') {
			sign := 1.0
			if s[i] == '-' {
				sign = -1
			}
			i++
			x, e := atom()
			return sign * x, e
		}
		if i < len(s) && s[i] == '(' {
			i++
			v, e := add()
			if e != nil || i >= len(s) || s[i] != ')' {
				return 0, fmt.Errorf("paren")
			}
			i++
			return v, nil
		}
		start := i
		for i < len(s) && ((s[i] >= '0' && s[i] <= '9') || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+' && i > start && (s[i-1] == 'e' || s[i-1] == 'E') || s[i] == '-' && i > start && (s[i-1] == 'e' || s[i-1] == 'E')) {
			i++
		}
		if i == start {
			return 0, fmt.Errorf("number")
		}
		return strconv.ParseFloat(s[start:i], 64)
	}
	mul = func() (float64, error) {
		v, e := atom()
		if e != nil {
			return 0, e
		}
		for i < len(s) && (s[i] == '*' || s[i] == '/') {
			op := s[i]
			i++
			b, e := atom()
			if e != nil {
				return 0, e
			}
			if op == '*' {
				v *= b
			} else {
				if b == 0 {
					return 0, fmt.Errorf("zero")
				}
				v /= b
			}
		}
		return v, nil
	}
	add = func() (float64, error) {
		v, e := mul()
		if e != nil {
			return 0, e
		}
		for i < len(s) && (s[i] == '+' || s[i] == '-') {
			op := s[i]
			i++
			b, e := mul()
			if e != nil {
				return 0, e
			}
			if op == '+' {
				v += b
			} else {
				v -= b
			}
		}
		return v, nil
	}
	v, e := add()
	if e != nil || i != len(s) || math.IsNaN(v) || math.IsInf(v, 0) {
		return 0, fmt.Errorf("invalid")
	}
	return v, nil
}

func sleepCheck() {
	var s struct {
		Enabled bool   `json:"enabled"`
		Start   string `json:"start"`
		End     string `json:"end"`
	}
	if !loadJSON("nexusSleepRestrictionV1", &s) || !s.Enabled {
		return
	}
	now := time.Now()
	cur := now.Hour()*60 + now.Minute()
	a, _ := clockMinutes(s.Start)
	b, _ := clockMinutes(s.End)
	active := false
	if a < b {
		active = cur >= a && cur < b
	} else if a > b {
		active = cur >= a || cur < b
	}
	if active && isHidden("nexusSleepOverlay") {
		openModal("nexusSleepOverlay")
		fmtSetText("nexusSleepOverlayDetail", fmt.Sprintf("設定時間：%s〜%s", s.Start, s.End))
	}
}
func clockMinutes(s string) (int, bool) {
	p := strings.Split(s, ":")
	if len(p) != 2 {
		return 0, false
	}
	h, e1 := strconv.Atoi(p[0])
	m, e2 := strconv.Atoi(p[1])
	return h*60 + m, e1 == nil && e2 == nil
}
