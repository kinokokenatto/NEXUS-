//go:build js && wasm

package main

import (
	"fmt"
	"math"
	"sort"
	"strconv"
	"strings"
	"syscall/js"
	"time"
)

func saveTodos() { storageSet("nexusDailyTodos", todos) }
func dayTodos() []Todo {
	if todos == nil {
		todos = map[string][]Todo{}
	}
	if todos[todoDate] == nil {
		todos[todoDate] = []Todo{}
	}
	return todos[todoDate]
}
func updateTodos() {
	items := dayTodos()
	done := 0
	h := ""
	for i, t := range items {
		cls := ""
		checked := ""
		if t.Done {
			cls = "done"
			checked = "checked"
			done++
		}
		h += fmt.Sprintf(`<li class="%s"><input type="checkbox" data-tcheck="%d" %s aria-label="Todo完了"><span class="todoText">%s</span><button class="todoDel" type="button" data-tdel="%d" aria-label="Todoを削除">×</button></li>`, cls, i, checked, escape(t.Text), i)
	}
	if len(items) == 0 {
		h = `<li class="todoEmpty">Todoを追加してください</li>`
	}
	setHTML("todoList", h)
	setVal("todoDate", todoDate)
	fmtSetText("todoSummary", fmt.Sprintf("%sの完了 %d / %d 件", map[bool]string{true: "今日", false: "選択日"}[todoDate == nowDate()], done, len(items)))
}
func initMemoTodoCalendar() {
	on("mnNew", "click", func(e js.Value) { openMemo(nil) })
	on("mnSave", "click", func(e js.Value) { saveMemo() })
	on("mnPin", "click", func(e js.Value) {
		m := currentMemo()
		if m == nil {
			return
		}
		m.Pin = !m.Pin
		storageSet("memos", memos)
		fmtSetText("mnPin", map[bool]string{true: "📌 固定中", false: "📌 固定"}[m.Pin])
		setAttr("mnPin", "aria-pressed", fmt.Sprint(m.Pin))
		fmtSetText("mnSt", "変更を保存しました。")
	})
	on("mnDel", "click", func(e js.Value) {
		m := currentMemo()
		if m == nil {
			closeMemo()
			return
		}
		if !confirm("このメモを削除しますか？元に戻せません。") {
			return
		}
		next := []Memo{}
		for _, x := range memos {
			if x.ID != m.ID {
				next = append(next, x)
			}
		}
		memos = next
		storageSet("memos", memos)
		closeMemo()
		updateMemos()
	})
	on("mnClose", "click", func(e js.Value) {
		if currentMemo() != nil {
			m := currentMemo()
			m.Title = strings.TrimSpace(val("mnTitle"))
			m.Body = val("memo")
			m.T = time.Now().UnixMilli()
			storageSet("memos", memos)
		}
		closeMemo()
	})
	on("mnSearch", "input", func(e js.Value) { updateMemos() })
	for _, id := range []string{"mnTitle", "memo"} {
		on(id, "input", func(e js.Value) { fmtSetText("mnSt", "未保存の変更があります") })
	}
	on("mnList", "click", func(e js.Value) {
		b := e.Get("target").Call("closest", "[data-id]")
		if b.IsNull() {
			return
		}
		id := b.Get("dataset").Get("id").String()
		for i := range memos {
			if memos[i].ID == id {
				openMemo(&memos[i])
				break
			}
		}
	})
	on("todoForm", "submit", func(e js.Value) {
		prevent(e)
		t := strings.TrimSpace(val("todoInput"))
		if t == "" {
			return
		}
		if len(dayTodos()) >= 200 {
			alert("1日あたりのTodoは最大200件です。")
			return
		}
		todos[todoDate] = append(dayTodos(), Todo{Text: t, Created: time.Now().Format(time.RFC3339)})
		saveTodos()
		setVal("todoInput", "")
		updateTodos()
	})
	on("todoDate", "change", func(e js.Value) {
		if val("todoDate") != "" {
			todoDate = val("todoDate")
			updateTodos()
		}
	})
	on("todoToday", "click", func(e js.Value) { todoDate = nowDate(); updateTodos() })
	on("todoClearDone", "click", func(e js.Value) {
		out := []Todo{}
		for _, t := range dayTodos() {
			if !t.Done {
				out = append(out, t)
			}
		}
		todos[todoDate] = out
		saveTodos()
		updateTodos()
	})
	on("todoList", "click", func(e js.Value) {
		b := e.Get("target").Call("closest", "[data-tdel]")
		if b.IsNull() {
			return
		}
		i, _ := strconvAtoi(b.Get("dataset").Get("tdel").String())
		items := dayTodos()
		if i >= 0 && i < len(items) {
			todos[todoDate] = append(items[:i], items[i+1:]...)
			saveTodos()
			updateTodos()
		}
	})
	on("todoList", "change", func(e js.Value) {
		target := e.Get("target")
		d := target.Get("dataset").Get("tcheck")
		if d.IsUndefined() {
			return
		}
		i, _ := strconvAtoi(d.String())
		items := dayTodos()
		if i >= 0 && i < len(items) {
			items[i].Done = target.Get("checked").Bool()
			items[i].CompletedAt = ""
			if items[i].Done {
				items[i].CompletedAt = time.Now().Format(time.RFC3339)
			}
			todos[todoDate] = items
			saveTodos()
			updateTodos()
		}
	})
	initCalendarEvents()
}
func currentMemo() *Memo {
	for i := range memos {
		if memos[i].ID == selectedMemo {
			return &memos[i]
		}
	}
	return nil
}
func openMemo(m *Memo) {
	if m == nil {
		selectedMemo = ""
		setVal("mnTitle", "")
		setVal("memo", "")
		setAttr("mnPin", "aria-pressed", "false")
		fmtSetText("mnPin", "📌 固定")
	} else {
		selectedMemo = m.ID
		setVal("mnTitle", m.Title)
		setVal("memo", m.Body)
		setAttr("mnPin", "aria-pressed", fmt.Sprint(m.Pin))
		fmtSetText("mnPin", map[bool]string{true: "📌 固定中", false: "📌 固定"}[m.Pin])
	}
	setHidden("mnEd", false)
	fmtSetText("mnSt", "未保存の変更は保存ボタンを押してください。")
	updateMemos()
	focus("mnTitle")
}
func closeMemo() {
	setHidden("mnEd", true)
	selectedMemo = ""
	setVal("mnTitle", "")
	setVal("memo", "")
	fmtSetText("mnSt", "")
	updateMemos()
}
func saveMemo() {
	title := strings.TrimSpace(val("mnTitle"))
	body := val("memo")
	now := time.Now().UnixMilli()
	if selectedMemo == "" {
		if title == "" && strings.TrimSpace(body) == "" {
			fmtSetText("mnSt", "題名か本文を入力してください。")
			return
		}
		if len(memos) >= 200 {
			fmtSetText("mnSt", "メモは最大200件です。")
			return
		}
		id := fmt.Sprintf("%x", now)
		memos = append(memos, Memo{ID: id, Title: title, Body: body, T: now, C: now})
		selectedMemo = id
	} else {
		m := currentMemo()
		if m == nil {
			return
		}
		m.Title = title
		m.Body = body
		m.T = now
	}
	if !storageSet("memos", memos) {
		fmtSetText("mnSt", "保存できませんでした。ブラウザの保存容量を確認してください。")
		return
	}
	fmtSetText("mnSt", "✓ 保存しました "+time.Now().Format("15:04"))
	updateMemos()
}
func updateMemos() {
	q := strings.ToLower(strings.TrimSpace(val("mnSearch")))
	list := append([]Memo{}, memos...)
	sort.SliceStable(list, func(i, j int) bool {
		if list[i].Pin != list[j].Pin {
			return list[i].Pin
		}
		return list[i].T > list[j].T
	})
	h := ""
	n := 0
	for _, m := range list {
		if q != "" && !strings.Contains(strings.ToLower(m.Title+" "+m.Body), q) {
			continue
		}
		n++
		title := m.Title
		if title == "" {
			title = "無題のメモ"
		}
		if m.Pin {
			title = "📌 " + title
		}
		preview := strings.Join(strings.Fields(m.Body), " ")
		if len([]rune(preview)) > 60 {
			preview = string([]rune(preview)[:60]) + "…"
		}
		h += fmt.Sprintf(`<button type="button" class="mnItem" data-id="%s"><b>%s</b><span>%s</span><small>%s</small></button>`, escape(m.ID), escape(title), escape(preview), time.UnixMilli(m.T).Format("01/02 15:04"))
	}
	if n == 0 {
		msg := "メモはまだありません。「＋ 新規」で作成できます。"
		if len(memos) > 0 {
			msg = "一致するメモがありません。"
		}
		h += `<div class="mnEmpty">` + escape(msg) + `</div>`
	}
	setHTML("mnList", h)
}

func initCalendarEvents() {
	if v := byID("sdt"); !v.IsNull() {
		setVal("sdt", nowDate())
	}
	on("spv", "click", func(e js.Value) { calendarMonth = calendarMonth.AddDate(0, -1, 0); updateCalendar() })
	on("snx", "click", func(e js.Value) { calendarMonth = calendarMonth.AddDate(0, 1, 0); updateCalendar() })
	on("scg", "click", func(e js.Value) {
		b := e.Get("target").Call("closest", "[data-d]")
		if b.IsNull() {
			return
		}
		calendarSelected = b.Get("dataset").Get("d").String()
		setVal("sdt", calendarSelected)
		updateCalendar()
	})
	on("sf2", "submit", func(e js.Value) {
		prevent(e)
		d := val("sdt")
		t := val("stm")
		n := strings.TrimSpace(val("snm"))
		if len(n) == 0 || len(d) != 10 {
			alert("有効な日付と予定名を入力してください。")
			return
		}
		if len(events) >= 500 {
			alert("予定は最大500件です。")
			return
		}
		events = append(events, Event{Date: d, Time: t, Name: n})
		storageSet("ev", events)
		calendarSelected = d
		setVal("snm", "")
		fmtSetText("smsg", "予定表に追加しました："+d+" "+t+" "+n)
		updateCalendar()
	})
	on("sls", "click", func(e js.Value) {
		target := e.Get("target")
		if b := target.Call("closest", "[data-x]"); !b.IsNull() {
			i, _ := strconvAtoi(b.Get("dataset").Get("x").String())
			if i >= 0 && i < len(events) {
				events = append(events[:i], events[i+1:]...)
				storageSet("ev", events)
				updateCalendar()
			}
			return
		}
		if b := target.Call("closest", "[data-c]"); !b.IsNull() {
			i, _ := strconvAtoi(b.Get("dataset").Get("c").String())
			if i >= 0 && i < len(events) {
				events[i].Done = !events[i].Done
				storageSet("ev", events)
				updateCalendar()
			}
		}
	})
}
func updateCalendar() {
	month := calendarMonth
	year, mon := month.Year(), month.Month()
	first := time.Date(year, mon, 1, 0, 0, 0, 0, month.Location())
	days := time.Date(year, mon+1, 0, 0, 0, 0, 0, month.Location()).Day()
	today := nowDate()
	h := ""
	for i := 0; i < int(first.Weekday()); i++ {
		h += "<u></u>"
	}
	for d := 1; d <= days; d++ {
		stamp := fmt.Sprintf("%04d-%02d-%02d", year, int(mon), d)
		classes := []string{}
		if stamp == today {
			classes = append(classes, "tdy")
		}
		for _, ev := range events {
			if ev.Date == stamp && !ev.Done {
				classes = append(classes, "has")
				break
			}
		}
		if stamp == calendarSelected {
			classes = append(classes, "sel")
		}
		h += fmt.Sprintf(`<b class="%s" data-d="%s">%d</b>`, strings.Join(classes, " "), stamp, d)
	}
	setHTML("scg", h)
	fmtSetText("smo", fmt.Sprintf("%d年%d月", year, int(mon)))
	ids := make([]int, 0)
	for i, e := range events {
		if calendarSelected == "" || e.Date == calendarSelected {
			ids = append(ids, i)
		}
	}
	sort.SliceStable(ids, func(i, j int) bool {
		a, b := events[ids[i]], events[ids[j]]
		if a.Date != b.Date {
			return a.Date < b.Date
		}
		return a.Time < b.Time
	})
	h = ""
	for _, i := range ids {
		e := events[i]
		cls := ""
		checked := ""
		if e.Done {
			cls = "dn"
			checked = "checked"
		}
		h += fmt.Sprintf(`<li class="%s"><input type="checkbox" data-c="%d" %s aria-label="完了"><span>%s %s</span>%s<button type="button" data-x="%d">×</button></li>`, cls, i, checked, escape(e.Date), escape(e.Time), escape(e.Name), i)
	}
	setHTML("sls", h)
}

func initCalculator() {
	calcState = calculatorState{display: "0", newInput: true}
	keyList := []string{"C", "⌫", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "-", "1", "2", "3", "+", "±", "0", ".", "="}
	h := ""
	for _, k := range keyList {
		h += fmt.Sprintf(`<button type="button" data-k2="%s">%s</button>`, escape(k), escape(k))
	}
	setHTML("kg", h)
	renderCalculator()
	on("kg", "click", func(e js.Value) {
		b := e.Get("target").Call("closest", "[data-k2]")
		if b.IsNull() {
			return
		}
		calculatorKey(b.Get("dataset").Get("k2").String())
	})
	on("calc", "keydown", func(e js.Value) {
		key := e.Get("key").String()
		m := map[string]string{"*": "×", "/": "÷", "Enter": "=", "Backspace": "⌫", "Escape": "C"}
		if v, ok := m[key]; ok {
			key = v
		}
		if len(key) == 1 && strings.Contains("0123456789.+-×÷%=C⌫", key) {
			prevent(e)
			calculatorKey(key)
		}
	})
}
func renderCalculator() {
	fmtSetText("kdisp", calcState.display)
	fmtSetText("khist", calcState.history)
}
func calculatorKey(k string) {
	d := calcState.display
	switch {
	case k >= "0" && k <= "9":
		if calcState.newInput || d == "0" {
			calcState.display = k
		} else if len(d) < 18 {
			calcState.display += k
		}
		calcState.newInput = false
	case k == ".":
		if calcState.newInput {
			calcState.display = "0."
			calcState.newInput = false
		} else if !strings.Contains(d, ".") {
			calcState.display += "."
		}
	case k == "C":
		calcState = calculatorState{display: "0", newInput: true}
	case k == "⌫":
		if len(d) > 1 && !calcState.newInput {
			calcState.display = d[:len(d)-1]
		} else {
			calcState.display = "0"
		}
	case k == "±":
		if strings.HasPrefix(d, "-") {
			calcState.display = strings.TrimPrefix(d, "-")
		} else {
			calcState.display = "-" + d
		}
	case k == "%":
		f, _ := strconv.ParseFloat(d, 64)
		calcState.display = formatFloat(f / 100)
		calcState.newInput = true
	case strings.Contains("+-×÷", k):
		f, _ := strconv.ParseFloat(d, 64)
		if calcState.op != "" && !calcState.newInput {
			calcState.left = applyOp(calcState.left, calcState.op, f)
			calcState.display = formatFloat(calcState.left)
		} else {
			calcState.left = f
		}
		calcState.op = k
		calcState.history = calcState.display + " " + k
		calcState.newInput = true
	case k == "=" && calcState.op != "":
		f, _ := strconv.ParseFloat(d, 64)
		r := applyOp(calcState.left, calcState.op, f)
		calcState.history = fmt.Sprintf("%s %s %s =", formatFloat(calcState.left), calcState.op, d)
		calcState.display = formatFloat(r)
		calcState.op = ""
		calcState.newInput = true
	}
	renderCalculator()
}

func applyOp(a float64, op string, b float64) float64 {
	switch op {
	case "+":
		return a + b
	case "-":
		return a - b
	case "×":
		return a * b
	case "÷":
		if b == 0 {
			return math.NaN()
		}
		return a / b
	}
	return b
}
func formatFloat(v float64) string {
	if math.IsNaN(v) || math.IsInf(v, 0) {
		return "エラー"
	}
	return strconv.FormatFloat(v, 'g', 12, 64)
}

// Board records use the original NEXUS storage key and JSON schema.
type BoardRecord struct {
	ID        string `json:"id"`
	Type      string `json:"type"`
	Title     string `json:"title"`
	Body      string `json:"body"`
	CreatedAt string `json:"createdAt"`
	UpdatedAt string `json:"updatedAt"`
}

var boardRecords []BoardRecord
var activeBoardID string

func loadBoard() { boardRecords = nil; loadJSON("nexusBulletinRecordsV1", &boardRecords) }
func openBoard() { loadBoard(); openModal("nexusBoardModal"); resetBoardEditor(); renderBoard() }
func resetBoardEditor() {
	activeBoardID = ""
	setVal("nexusBoardType", "thought")
	setVal("nexusBoardTitle", "")
	setVal("nexusBoardBody", "")
	setDisabled("nexusBoardDelete", true)
	fmtSetText("nexusBoardEditorHeading", "✍️ 記録を書く")
	fmtSetText("nexusBoardStatus", "記録はこのブラウザ内に保存されます。")
}
func renderBoard() {
	sort.SliceStable(boardRecords, func(i, j int) bool { return boardRecords[i].UpdatedAt > boardRecords[j].UpdatedAt })
	h := ""
	for _, r := range boardRecords {
		h += fmt.Sprintf(`<button type="button" class="nexusBoardEntry" data-board="%s"><span class="entryTop"><span class="entryType">%s</span><time>%s</time></span><strong>%s</strong><span class="entryPreview">%s</span></button>`, escape(r.ID), escape(boardType(r.Type)), escape(r.UpdatedAt), escape(r.Title), escape(truncate(r.Body, 125)))
	}
	setHTML("nexusBoardEntries", h)
	fmtSetText("nexusBoardCount", fmt.Sprintf("%d件", len(boardRecords)))
	setHidden("nexusBoardEmpty", len(boardRecords) > 0)
}
func boardType(v string) string {
	m := map[string]string{"thought": "主の最近の感想", "diary": "近況・日記", "notice": "お知らせ", "idea": "アイデア・ひらめき", "other": "その他"}
	if x := m[v]; x != "" {
		return x
	}
	return "その他"
}
func truncate(s string, n int) string {
	r := []rune(strings.Join(strings.Fields(s), " "))
	if len(r) > n {
		return string(r[:n]) + "…"
	}
	return string(r)
}
func saveBoard() {
	title := strings.TrimSpace(val("nexusBoardTitle"))
	body := strings.TrimSpace(val("nexusBoardBody"))
	if title == "" || body == "" {
		fmtSetText("nexusBoardStatus", "タイトルと本文を入力してください。")
		return
	}
	if len([]rune(title)) > 100 || len([]rune(body)) > 4000 {
		fmtSetText("nexusBoardStatus", "タイトルは100文字、本文は4000文字以内にしてください。")
		return
	}
	now := time.Now().Format(time.RFC3339)
	typ := val("nexusBoardType")
	found := false
	for i := range boardRecords {
		if boardRecords[i].ID == activeBoardID {
			boardRecords[i].Type = typ
			boardRecords[i].Title = title
			boardRecords[i].Body = body
			boardRecords[i].UpdatedAt = now
			found = true
		}
	}
	if !found {
		if len(boardRecords) >= 100 {
			fmtSetText("nexusBoardStatus", "記録は最大100件です。TXT保存後に古い記録を削除してください。")
			return
		}
		activeBoardID = fmt.Sprintf("%x", time.Now().UnixNano())
		boardRecords = append(boardRecords, BoardRecord{ID: activeBoardID, Type: typ, Title: title, Body: body, CreatedAt: now, UpdatedAt: now})
	}
	if !storageSet("nexusBulletinRecordsV1", boardRecords) {
		fmtSetText("nexusBoardStatus", "保存に失敗しました。ブラウザの保存容量を確認してください。")
		return
	}
	setDisabled("nexusBoardDelete", false)
	fmtSetText("nexusBoardEditorHeading", "✍️ 記録を編集")
	fmtSetText("nexusBoardStatus", "保存しました。この端末のブラウザ内だけに保存されています。")
	renderBoard()
}
func initBoard() {
	on("nexusBoardForm", "submit", func(e js.Value) { prevent(e); saveBoard() })
	on("nexusBoardNew", "click", func(e js.Value) { resetBoardEditor() })
	on("nexusBoardEntries", "click", func(e js.Value) {
		b := e.Get("target").Call("closest", "[data-board]")
		if b.IsNull() {
			return
		}
		id := b.Get("dataset").Get("board").String()
		for _, r := range boardRecords {
			if r.ID == id {
				activeBoardID = id
				setVal("nexusBoardType", r.Type)
				setVal("nexusBoardTitle", r.Title)
				setVal("nexusBoardBody", r.Body)
				setDisabled("nexusBoardDelete", false)
				fmtSetText("nexusBoardEditorHeading", "✍️ 記録を編集")
				fmtSetText("nexusBoardStatus", "編集中："+r.Title)
				break
			}
		}
	})
	on("nexusBoardDelete", "click", func(e js.Value) {
		if activeBoardID == "" {
			return
		}
		if !confirm("この記録を削除しますか？元に戻せません。") {
			return
		}
		out := []BoardRecord{}
		for _, r := range boardRecords {
			if r.ID != activeBoardID {
				out = append(out, r)
			}
		}
		boardRecords = out
		storageSet("nexusBulletinRecordsV1", boardRecords)
		resetBoardEditor()
		renderBoard()
	})
	on("nexusBoardExport", "click", func(e js.Value) {
		if len(boardRecords) == 0 {
			fmtSetText("nexusBoardStatus", "書き出す記録がありません。")
			return
		}
		s := "NEXUS 掲示板記録\n出力日時：" + time.Now().Format("2006-01-02 15:04") + "\n\n"
		for _, r := range boardRecords {
			s += "━━━━━━━━━━━━━━━━━━━━\n［" + boardType(r.Type) + "］ " + r.Title + "\n更新：" + r.UpdatedAt + "\n\n" + r.Body + "\n\n"
		}
		download("NEXUS_掲示板記録_"+nowDate()+".txt", s, "text/plain;charset=utf-8")
		fmtSetText("nexusBoardStatus", "TXTファイルに書き出しました。")
	})
}
