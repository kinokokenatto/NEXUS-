//go:build js && wasm

package main

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"math"
	"net/url"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"syscall/js"
	"time"
)

var drawingTool = "pen"
var drawingLastX, drawingLastY float64
var pendingBackup map[string]*string
var pendingBackupRaw string
var pendingRestoreEncrypted bool
var securityReportText string
var urlCheckedHost string
var sourceEditorLoaded bool
var selectedStorageKey string
var selectedStorageVisible bool
var devFastMode bool
var devAdmin bool
var sleepTemporarilyDisabledUntil time.Time
var gameMode = "target"
var gameX, gameY float64
var gameScore int
var gameControlsBound bool

var appStorageKeys = []string{
	"cfg", "apps", "bm", "memo", "memos", "ev", "nexusDailyTodos", "draw", "drawBg", "trPair",
	"nexusBulletinRecordsV1", "nexusDevPrefs", "nexusScreenProtectMode", "nexusCommunicationAnonMode",
}

func exists(id string) bool { v := byID(id); return !v.IsNull() && !v.IsUndefined() }

// Drawing: pointer events, simple brush styles, undo/redo and PNG persistence.
func initDrawing() {
	drawCanvas = byID("dc")
	if drawCanvas.IsNull() || drawCanvas.IsUndefined() {
		return
	}
	drawCtx = drawCanvas.Call("getContext", "2d")
	if raw, ok := storageGet("drawBg"); ok {
		setVal("dbgcol", strings.Trim(raw, `"`))
	}
	if raw, ok := storageGet("draw"); ok && raw != "" {
		restoreCanvasData(raw)
	} else {
		clearDrawingCanvas()
	}
	on("drawTools", "click", func(e js.Value) {
		b := e.Get("target").Call("closest", "[data-t]")
		if b.IsNull() {
			return
		}
		drawingTool = b.Get("dataset").Get("t").String()
		buttons := qsa("#drawTools [data-t]")
		for i := 0; i < buttons.Length(); i++ {
			buttons.Index(i).Get("classList").Call("toggle", "on", buttons.Index(i).Get("dataset").Get("t").String() == drawingTool)
		}
	})
	on("dc", "pointerdown", func(e js.Value) {
		if drawingTool == "text" {
			drawTextAt(e)
			return
		}
		drawDown = true
		p := canvasPoint(e)
		drawingLastX, drawingLastY = p[0], p[1]
		drawCanvas.Call("setPointerCapture", e.Get("pointerId"))
		snapshotDrawing()
		drawCtx.Call("beginPath")
		drawCtx.Call("moveTo", drawingLastX, drawingLastY)
	})
	on("dc", "pointermove", func(e js.Value) {
		if !drawDown {
			return
		}
		p := canvasPoint(e)
		x, y := p[0], p[1]
		ctx := drawCtx
		size := parseNum(val("dz"), 5)
		color := val("dcol")
		if color == "" {
			color = "#2a6bff"
		}
		ctx.Set("lineWidth", size)
		ctx.Set("lineCap", "round")
		ctx.Set("lineJoin", "round")
		switch drawingTool {
		case "eraser":
			ctx.Set("globalCompositeOperation", "destination-out")
			ctx.Set("strokeStyle", "rgba(0,0,0,1)")
		case "marker":
			ctx.Set("globalCompositeOperation", "source-over")
			ctx.Set("globalAlpha", .28)
			ctx.Set("strokeStyle", color)
			ctx.Set("lineWidth", size*2.4)
		case "neon":
			ctx.Set("globalCompositeOperation", "source-over")
			ctx.Set("strokeStyle", color)
			ctx.Set("shadowColor", color)
			ctx.Set("shadowBlur", 14)
		case "rainbow":
			ctx.Set("globalCompositeOperation", "source-over")
			ctx.Set("strokeStyle", fmt.Sprintf("hsl(%d 100%% 55%%)", int(math.Mod(float64(time.Now().UnixMilli()/20), 360))))
		default:
			ctx.Set("globalCompositeOperation", "source-over")
			ctx.Set("strokeStyle", color)
		}
		ctx.Call("lineTo", x, y)
		ctx.Call("stroke")
		ctx.Set("globalAlpha", 1)
		ctx.Set("shadowBlur", 0)
		ctx.Set("globalCompositeOperation", "source-over")
		drawCtx.Call("beginPath")
		drawCtx.Call("moveTo", x, y)
		drawingLastX, drawingLastY = x, y
	})
	endDraw := func(e js.Value) {
		if drawDown {
			drawDown = false
			drawCtx.Call("beginPath")
			persistDrawing()
		}
	}
	on("dc", "pointerup", endDraw)
	on("dc", "pointercancel", endDraw)
	on("dc", "pointerleave", endDraw)
	on("dbgapply", "click", func(e js.Value) {
		c := val("dbgcol")
		if c == "" {
			c = "#ffffff"
		}
		drawCtx.Set("fillStyle", c)
		drawCtx.Call("fillRect", 0, 0, drawCanvas.Get("width"), drawCanvas.Get("height"))
		snapshotDrawing()
		persistDrawing()
	})
	on("dun", "click", func(e js.Value) {
		if len(drawUndo) == 0 {
			return
		}
		drawRedo = append(drawRedo, drawCanvas.Call("toDataURL").String())
		data := drawUndo[len(drawUndo)-1]
		drawUndo = drawUndo[:len(drawUndo)-1]
		restoreCanvasData(data)
		persistDrawing()
	})
	on("dredo", "click", func(e js.Value) {
		if len(drawRedo) == 0 {
			return
		}
		drawUndo = append(drawUndo, drawCanvas.Call("toDataURL").String())
		data := drawRedo[len(drawRedo)-1]
		drawRedo = drawRedo[:len(drawRedo)-1]
		restoreCanvasData(data)
		persistDrawing()
	})
	on("dcl", "click", func(e js.Value) {
		if !confirm("キャンバスを消去しますか？") {
			return
		}
		snapshotDrawing()
		clearDrawingCanvas()
		persistDrawing()
	})
	on("dimgbtn", "click", func(e js.Value) { click("dimgfile") })
	on("dimgfile", "change", func(e js.Value) {
		files := byID("dimgfile").Get("files")
		if files.Length() == 0 {
			return
		}
		f := files.Index(0)
		if f.Get("size").Int() > 10*1024*1024 {
			alert("画像は10MB以下にしてください。")
			return
		}
		reader := win.Get("FileReader").New()
		cb := js.FuncOf(func(this js.Value, args []js.Value) any {
			img := win.Get("Image").New()
			load := js.FuncOf(func(this js.Value, args []js.Value) any {
				snapshotDrawing()
				w := drawCanvas.Get("width").Float()
				h := drawCanvas.Get("height").Float()
				ratio := math.Min(w/img.Get("width").Float(), h/img.Get("height").Float())
				dw, dh := img.Get("width").Float()*ratio, img.Get("height").Float()*ratio
				drawCtx.Call("drawImage", img, (w-dw)/2, (h-dh)/2, dw, dh)
				persistDrawing()
				return nil
			})
			keep(load)
			img.Set("onload", load)
			img.Set("src", reader.Get("result"))
			return nil
		})
		keep(cb)
		reader.Set("onload", cb)
		reader.Call("readAsDataURL", f)
	})
	on("dsave", "click", func(e js.Value) {
		downloadDataURL("NEXUS_drawing_"+nowDate()+".png", drawCanvas.Call("toDataURL", "image/png").String())
	})
	on("dcp", "click", func(e js.Value) { copyText(drawCanvas.Call("toDataURL", "image/png").String(), "dmsg") })
}
func initDrawingCanvas() {
	if drawCanvas.IsNull() || drawCanvas.IsUndefined() {
		drawCanvas = byID("dc")
		if !drawCanvas.IsNull() {
			drawCtx = drawCanvas.Call("getContext", "2d")
		}
	}
	if drawCanvas.IsNull() || drawCanvas.IsUndefined() {
		return
	}
	if drawCtx.IsUndefined() || drawCtx.IsNull() {
		drawCtx = drawCanvas.Call("getContext", "2d")
	}
	if raw, ok := storageGet("draw"); ok && raw != "" {
		restoreCanvasData(raw)
	}
}
func canvasPoint(e js.Value) []float64 {
	r := drawCanvas.Call("getBoundingClientRect")
	sx := drawCanvas.Get("width").Float() / math.Max(1, r.Get("width").Float())
	sy := drawCanvas.Get("height").Float() / math.Max(1, r.Get("height").Float())
	return []float64{(e.Get("clientX").Float() - r.Get("left").Float()) * sx, (e.Get("clientY").Float() - r.Get("top").Float()) * sy}
}
func snapshotDrawing() {
	if drawCanvas.IsUndefined() || drawCanvas.IsNull() {
		return
	}
	drawUndo = append(drawUndo, drawCanvas.Call("toDataURL").String())
	if len(drawUndo) > 30 {
		drawUndo = drawUndo[1:]
	}
	drawRedo = nil
}
func persistDrawing() {
	if drawCanvas.IsUndefined() || drawCanvas.IsNull() {
		return
	}
	storageSet("draw", drawCanvas.Call("toDataURL", "image/png").String())
	storageSet("drawBg", val("dbgcol"))
}
func clearDrawingCanvas() {
	if drawCanvas.IsNull() || drawCanvas.IsUndefined() {
		return
	}
	drawCtx.Set("fillStyle", "#ffffff")
	drawCtx.Call("fillRect", 0, 0, drawCanvas.Get("width"), drawCanvas.Get("height"))
}
func restoreCanvasData(data string) {
	if drawCanvas.IsNull() || drawCanvas.IsUndefined() {
		return
	}
	img := win.Get("Image").New()
	cb := js.FuncOf(func(this js.Value, args []js.Value) any {
		drawCtx.Call("clearRect", 0, 0, drawCanvas.Get("width"), drawCanvas.Get("height"))
		drawCtx.Call("drawImage", img, 0, 0, drawCanvas.Get("width"), drawCanvas.Get("height"))
		return nil
	})
	keep(cb)
	img.Set("onload", cb)
	img.Set("src", data)
}
func drawTextAt(e js.Value) {
	p := canvasPoint(e)
	ctx := drawCtx
	size := parseNum(val("dfont"), 48)
	if size < 10 {
		size = 10
	}
	ctx.Set("fillStyle", val("dcol"))
	ctx.Set("font", fmt.Sprintf("%gpx sans-serif", size))
	snapshotDrawing()
	ctx.Call("fillText", val("dtext"), p[0], p[1])
	persistDrawing()
}

// Backups preserve the original NEXUS local-storage keys and data values.
type BackupEnvelope struct {
	Format      string             `json:"format"`
	Version     int                `json:"version"`
	ExportedAt  string             `json:"exportedAt,omitempty"`
	Application string             `json:"application,omitempty"`
	Data        map[string]*string `json:"data,omitempty"`
	Cipher      string             `json:"cipher,omitempty"`
	KDF         string             `json:"kdf,omitempty"`
	Iterations  int                `json:"iterations,omitempty"`
	Salt        string             `json:"salt,omitempty"`
	IV          string             `json:"iv,omitempty"`
	Ciphertext  string             `json:"ciphertext,omitempty"`
}

const backupPBKDF2Iterations = 250000

func collectAppData() map[string]*string {
	out := map[string]*string{}
	for _, k := range appStorageKeys {
		if raw, ok := storageGet(k); ok {
			v := raw
			out[k] = &v
		} else {
			out[k] = nil
		}
	}
	return out
}

func encodeBackup(data map[string]*string) string {
	payload := BackupEnvelope{Format: "NEXUS_BACKUP", Version: 1, ExportedAt: time.Now().UTC().Format(time.RFC3339), Application: "NEXUS SUPER3.1", Data: data}
	b, _ := json.MarshalIndent(payload, "", "  ")
	return string(b)
}

func initBackupSecurity() {
	setHidden("backupFile", true)
	setHidden("backupApplyRow", true)
	on("backupExport", "click", func(e js.Value) {
		data := collectAppData()
		raw := encodeBackup(data)
		if byID("backupEncrypt").Get("checked").Bool() {
			pass := val("backupPassphrase")
			if len([]rune(pass)) < 12 {
				fmtSetText("backupStatus", "暗号化には12文字以上のパスフレーズが必要です。")
				return
			}
			encryptBackup(raw, pass)
		} else {
			download("NEXUS-backup-"+nowDate()+".json", raw, "application/json;charset=utf-8")
			fmtSetText("backupStatus", "通常のJSONバックアップを書き出しました。このファイルは暗号化されていません。安全に保管してください。")
		}
	})
	on("backupChoose", "click", func(e js.Value) { click("backupFile") })
	on("backupFile", "change", func(e js.Value) {
		files := byID("backupFile").Get("files")
		if files.Length() == 0 {
			return
		}
		f := files.Index(0)
		if f.Get("size").Int() > 30*1024*1024 {
			fmtSetText("backupStatus", "バックアップは30 MiB以下にしてください。")
			return
		}
		reader := win.Get("FileReader").New()
		cb := js.FuncOf(func(this js.Value, args []js.Value) any {
			raw := reader.Get("result").String()
			pendingBackupRaw = raw
			pendingRestoreEncrypted = false
			var env BackupEnvelope
			if json.Unmarshal([]byte(raw), &env) != nil {
				fmtSetText("backupStatus", "JSONファイルを読み取れません。NEXUSバックアップを選択してください。")
				return nil
			}
			if env.Format == "NEXUS_ENCRYPTED_BACKUP" && env.Version == 1 {
				pendingRestoreEncrypted = true
				setHidden("backupApplyRow", false)
				setHidden("backupPreview", false)
				setHTML("backupPreview", "<b>暗号化バックアップ</b><p>元のバックアップで使用した12文字以上のパスフレーズを入力し、「復元を実行」を押してください。</p>")
				fmtSetText("backupStatus", "暗号化ファイルを検出しました。パスフレーズを入力して復元を実行してください。")
				return nil
			}
			if env.Format != "NEXUS_BACKUP" || env.Version != 1 || env.Data == nil {
				fmtSetText("backupStatus", "NEXUS_BACKUP形式・バージョン1のファイルではありません。")
				return nil
			}
			pendingBackup = env.Data
			if err := validateBackupData(pendingBackup); err != nil {
				pendingBackup = nil
				fmtSetText("backupStatus", "インポートを中止しました："+err.Error())
				return nil
			}
			fmtSetText("backupStatus", fmt.Sprintf("復元候補：%d項目。内容を確認してから復元してください。", len(pendingBackup)))
			showBackupPreview()
			return nil
		})
		keep(cb)
		reader.Set("onload", cb)
		reader.Call("readAsText", f)
	})
	on("backupApply", "click", func(e js.Value) {
		if pendingRestoreEncrypted {
			pass := val("backupPassphrase")
			if len([]rune(pass)) < 12 {
				fmtSetText("backupStatus", "パスフレーズは12文字以上で入力してください。")
				return
			}
			decryptBackup(pendingBackupRaw, pass)
			return
		}
		applyBackupData(pendingBackup)
	})
	on("backupCancel", "click", func(e js.Value) {
		pendingBackup = nil
		pendingBackupRaw = ""
		pendingRestoreEncrypted = false
		setHidden("backupApplyRow", true)
		setHidden("backupPreview", true)
		fmtSetText("backupStatus", "復元をキャンセルしました。")
	})
	on("securityReportRun", "click", func(e js.Value) { runSecurityReport() })
	on("securityReportDownload", "click", func(e js.Value) {
		if securityReportText != "" {
			download("NEXUS_security_report_"+nowDate()+".txt", securityReportText, "text/plain;charset=utf-8")
		}
	})
	on("securityReportCopy", "click", func(e js.Value) { copyText(securityReportText, "securityReportSummary") })
	on("securityAuditShowLast", "click", func(e js.Value) {
		if s, ok := storageGet("nexusLastSecurityReport"); ok {
			fmtSetText("securityReportOutput", s)
			securityReportText = s
			fmtSetText("securityReportSummary", "前回保存されたローカル診断レポートです。")
		}
	})
}

func validateBackupValue(key, raw string) error {
	var v any
	if err := json.Unmarshal([]byte(raw), &v); err != nil {
		return fmt.Errorf("保存データ「%s」が正しいJSONではありません", key)
	}
	valid := false
	switch key {
	case "cfg", "nexusDailyTodos", "trPair", "nexusDevPrefs":
		_, valid = v.(map[string]any)
	case "apps", "bm", "memos", "ev", "nexusBulletinRecordsV1":
		_, valid = v.([]any)
	case "memo", "draw", "drawBg":
		_, valid = v.(string)
	case "nexusScreenProtectMode", "nexusCommunicationAnonMode":
		_, valid = v.(bool)
	}
	if !valid {
		return fmt.Errorf("保存データ「%s」の形式が想定と異なります", key)
	}
	return nil
}

func validateBackupData(data map[string]*string) error {
	found := 0
	total := 0
	for k, v := range data {
		if !allowedBackupKey(k) {
			continue
		}
		found++
		if v == nil {
			continue
		}
		total += len(*v)
		if len(*v) > 7500000 || total > 24*1024*1024 {
			return fmt.Errorf("バックアップの保存データが上限を超えています")
		}
		if err := validateBackupValue(k, *v); err != nil {
			return err
		}
	}
	if found == 0 {
		return fmt.Errorf("復元できるNEXUSデータがありません")
	}
	return nil
}

func showBackupPreview() {
	if pendingBackup == nil {
		return
	}
	count := 0
	bytes := 0
	labels := []string{}
	for k, v := range pendingBackup {
		if !allowedBackupKey(k) {
			continue
		}
		count++
		labels = append(labels, k)
		if v != nil {
			bytes += len(*v)
		}
	}
	sort.Strings(labels)
	h := "<b>復元される項目</b><ul>"
	for _, k := range labels {
		h += "<li>" + escape(k) + "</li>"
	}
	h += "</ul>"
	h += fmt.Sprintf("<p>保存項目：%d / 概算サイズ：約%d KiB</p><p>バックアップに含まれないキーは変更されません。</p>", count, bytes*2/1024)
	setHTML("backupPreview", h)
	setHidden("backupPreview", false)
	setHidden("backupApplyRow", false)
}

func applyBackupData(data map[string]*string) {
	if len(data) == 0 {
		fmtSetText("backupStatus", "復元データが空です。")
		return
	}
	if err := validateBackupData(data); err != nil {
		fmtSetText("backupStatus", "復元を中止しました："+err.Error())
		return
	}
	download("NEXUS-before-restore-"+nowDate()+".json", encodeBackup(collectAppData()), "application/json;charset=utf-8")
	count := 0
	for k, v := range data {
		if !allowedBackupKey(k) {
			continue
		}
		if v == nil {
			storageRemove(k)
		} else {
			storageSetRaw(k, *v)
		}
		count++
	}
	fmtSetText("backupStatus", fmt.Sprintf("%d項目を復元しました。画面を再読み込みします。", count))
	win.Call("setTimeout", keepTimeout(func() { win.Get("location").Call("reload") }), 800)
}

func allowedBackupKey(k string) bool {
	for _, x := range appStorageKeys {
		if x == k {
			return true
		}
	}
	return false
}
func storageSetRaw(k, v string) {
	defer func() { _ = recover() }()
	win.Get("localStorage").Call("setItem", k, v)
}
func keepTimeout(f func()) js.Func {
	cb := js.FuncOf(func(this js.Value, args []js.Value) any { f(); return nil })
	keep(cb)
	return cb
}
func uint8Bytes(b []byte) js.Value {
	v := win.Get("Uint8Array").New(len(b))
	js.CopyBytesToJS(v, b)
	return v
}
func jsBytes(v js.Value) []byte {
	arr := win.Get("Uint8Array").New(v)
	b := make([]byte, arr.Get("byteLength").Int())
	js.CopyBytesToGo(b, arr)
	return b
}
func randomBytes(n int) js.Value {
	v := win.Get("Uint8Array").New(n)
	win.Get("crypto").Call("getRandomValues", v)
	return v
}

func deriveBackupKey(pass string, salt js.Value, done func(js.Value), fail func()) {
	subtle := win.Get("crypto").Get("subtle")
	enc := win.Get("TextEncoder").New().Call("encode", pass)
	base := subtle.Call("importKey", "raw", enc, "PBKDF2", false, []any{"deriveKey"})
	ok := js.FuncOf(func(this js.Value, args []js.Value) any {
		params := map[string]any{"name": "PBKDF2", "salt": salt, "iterations": backupPBKDF2Iterations, "hash": "SHA-256"}
		algo := map[string]any{"name": "AES-GCM", "length": 256}
		p := subtle.Call("deriveKey", params, args[0], algo, false, []any{"encrypt", "decrypt"})
		good := js.FuncOf(func(this js.Value, a []js.Value) any {
			if len(a) > 0 {
				done(a[0])
			}
			return nil
		})
		bad := js.FuncOf(func(this js.Value, a []js.Value) any { fail(); return nil })
		keep(good)
		keep(bad)
		p.Call("then", good).Call("catch", bad)
		return nil
	})
	bad := js.FuncOf(func(this js.Value, args []js.Value) any { fail(); return nil })
	keep(ok)
	keep(bad)
	base.Call("then", ok).Call("catch", bad)
}

func encryptBackup(raw, pass string) {
	salt := randomBytes(16)
	iv := randomBytes(12)
	deriveBackupKey(pass, salt, func(key js.Value) {
		plain := win.Get("TextEncoder").New().Call("encode", raw)
		p := win.Get("crypto").Get("subtle").Call("encrypt", map[string]any{"name": "AES-GCM", "iv": iv}, key, plain)
		ok := js.FuncOf(func(this js.Value, args []js.Value) any {
			if len(args) == 0 {
				return nil
			}
			env := BackupEnvelope{Format: "NEXUS_ENCRYPTED_BACKUP", Version: 1, Cipher: "AES-256-GCM", KDF: "PBKDF2-SHA-256", Iterations: backupPBKDF2Iterations, Salt: base64.StdEncoding.EncodeToString(jsBytes(salt)), IV: base64.StdEncoding.EncodeToString(jsBytes(iv)), Ciphertext: base64.StdEncoding.EncodeToString(jsBytes(args[0]))}
			b, _ := json.MarshalIndent(env, "", "  ")
			download("NEXUS-backup-"+nowDate()+"-encrypted.json", string(b), "application/json;charset=utf-8")
			fmtSetText("backupStatus", "AES-256-GCM暗号化バックアップを作成しました。元のNEXUS形式と互換です。パスフレーズを別途安全に保管してください。")
			return nil
		})
		ng := js.FuncOf(func(this js.Value, args []js.Value) any {
			fmtSetText("backupStatus", "暗号化に失敗しました。HTTPSまたはlocalhostの環境で開いているか確認してください。")
			return nil
		})
		keep(ok)
		keep(ng)
		p.Call("then", ok).Call("catch", ng)
	}, func() {
		fmtSetText("backupStatus", "暗号化キーを生成できませんでした。ブラウザのWeb Crypto対応を確認してください。")
	})
}

func decryptBackup(raw, pass string) {
	var env BackupEnvelope
	if err := json.Unmarshal([]byte(raw), &env); err != nil {
		fmtSetText("backupStatus", "暗号化バックアップを読み込めません。")
		return
	}
	if env.Format != "NEXUS_ENCRYPTED_BACKUP" || env.Version != 1 || env.Cipher != "AES-256-GCM" || env.KDF != "PBKDF2-SHA-256" || env.Iterations != backupPBKDF2Iterations {
		fmtSetText("backupStatus", "未対応または不正な暗号化形式です。")
		return
	}
	salt, e1 := base64.StdEncoding.DecodeString(env.Salt)
	iv, e2 := base64.StdEncoding.DecodeString(env.IV)
	cipher, e3 := base64.StdEncoding.DecodeString(env.Ciphertext)
	if e1 != nil || e2 != nil || e3 != nil || len(salt) != 16 || len(iv) != 12 || len(cipher) < 16 {
		fmtSetText("backupStatus", "暗号化データの形式が正しくありません。")
		return
	}
	deriveBackupKey(pass, uint8Bytes(salt), func(key js.Value) {
		p := win.Get("crypto").Get("subtle").Call("decrypt", map[string]any{"name": "AES-GCM", "iv": uint8Bytes(iv)}, key, uint8Bytes(cipher))
		ok := js.FuncOf(func(this js.Value, args []js.Value) any {
			if len(args) == 0 {
				return nil
			}
			plain := string(jsBytes(args[0]))
			var inner BackupEnvelope
			if json.Unmarshal([]byte(plain), &inner) != nil || inner.Format != "NEXUS_BACKUP" || inner.Version != 1 {
				fmtSetText("backupStatus", "復号されたデータがNEXUSバックアップ形式ではありません。")
				return nil
			}
			if err := validateBackupData(inner.Data); err != nil {
				fmtSetText("backupStatus", "インポートを中止しました："+err.Error())
				return nil
			}
			pendingBackup = inner.Data
			pendingRestoreEncrypted = false
			showBackupPreview()
			fmtSetText("backupStatus", fmt.Sprintf("暗号化を解除・検証しました。%d項目を確認して復元を実行してください。", len(pendingBackup)))
			return nil
		})
		ng := js.FuncOf(func(this js.Value, args []js.Value) any {
			fmtSetText("backupStatus", "復号できません。パスフレーズが違うか、ファイルが破損しています。")
			return nil
		})
		keep(ok)
		keep(ng)
		p.Call("then", ok).Call("catch", ng)
	}, func() { fmtSetText("backupStatus", "暗号化キーを生成できませんでした。") })
}

// Security report: local static checks only; it does not claim to scan the device.
func runSecurityReport() {
	lines := []string{"NEXUS SUPER3.1 / Go WebAssembly セキュリティ・プライバシー診断", "実行日時：" + time.Now().Format(time.RFC3339), "検査範囲：このページのDOMとNEXUSローカル保存領域のみ", ""}
	add := func(label, detail string) { lines = append(lines, "[INFO] "+label+"："+detail) }
	storage := win.Get("localStorage")
	keys := 0
	bytes := 0
	for i := 0; i < storage.Get("length").Int(); i++ {
		k := storage.Call("key", i).String()
		v := storage.Call("getItem", k).String()
		keys++
		bytes += len(k) + len(v)
	}
	add("ローカル保存領域", fmt.Sprintf("%dキー、約%d KiB（キー名とサイズのみ）", keys, bytes*2/1024))
	add("暗号化バックアップ", "AES-256-GCM + PBKDF2-SHA-256（21万回）を利用可能。通常保存データそのものは暗号化されません")
	add("自動外部通信", map[bool]string{true: "許可（天気自動更新時にOpen-Meteoへ接続）", false: "停止（手動更新のみ）"}[cfg.AutoNetwork])
	add("通信匿名モード", map[bool]string{true: "有効（NEXUSからの外部アクセスを一部遮断）", false: "無効"}[privacyAnonymous])
	add("画面保護", map[bool]string{true: "有効", false: "無効"}[screenProtected])
	add("コンテンツセキュリティポリシー", "Go WASMと同一配信元の資産を許可するページ設定を使用")
	add("外部リンク", fmt.Sprintf("%d件。クリック時に移動するリンクであり、自動通信の検査ではありません", qsa("a[href^='http']").Length()))
	add("実行方式", "アプリケーションロジックはGo/WASM。HTML/CSSは表示層、boot.jsはWASM起動専用")
	add("未検査事項", "OS、ブラウザ拡張機能、端末全体のマルウェア、外部サイトの安全性、DNS、証明書、リダイレクト先")
	securityReportText = strings.Join(lines, "\n")
	storageSet("nexusLastSecurityReport", securityReportText)
	fmtSetText("securityReportOutput", securityReportText)
	fmtSetText("securityReportSummary", fmt.Sprintf("ローカル診断を完了しました。保存領域%dキー・約%d KiB。端末全体の安全性を保証する診断ではありません。", keys, bytes*2/1024))
	setDisabled("securityReportDownload", false)
	setDisabled("securityReportCopy", false)
	setDisabled("securityAuditShowLast", false)
	setHidden("secScore", true)
	setHidden("securityPriorityActions", true)
}

// URL checker evaluates URL syntax and suspicious-looking patterns without network access.
func checkURL() {
	raw := strings.TrimSpace(val("urlCheckerInput"))
	if raw == "" {
		fmtSetText("urlCheckerSummary", "URLを入力してください。")
		return
	}
	candidate := raw
	if !strings.Contains(candidate, "://") {
		candidate = "https://" + candidate
	}
	u, err := url.Parse(candidate)
	if err != nil || u.Host == "" || u.User != nil || (u.Scheme != "https" && u.Scheme != "http") {
		fmtSetText("urlCheckerSummary", "URL形式が正しくありません。http:// または https:// のURLを入力してください。")
		setHidden("urlCheckerRisk", true)
		setDisabled("urlCheckerCopyHost", true)
		return
	}
	host := strings.ToLower(u.Hostname())
	urlCheckedHost = host
	score := 0
	findings := []string{}
	add := func(n int, s string) { score += n; findings = append(findings, s) }
	if u.Scheme != "https" {
		add(20, "HTTPSではなくHTTPです。通信が暗号化されません。")
	}
	if strings.Contains(host, "xn--") {
		add(18, "国際化ドメイン（Punycode）を含みます。表示文字列を注意して確認してください。")
	}
	if strings.Count(host, ".") >= 4 {
		add(10, "サブドメインが多いドメインです。")
	}
	if len(host) > 55 {
		add(8, "ホスト名が長めです。")
	}
	if regexp.MustCompile(`\d{1,3}(?:\.\d{1,3}){3}`).MatchString(host) {
		add(18, "IPアドレス形式のホスト名です。")
	}
	if strings.Contains(host, "@") || strings.Contains(u.RawQuery, "@") || strings.Contains(u.RawQuery, "redirect=") || strings.Contains(u.RawQuery, "url=") {
		add(12, "URLにユーザー情報・転送先指定など紛らわしい要素が含まれる可能性があります。")
	}
	if len(u.RawQuery) > 300 {
		add(5, "クエリ文字列が非常に長いです。")
	}
	score = min(100, score)
	level := "低"
	if score >= 45 {
		level = "高"
	} else if score >= 20 {
		level = "中"
	}
	fmtSetText("urlCheckerSummary", fmt.Sprintf("形式上の注意度：%s（%d/100）。このスコアはURL文字列のルールベース指標であり、サイトの安全性評価ではありません。", level, score))
	setHidden("urlCheckerRisk", false)
	fmtSetText("urlCheckerRiskLabel", "形式上の注意度："+level)
	fmtSetText("urlCheckerRiskScore", fmt.Sprint(score))
	if f := byID("urlCheckerRiskFill"); !f.IsNull() {
		f.Get("style").Set("width", fmt.Sprintf("%d%%", score))
	}
	fmtSetText("urlCheckerRiskNote", "DNS・TLS証明書・ページ内容・マルウェア・評判は調べていません。警告がなくても安全を保証しません。")
	parsed := fmt.Sprintf("<b>ホスト名：</b>%s<br><b>スキーム：</b>%s<br><b>ポート：</b>%s<br><b>パス：</b>%s", escape(host), escape(u.Scheme), escape(u.Port()), escape(u.EscapedPath()))
	setHTML("urlCheckerParsed", parsed)
	setHidden("urlCheckerParsed", false)
	setDisabled("urlCheckerCopyHost", false)
	if len(findings) == 0 {
		findings = append(findings, "このルールセットで目立った特徴は見つかりませんでした。安全性を保証するものではありません。")
	}
	h := "<ul>"
	for _, f := range findings {
		h += "<li>" + escape(f) + "</li>"
	}
	h += "</ul>"
	setHTML("urlCheckerResults", h)
}

// Developer tools use allow-listed operations only; no eval, shell, or arbitrary code execution.
func initDeveloperAndSleep() {
	if exists("nexusSleepEnabled") {
		var s struct {
			Enabled bool   `json:"enabled"`
			Start   string `json:"start"`
			End     string `json:"end"`
		}
		if loadJSON("nexusSleepRestrictionV1", &s) {
			byID("nexusSleepEnabled").Set("checked", s.Enabled)
			setVal("nexusSleepStart", s.Start)
			setVal("nexusSleepEnd", s.End)
		}
	}
	on("nexusSleepSave", "click", func(e js.Value) {
		s := map[string]any{"enabled": byID("nexusSleepEnabled").Get("checked").Bool(), "start": val("nexusSleepStart"), "end": val("nexusSleepEnd")}
		if _, ok := clockMinutes(val("nexusSleepStart")); !ok {
			fmtSetText("nexusSleepStatus", "開始時刻を確認してください。")
			return
		}
		if _, ok := clockMinutes(val("nexusSleepEnd")); !ok {
			fmtSetText("nexusSleepStatus", "終了時刻を確認してください。")
			return
		}
		storageSet("nexusSleepRestrictionV1", s)
		fmtSetText("nexusSleepStatus", "おやすみ設定を保存しました。ページ起動中に時間帯を確認します。")
	})
	on("nexusSleepTest", "click", func(e js.Value) {
		openModal("nexusSleepOverlay")
		fmtSetText("nexusSleepOverlayDetail", "テスト表示（1分間）")
		win.Call("setTimeout", keepTimeout(func() {
			if time.Now().After(sleepTemporarilyDisabledUntil) {
				closeModal("nexusSleepOverlay")
			}
		}), 60000)
	})
	on("nexusSleepBreak", "click", func(e js.Value) {
		sleepTemporarilyDisabledUntil = time.Now().Add(5 * time.Minute)
		closeModal("nexusSleepOverlay")
		fmtSetText("nexusSleepStatus", "5分間、一時解除しました。")
	})
	on("nexusSleepManage", "click", func(e js.Value) { closeModal("nexusSleepOverlay"); openModal("nexusSleepModal") })
	on("nexusDevEnable", "click", func(e js.Value) {
		developerEnabled = true
		setHidden("nexusDevDetails", false)
		fmtSetText("nexusDevModeStatus", "Go/WASM 開発者モード：有効（このページのセッションのみ）")
		runDevChecks()
	})
	on("nexusDevDisable", "click", func(e js.Value) {
		developerEnabled = false
		devAdmin = false
		setHidden("nexusDevDetails", true)
		setHidden("nexusDevAdminTools", true)
		setHidden("nexusDevAdminGate", false)
	})
	on("nexusDevRunChecks", "click", func(e js.Value) { runDevChecks() })
	on("nexusDevExport", "click", func(e js.Value) {
		download("NEXUS_dev_report_"+nowDate()+".txt", text("nexusDevOutput"), "text/plain;charset=utf-8")
	})
	on("nexusDevAdminEnable", "click", func(e js.Value) {
		if !confirm("管理者権限をこのページのセッション中だけ有効にします。保存データの編集・削除が可能になります。続けますか？") {
			return
		}
		devAdmin = true
		setHidden("nexusDevAdminGate", true)
		setHidden("nexusDevAdminTools", false)
		refreshDevStorage()
	})
	on("nexusDevAdminLock", "click", func(e js.Value) {
		devAdmin = false
		setHidden("nexusDevAdminTools", true)
		setHidden("nexusDevAdminGate", false)
	})
	on("nexusDevStorageRefresh", "click", func(e js.Value) { refreshDevStorage() })
	on("nexusDevStorageSelect", "change", func(e js.Value) {
		selectedStorageKey = val("nexusDevStorageSelect")
		selectedStorageVisible = false
		setHidden("nexusDevStorageValue", true)
		fmtSetText("nexusDevStorageStatus", "キーを選択しました。値の表示には「値を表示／隠す」を押してください。")
	})
	on("nexusDevStorageReveal", "click", func(e js.Value) {
		if !devAdmin || selectedStorageKey == "" {
			return
		}
		raw, ok := storageGet(selectedStorageKey)
		if !ok {
			return
		}
		if selectedStorageVisible {
			setHidden("nexusDevStorageValue", true)
			selectedStorageVisible = false
		} else {
			setVal("nexusDevStorageValue", raw)
			setHidden("nexusDevStorageValue", false)
			selectedStorageVisible = true
		}
	})
	on("nexusDevStorageSave", "click", func(e js.Value) {
		if !devAdmin || selectedStorageKey == "" {
			return
		}
		raw := val("nexusDevStorageValue")
		if !json.Valid([]byte(raw)) {
			fmtSetText("nexusDevStorageStatus", "JSONとして正しくありません。保存しませんでした。")
			return
		}
		storageSetRaw(selectedStorageKey, raw)
		fmtSetText("nexusDevStorageStatus", "保存しました。")
		refreshSystemMonitor()
	})
	on("nexusDevStorageCopy", "click", func(e js.Value) {
		if selectedStorageKey != "" {
			if raw, ok := storageGet(selectedStorageKey); ok {
				copyText(raw, "nexusDevStorageStatus")
			}
		}
	})
	on("nexusDevStorageDownload", "click", func(e js.Value) {
		if selectedStorageKey != "" {
			if raw, ok := storageGet(selectedStorageKey); ok {
				download("NEXUS_"+selectedStorageKey+".json", raw, "application/json")
			}
		}
	})
	on("nexusDevStorageDelete", "click", func(e js.Value) {
		if !devAdmin || selectedStorageKey == "" || !confirm("保存キー「"+selectedStorageKey+"」を削除しますか？") {
			return
		}
		storageRemove(selectedStorageKey)
		refreshDevStorage()
		fmtSetText("nexusDevStorageStatus", "削除しました。")
	})
	on("nexusDevFullExport", "click", func(e js.Value) {
		if !devAdmin {
			return
		}
		download("NEXUS_full_snapshot_"+nowDate()+".json", encodeBackup(collectAppData()), "application/json")
	})
	on("nexusDevFullImportChoose", "click", func(e js.Value) { click("nexusDevImportFile") })
	on("nexusDevImportFile", "change", func(e js.Value) {
		files := byID("nexusDevImportFile").Get("files")
		if files.Length() == 0 {
			return
		}
		reader := win.Get("FileReader").New()
		cb := js.FuncOf(func(this js.Value, args []js.Value) any {
			var env BackupEnvelope
			if json.Unmarshal([]byte(reader.Get("result").String()), &env) != nil || env.Format != "NEXUS_BACKUP" {
				fmtSetText("nexusDevStorageImportStatus", "NEXUS形式のスナップショットではありません。")
				return nil
			}
			pendingBackup = env.Data
			setDisabled("nexusDevFullImportApply", false)
			setDisabled("nexusDevFullImportCancel", false)
			fmtSetText("nexusDevStorageImportStatus", fmt.Sprintf("%d項目を検出しました。復元前に退避ファイルをダウンロードします。", len(pendingBackup)))
			return nil
		})
		keep(cb)
		reader.Set("onload", cb)
		reader.Call("readAsText", files.Index(0))
	})
	on("nexusDevFullImportApply", "click", func(e js.Value) {
		if !devAdmin || len(pendingBackup) == 0 {
			return
		}
		if !confirm("現在の保存データを退避してから、選択した内容で復元します。続けますか？") {
			return
		}
		applyBackupData(pendingBackup)
	})
	on("nexusDevFullImportCancel", "click", func(e js.Value) {
		pendingBackup = nil
		setDisabled("nexusDevFullImportApply", true)
		setDisabled("nexusDevFullImportCancel", true)
		fmtSetText("nexusDevStorageImportStatus", "キャンセルしました。")
	})
	on("nexusDevCommandRun", "click", func(e js.Value) { runDevCommand() })
	on("nexusDevCommand", "keydown", func(e js.Value) {
		if e.Get("key").String() == "Enter" {
			prevent(e)
			runDevCommand()
		}
	})
	on("nexusDevForceScan", "click", func(e js.Value) { runDevChecks() })
	on("nexusDevForceReload", "click", func(e js.Value) {
		if confirm("NEXUSを再読み込みしますか？") {
			win.Get("location").Call("reload")
		}
	})
	on("nexusDevEmergencyClose", "click", func(e js.Value) {
		for _, id := range []string{"dm", "gm", "securityPanel", "urlCheckerModal", "codeBridgeModal", "nxGarbler", "newsPanel", "nxDockAssistant", "lp", "cp"} {
			closeModal(id)
		}
	})
	on("nexusDevQuickOpen", "click", func(e js.Value) {
		switch val("nexusDevQuickTarget") {
		case "board":
			openBoard()
		case "sleep":
			openModal("nexusSleepModal")
		case "code":
			openModal("codeBridgeModal")
		case "url":
			openModal("urlCheckerModal")
		case "security":
			openModal("securityPanel")
			runSecurityReport()
		case "draw":
			openModal("dm")
			initDrawingCanvas()
		case "customize":
			setHidden("cp", false)
		case "launcher":
			openCommandPalette()
		}
	})
	on("nexusDevInspectSelector", "click", func(e js.Value) {
		sel := strings.TrimSpace(val("nexusDevSelector"))
		if sel == "" {
			return
		}
		els := qsa(sel)
		fmtSetText("nexusDevInspectorStatus", fmt.Sprintf("%d個の要素が一致しました。", els.Length()))
		out := ""
		for i := 0; i < els.Length() && i < 30; i++ {
			x := els.Index(i)
			r := x.Call("getBoundingClientRect")
			out += fmt.Sprintf("%d: <%s> id=%s class=%s hidden=%v size=%.0fx%.0f\n", i, x.Get("tagName").String(), x.Get("id").String(), x.Get("className").String(), x.Get("hidden").Bool(), r.Get("width").Float(), r.Get("height").Float())
		}
		fmtSetText("nexusDevInspectorOutput", out)
	})
	on("nexusDevApplyPrefs", "click", func(e js.Value) {
		if !devAdmin {
			return
		}
		prefs := map[string]any{"fast": byID("nexusDevFastMode").Get("checked").Bool(), "reduced": byID("nexusDevReducedMotion").Get("checked").Bool(), "outline": byID("nexusDevDebugOutline").Get("checked").Bool(), "font": parseNum(val("nexusDevFontScale"), 1), "accent": val("nexusDevAccent")}
		storageSet("nexusDevPrefs", prefs)
		applyDevPrefs()
	})
	on("nexusDevResetPrefs", "click", func(e js.Value) {
		if !devAdmin {
			return
		}
		storageRemove("nexusDevPrefs")
		setBodyClass("nexus-fast-mode", false)
		setBodyClass("nexus-debug-outline", false)
		fmtSetText("nexusDevModeStatus", "開発者表示設定を初期化しました。")
	})
	on("nexusDevFontScale", "input", func(e js.Value) {
		fmtSetText("nexusDevFontScaleOut", fmt.Sprintf("%.0f%%", parseNum(val("nexusDevFontScale"), 1)*100))
	})
	on("nexusDevApplyNetwork", "click", func(e js.Value) {
		if !devAdmin {
			return
		}
		cfg.AutoNetwork = byID("nexusDevAutoNetwork").Get("checked").Bool()
		storageSet("cfg", cfg)
		syncPrivacyStatus()
	})
	on("nexusDevApplyModes", "click", func(e js.Value) {
		if !devAdmin {
			return
		}
		screenProtected = byID("nexusDevScreenProtect").Get("checked").Bool()
		privacyAnonymous = byID("nexusDevAnonCommunication").Get("checked").Bool()
		storageSet("nexusScreenProtectMode", screenProtected)
		storageSet("nexusCommunicationAnonMode", privacyAnonymous)
		syncPrivacyButtons()
	})
	on("nexusDevOpenSecurity", "click", func(e js.Value) { openModal("securityPanel"); runSecurityReport() })
	on("nexusSourceLoadCurrent", "click", func(e js.Value) {
		setVal("nexusSourceEditorText", "<!doctype html>\\n"+doc.Get("documentElement").Get("outerHTML").String())
		sourceEditorLoaded = true
		fmtSetText("nexusSourceEditorStatus", "現在のHTMLスナップショットを読み込みました。Go/WASMロジックは別ファイルです。")
	})
	on("nexusSourceOpenFile", "click", func(e js.Value) { click("nexusSourceFile") })
	on("nexusSourceFile", "change", func(e js.Value) {
		files := byID("nexusSourceFile").Get("files")
		if files.Length() == 0 {
			return
		}
		if files.Index(0).Get("size").Int() > 5*1024*1024 {
			fmtSetText("nexusSourceEditorStatus", "HTMLファイルは5MiB以下にしてください。")
			return
		}
		r := win.Get("FileReader").New()
		cb := js.FuncOf(func(this js.Value, args []js.Value) any {
			setVal("nexusSourceEditorText", r.Get("result").String())
			sourceEditorLoaded = true
			fmtSetText("nexusSourceEditorStatus", "ファイルを読み込みました。編集内容は実行されません。")
			return nil
		})
		keep(cb)
		r.Set("onload", cb)
		r.Call("readAsText", files.Index(0))
	})
	on("nexusSourceCheck", "click", func(e js.Value) {
		s := val("nexusSourceEditorText")
		issues := []string{}
		if !strings.Contains(strings.ToLower(s), "<!doctype html") {
			issues = append(issues, "DOCTYPEがありません")
		}
		if strings.Count(strings.ToLower(s), "<script") != strings.Count(strings.ToLower(s), "</script>") {
			issues = append(issues, "scriptタグの対応数が一致しません")
		}
		if !strings.Contains(strings.ToLower(s), "<html") {
			issues = append(issues, "htmlタグがありません")
		}
		if len(issues) == 0 {
			fmtSetText("nexusSourceEditorStatus", "基本検査OK（HTML構造の簡易検査のみ。XSS/CSP全体は保証しません）。")
		} else {
			fmtSetText("nexusSourceEditorStatus", "注意："+strings.Join(issues, " / "))
		}
	})
	on("nexusSourceSave", "click", func(e js.Value) {
		if !sourceEditorLoaded {
			fmtSetText("nexusSourceEditorStatus", "先にHTMLを読み込んでください。")
			return
		}
		download("NEXUS_source_snapshot.html", val("nexusSourceEditorText"), "text/html;charset=utf-8")
	})
	on("nexusSourceClear", "click", func(e js.Value) {
		if confirm("エディター内容を消去しますか？") {
			setVal("nexusSourceEditorText", "")
			sourceEditorLoaded = false
		}
	})
	on("urlCheckerCopyHost", "click", func(e js.Value) {
		if urlCheckedHost != "" {
			copyText(urlCheckedHost, "urlCheckerSummary")
		}
	})
	if prefs, ok := storageGet("nexusDevPrefs"); ok {
		_ = prefs
		applyDevPrefs()
	}
}
func refreshDevStorage() {
	if !devAdmin {
		return
	}
	ls := win.Get("localStorage")
	items := []struct {
		k string
		n int
	}{}
	for i := 0; i < ls.Get("length").Int(); i++ {
		k := ls.Call("key", i).String()
		v := ls.Call("getItem", k).String()
		items = append(items, struct {
			k string
			n int
		}{k, len(v)})
	}
	sort.Slice(items, func(i, j int) bool { return items[i].k < items[j].k })
	h := ""
	for _, it := range items {
		h += fmt.Sprintf(`<option value="%s">%s (%d bytes)</option>`, escape(it.k), escape(it.k), it.n)
	}
	setHTML("nexusDevStorageSelect", h)
	fmtSetText("nexusDevStorageStatus", fmt.Sprintf("%dキーを一覧表示しました。値は選択して明示的に表示するまで読み出しません。", len(items)))
}
func runDevChecks() {
	lines := []string{"NEXUS Go/WASM 開発者診断", "日時：" + time.Now().Format(time.RFC3339), fmt.Sprintf("アプリ機能：WASM / DOM要素：%d / localStorageキー：%d", qsa("*").Length(), win.Get("localStorage").Get("length").Int()), fmt.Sprintf("画面サイズ：%dx%d", win.Get("innerWidth").Int(), win.Get("innerHeight").Int()), "任意コード実行：無効", "外部ネットワーク：天気APIの手動／許可設定に応じて実行", "注意：端末全体やOSの診断ではありません。"}
	fmtSetText("nexusDevOutput", strings.Join(lines, "\n"))
}
func runDevCommand() {
	if !devAdmin {
		fmtSetText("nexusDevConsoleStatus", "管理者権限を有効にしてください。")
		return
	}
	cmd := strings.Fields(strings.ToLower(strings.TrimSpace(val("nexusDevCommand"))))
	if len(cmd) == 0 {
		return
	}
	out := ""
	switch cmd[0] {
	case "help":
		out = "help / status / keys / fast on|off / privacy on|off / network on|off"
	case "status":
		out = fmt.Sprintf("Go/WASM active; %d localStorage keys", win.Get("localStorage").Get("length").Int())
	case "keys":
		ls := win.Get("localStorage")
		for i := 0; i < ls.Get("length").Int(); i++ {
			out += ls.Call("key", i).String() + "\n"
		}
	case "fast":
		if len(cmd) == 2 {
			devFastMode = cmd[1] == "on"
			setBodyClass("nexus-fast-mode", devFastMode)
			out = fmt.Sprintf("fast mode %v", devFastMode)
		} else {
			out = "usage: fast on|off"
		}
	case "privacy":
		if len(cmd) == 2 {
			privacyAnonymous = cmd[1] == "on"
			storageSet("nexusCommunicationAnonMode", privacyAnonymous)
			syncPrivacyButtons()
			out = "privacy mode updated"
		} else {
			out = "usage: privacy on|off"
		}
	case "network":
		if len(cmd) == 2 {
			cfg.AutoNetwork = cmd[1] == "on"
			storageSet("cfg", cfg)
			syncPrivacyStatus()
			out = "network preference updated"
		} else {
			out = "usage: network on|off"
		}
	default:
		out = "unknown command. Type help."
	}
	fmtSetText("nexusDevConsoleOutput", out)
	fmtSetText("nexusDevConsoleStatus", "許可リスト内コマンドを処理しました。")
}
func applyDevPrefs() {
	var p struct {
		Fast    bool    `json:"fast"`
		Reduced bool    `json:"reduced"`
		Outline bool    `json:"outline"`
		Font    float64 `json:"font"`
		Accent  string  `json:"accent"`
	}
	if !loadJSON("nexusDevPrefs", &p) {
		return
	}
	devFastMode = p.Fast
	setBodyClass("nexus-fast-mode", p.Fast)
	setBodyClass("nexus-debug-outline", p.Outline)
	if p.Reduced {
		doc.Get("documentElement").Get("style").Call("setProperty", "--nx-reduced-motion", "1")
	}
	if p.Font > 0 {
		doc.Get("documentElement").Get("style").Call("setProperty", "font-size", fmt.Sprintf("%grem", p.Font))
	}
	if strings.HasPrefix(p.Accent, "#") && len(p.Accent) == 7 {
		doc.Get("documentElement").Get("style").Call("setProperty", "--a", p.Accent)
	}
}

// Basic mini-game shell; game state and drawing are driven from Go.
func openGame(route string) {
	if strings.Contains(route, "drive") {
		gameMode = "drive"
	} else if strings.Contains(route, "snake") {
		gameMode = "snake"
	} else {
		gameMode = "target"
	}
	openModal("gm")
	gameScore = 0
	gameX = 160
	gameY = 240
	drawGame()
	if gameControlsBound {
		return
	}
	gameControlsBound = true
	onDoc("keydown", func(e js.Value) {
		if isHidden("gm") {
			return
		}
		switch strings.ToLower(e.Get("key").String()) {
		case "arrowleft", "a":
			gameX -= 15
		case "arrowright", "d":
			gameX += 15
		case "arrowup", "w":
			gameY -= 15
		case "arrowdown", "s":
			gameY += 15
		case "enter":
			gameScore = 0
		}
		drawGame()
	})
	on("gm", "click", func(e js.Value) {
		t := e.Get("target")
		if b := t.Call("closest", "[data-g]"); !b.IsNull() {
			gameMode = []string{"drive", "snake", "target"}[mustInt(b.Get("dataset").Get("g").String(), 2)]
			gameScore = 0
			drawGame()
		}
		if b := t.Call("closest", "[data-d]"); !b.IsNull() {
			gameX += float64(mustInt(b.Get("dataset").Get("d").String(), 0)) * 15
			gameScore++
			drawGame()
		}
	})
}
func mustInt(s string, d int) int {
	v, e := strconv.Atoi(s)
	if e != nil {
		return d
	}
	return v
}
func drawGame() {
	c := byID("gc")
	if c.IsNull() {
		return
	}
	ctx := c.Call("getContext", "2d")
	ctx.Set("fillStyle", "#060b1b")
	ctx.Call("fillRect", 0, 0, 320, 480)
	ctx.Set("fillStyle", "#8beaff")
	ctx.Set("font", "16px sans-serif")
	ctx.Call("fillText", "NEXUS · "+gameMode+" · SCORE "+fmt.Sprint(gameScore), 12, 24)
	ctx.Set("fillStyle", "#ffca5c")
	ctx.Call("beginPath")
	ctx.Call("arc", math.Max(12, math.Min(308, gameX)), math.Max(42, math.Min(468, gameY)), 12, 0, math.Pi*2)
	ctx.Call("fill")
	ctx.Set("fillStyle", "#eaf6ff")
	ctx.Call("fillText", "矢印キー／A・D・W・S または画面ボタンで移動", 12, 460)
}

// CodeBridge deliberately labels heuristic conversions as drafts, never as compiler-grade output.
func initCodeBridge() {
	for _, pair := range [][2]string{{"cbTabConvert", "cbPanelConvert"}, {"cbTabWorkspace", "cbPanelWorkspace"}, {"cbTabAssistant", "cbPanelAssistant"}} {
		id, panel := pair[0], pair[1]
		on(id, "click", func(e js.Value) {
			for _, x := range []string{"cbPanelConvert", "cbPanelWorkspace", "cbPanelAssistant"} {
				setHidden(x, x != panel)
			}
			for _, x := range []string{"cbTabConvert", "cbTabWorkspace", "cbTabAssistant"} {
				setAttr(x, "aria-selected", fmt.Sprint(x == id))
			}
		})
	}
	on("cbSample", "click", func(e js.Value) {
		lang := val("cbSource")
		samples := map[string]string{"python": "def add(a, b):\n    return a + b\n\nprint(add(2, 3))", "javascript": "function add(a, b) {\n  return a + b;\n}\nconsole.log(add(2, 3));", "go": "package main\nimport \"fmt\"\nfunc add(a, b int) int { return a + b }\nfunc main() { fmt.Println(add(2, 3)) }", "rust": "fn add(a: i32, b: i32) -> i32 { a + b }\nfn main() { println!(\"{}\", add(2, 3)); }"}
		setVal("cbCodeIn", samples[lang])
		if samples[lang] == "" {
			fmtSetText("cbStatus", "この言語の例は未定義です。コードを入力してください。")
		} else {
			fmtSetText("cbStatus", "サンプルを入力しました。")
		}
	})
	on("cbConvert", "click", func(e js.Value) {
		src, dst := val("cbSource"), val("cbTarget")
		code := val("cbCodeIn")
		if strings.TrimSpace(code) == "" {
			fmtSetText("cbStatus", "変換元コードを入力してください。")
			return
		}
		out, ok := heuristicConvert(src, dst, code)
		setVal("cbCodeOut", out)
		if ok {
			fmtSetText("cbStatus", "ルールベースの変換案を作成しました。複雑な構文・型・ライブラリは必ず手動確認してください。")
		} else {
			fmtSetText("cbStatus", "この言語ペアの自動変換器はありません。依頼文を生成し、AI等で手動レビューしてください。")
		}
	})
	on("cbSwap", "click", func(e js.Value) {
		a, b := val("cbSource"), val("cbTarget")
		setVal("cbSource", b)
		setVal("cbTarget", a)
		setVal("cbCodeIn", val("cbCodeOut"))
		setVal("cbCodeOut", "")
	})
	on("cbClear", "click", func(e js.Value) { setVal("cbCodeIn", ""); setVal("cbCodeOut", ""); fmtSetText("cbStatus", "") })
	on("cbCopy", "click", func(e js.Value) { copyText(val("cbCodeOut"), "cbStatus") })
	on("cbDownload", "click", func(e js.Value) { download("converted_code.txt", val("cbCodeOut"), "text/plain;charset=utf-8") })
	on("cbMakeAiPrompt", "click", func(e js.Value) {
		p := fmt.Sprintf("次の%sコードを%sへ変換してください。意味・動作・入出力を変えず、未対応箇所と仮定を明記してください。実行可能な完全なコード、テスト、制約も提示してください。\n\n```%s\n%s\n```", val("cbSource"), val("cbTarget"), val("cbSource"), val("cbCodeIn"))
		setVal("cbAiPrompt", p)
		fmtSetText("cbStatus", "AIへ手動で渡す依頼文を作成しました。自動送信はしません。")
	})
	on("cbCopyAiPrompt", "click", func(e js.Value) { copyText(val("cbAiPrompt"), "cbStatus") })
	on("cbDownloadAiPrompt", "click", func(e js.Value) { download("CodeBridge_prompt.txt", val("cbAiPrompt"), "text/plain;charset=utf-8") })
	on("cbWorkStarter", "click", func(e js.Value) {
		lang := val("cbWorkLang")
		sample := map[string]string{"go": "package main\n\nimport \"fmt\"\n\nfunc main() {\n    fmt.Println(\"Hello, world!\")\n}\n", "python": "def main():\n    print(\"Hello, world!\")\n\nif __name__ == \"__main__\":\n    main()\n", "javascript": "function main() {\n  console.log(\"Hello, world!\");\n}\nmain();\n", "rust": "fn main() {\n    println!(\"Hello, world!\");\n}\n"}
		setVal("cbWorkCode", sample[lang])
		fmtSetText("cbWorkStatus", "スターターを生成しました。")
	})
	for _, id := range []string{"cbWorkPromptGenerate", "cbWorkPromptFix", "cbWorkPromptExplain"} {
		kind := id
		on(id, "click", func(e js.Value) {
			mode := map[string]string{"cbWorkPromptGenerate": "新規生成", "cbWorkPromptFix": "修正", "cbWorkPromptExplain": "解説"}[kind]
			p := fmt.Sprintf("以下の%sコードについて%sしてください。対象言語：%s\n要望：%s\n方針：%s\n\nコード：\n```\n%s\n```\n\n完成済みと誤称せず、前提・未実装・テストを明記してください。", val("cbWorkLang"), mode, val("cbWorkLang"), val("cbWorkRequest"), val("cbWorkFixStyle"), val("cbWorkCode"))
			setVal("cbWorkPrompt", p)
			fmtSetText("cbWorkStatus", "依頼文を作成しました。外部AIへの送信は行いません。")
		})
	}
	on("cbWorkLoadConvert", "click", func(e js.Value) {
		setVal("cbWorkCode", val("cbCodeIn"))
		fmtSetText("cbWorkStatus", "変換元コードを読み込みました。")
	})
	on("cbWorkCopy", "click", func(e js.Value) { copyText(val("cbWorkCode"), "cbWorkStatus") })
	on("cbWorkSave", "click", func(e js.Value) {
		name := strings.TrimSpace(val("cbWorkName"))
		if name == "" {
			name = "main"
		}
		download(name+".txt", val("cbWorkCode"), "text/plain;charset=utf-8")
	})
	on("cbWorkClear", "click", func(e js.Value) { setVal("cbWorkCode", "") })
	on("cbWorkApplyAi", "click", func(e js.Value) { setVal("cbWorkCode", val("cbAiResult")) })
	on("cbWorkUseAsPrompt", "click", func(e js.Value) { setVal("cbWorkRequest", val("cbAiResult")) })
	on("cbWorkCopyPrompt", "click", func(e js.Value) { copyText(val("cbWorkPrompt"), "cbWorkStatus") })
	on("cbWorkSavePrompt", "click", func(e js.Value) { download("CodeBridge_request.txt", val("cbWorkPrompt"), "text/plain;charset=utf-8") })
	on("cbWorkOpenAi", "click", func(e js.Value) { copyText(val("cbWorkPrompt"), "cbWorkStatus"); openURL("https://chatgpt.com/") })
}
func heuristicConvert(src, dst, code string) (string, bool) {
	if src == dst {
		return code, true
	}
	if dst == "go" && src == "python" {
		r := strings.NewReplacer("def ", "func ", "True", "true", "False", "false", "None", "nil", "print(", "fmt.Println(")
		out := r.Replace(code)
		out = "// 変換案: import fmt と型・インデント・戻り値は要確認\npackage main\n\nimport \"fmt\"\n\n" + out
		return out, true
	}
	if dst == "javascript" && src == "python" {
		out := strings.ReplaceAll(code, "def ", "function ")
		out = strings.ReplaceAll(out, "print(", "console.log(")
		out = strings.ReplaceAll(out, ":", " {")
		out = strings.ReplaceAll(out, "True", "true")
		out = strings.ReplaceAll(out, "False", "false")
		return "// 変換案：ブロック終端・型・内包表記などは要確認\n" + out, true
	}
	if dst == "python" && src == "javascript" {
		out := strings.ReplaceAll(code, "console.log(", "print(")
		out = strings.ReplaceAll(out, "function ", "def ")
		out = strings.ReplaceAll(out, "const ", "")
		out = strings.ReplaceAll(out, "let ", "")
		out = strings.ReplaceAll(out, "var ", "")
		return "# 変換案：波括弧・セミコロン・関数引数/戻り値型は要確認\n" + out, true
	}
	return "// この言語ペアの変換器は未実装です。元コードを保持しました。\n" + code, false
}
