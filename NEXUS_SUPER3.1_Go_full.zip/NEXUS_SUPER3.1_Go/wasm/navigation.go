//go:build js && wasm

package main

import (
	"fmt"
	"net/url"
	"strings"
	"syscall/js"
)

type searchProvider struct {
	Name   string
	Prefix string
}

var searchProviders = []searchProvider{
	{"Google", "https://www.google.com/search?q="}, {"Yahoo", "https://search.yahoo.co.jp/search?p="}, {"DuckDuckGo", "https://duckduckgo.com/?q="}, {"Bing", "https://www.bing.com/search?q="}, {"Brave", "https://search.brave.com/search?q="}, {"Ecosia", "https://www.ecosia.org/search?q="}, {"Startpage", "https://www.startpage.com/do/search?q="},
}

func initSettings() {
	applySettings()
	for id, key := range map[string]string{"ch": "h", "cb": "bl", "cz": "sz", "cc": "ct", "cl": "br"} {
		_ = key
		el := byID(id)
		if el.IsNull() || el.IsUndefined() {
			continue
		}
		switch id {
		case "ch":
			el.Set("value", cfg.Hue)
		case "cb":
			el.Set("value", cfg.Blur)
		case "cz":
			el.Set("value", cfg.Size)
		case "cc":
			el.Set("value", cfg.Contrast)
		case "cl":
			el.Set("value", cfg.Brightness)
		}
	}
	for _, id := range []string{"ch", "cb", "cz", "cc", "cl"} {
		on(id, "input", func(e js.Value) {
			switch id {
			case "ch":
				cfg.Hue = parseNum(val(id), 190)
			case "cb":
				cfg.Blur = parseNum(val(id), 12)
			case "cz":
				cfg.Size = parseNum(val(id), 84)
			case "cc":
				cfg.Contrast = parseNum(val(id), 1.25)
			case "cl":
				cfg.Brightness = parseNum(val(id), 1)
			}
			storageSet("cfg", cfg)
			applySettings()
		})
	}
	if e := byID("wallpaperPreset"); !e.IsNull() {
		e.Set("value", cfg.Wallpaper)
	}
	on("wallpaperPreset", "change", func(e js.Value) {
		cfg.Wallpaper = val("wallpaperPreset")
		if cfg.Wallpaper != "custom" {
			cfg.Background = ""
		}
		storageSet("cfg", cfg)
		applySettings()
	})
	on("cf", "change", func(e js.Value) {
		files := byID("cf").Get("files")
		if files.Length() == 0 {
			return
		}
		file := files.Index(0)
		if file.Get("size").Int() > 5*1024*1024 {
			alert("背景画像は5MB以下にしてください。")
			return
		}
		reader := win.Get("FileReader").New()
		cb := js.FuncOf(func(this js.Value, args []js.Value) any {
			cfg.Background = reader.Get("result").String()
			cfg.Wallpaper = "custom"
			storageSet("cfg", cfg)
			applySettings()
			return nil
		})
		keep(cb)
		reader.Set("onload", cb)
		reader.Call("readAsDataURL", file)
	})
	on("cr", "click", func(e js.Value) { cfg.Background = ""; cfg.Wallpaper = "cpc"; storageSet("cfg", cfg); applySettings() })
	on("layoutMode", "change", func(e js.Value) { cfg.Layout = val("layoutMode"); storageSet("cfg", cfg); applySettings() })
	checks := qsa("[data-k]")
	for i := 0; i < checks.Length(); i++ {
		el := checks.Index(i)
		idx := el.Get("dataset").Get("k").String()
		n, _ := strconvAtoi(idx)
		if n >= 0 && n < len(cfg.Visible) {
			el.Set("checked", cfg.Visible[n] != 0)
			id := n
			cb := js.FuncOf(func(this js.Value, args []js.Value) any {
				if len(args) > 0 {
					cfg.Visible[id] = 0
					if args[0].Get("target").Get("checked").Bool() {
						cfg.Visible[id] = 1
					}
					storageSet("cfg", cfg)
					applySettings()
				}
				return nil
			})
			keep(cb)
			el.Call("addEventListener", "change", cb)
		}
	}
	on("privacyAutoNetwork", "change", func(e js.Value) {
		cfg.AutoNetwork = byID("privacyAutoNetwork").Get("checked").Bool()
		storageSet("cfg", cfg)
		syncPrivacyStatus()
		if cfg.AutoNetwork {
			loadWeather(false)
		}
	})
	on("privacyBlur", "change", func(e js.Value) {
		cfg.BlurPrivacy = byID("privacyBlur").Get("checked").Bool()
		storageSet("cfg", cfg)
		syncPrivacyStatus()
		syncPrivacyScrim()
	})
	byID("privacyAutoNetwork").Set("checked", cfg.AutoNetwork)
	byID("privacyBlur").Set("checked", cfg.BlurPrivacy)
	syncPrivacyStatus()
	on("privacyClearData", "click", func(e js.Value) {
		if !confirm("NEXUSの設定・メモ・Todo・予定・ブックマーク・お絵かきなど、アプリが使うローカル保存データを消去します。元に戻せません。先にバックアップしましたか？") {
			return
		}
		keys := []string{"cfg", "apps", "bm", "memos", "memo", "ev", "nexusDailyTodos", "draw", "drawBg", "trPair", "nexusBulletinRecordsV1", "nexusDevPrefs", "nexusScreenProtectMode", "nexusCommunicationAnonMode"}
		for _, k := range keys {
			storageRemove(k)
		}
		fmtSetText("privacyClearStatus", "保存データを消去しました。初期状態へ戻すため再読み込みします。")
		win.Call("setTimeout", js.FuncOf(func(this js.Value, args []js.Value) any { win.Get("location").Call("reload"); return nil }), 700)
	})
	initPrivacyModes()
}
func parseNum(s string, def float64) float64 {
	var f float64
	if _, e := fmt.Sscan(s, &f); e != nil {
		return def
	}
	return f
}
func strconvAtoi(s string) (int, error) { var n int; _, e := fmt.Sscan(s, &n); return n, e }
func applySettings() {
	root := doc.Get("documentElement")
	root.Get("dataset").Set("theme", cfg.Theme)
	root.Get("dataset").Set("layoutMode", cfg.Layout)
	style := root.Get("style")
	style.Call("setProperty", "--h", fmt.Sprint(cfg.Hue))
	style.Call("setProperty", "--bl", fmt.Sprintf("%gpx", cfg.Blur))
	style.Call("setProperty", "--sz", fmt.Sprintf("%gpx", cfg.Size))
	bg := byID("bg")
	if !bg.IsNull() {
		switch cfg.Wallpaper {
		case "calm":
			bg.Get("style").Set("background", "linear-gradient(135deg,#111b2a 0%,#182538 50%,#101a29 100%)")
		case "space":
			bg.Get("style").Set("background", "radial-gradient(ellipse at 18% 22%,rgba(118,38,255,.48),transparent 38%),radial-gradient(ellipse at 78% 25%,rgba(0,190,255,.42),transparent 42%),radial-gradient(ellipse at 55% 82%,rgba(0,255,211,.20),transparent 44%),#02030a")
		case "deep":
			bg.Get("style").Set("background", "radial-gradient(ellipse at 18% 20%,rgba(0,95,255,.38),transparent 42%),radial-gradient(ellipse at 85% 35%,rgba(70,45,200,.32),transparent 44%),#010612")
		case "grid":
			bg.Get("style").Set("background", "linear-gradient(rgba(1,5,18,.38),rgba(1,5,18,.5)),linear-gradient(90deg,rgba(0,217,255,.2) 1px,transparent 1px),linear-gradient(rgba(0,217,255,.2) 1px,transparent 1px),#02030a")
		case "custom":
			if cfg.Background != "" {
				bg.Get("style").Set("background", fmt.Sprintf("linear-gradient(rgba(1,5,18,.25),rgba(1,5,18,.38)),url('%s') center/cover no-repeat fixed", cfg.Background))
			}
		default:
			bg.Get("style").Set("background", "")
		}
		bg.Get("style").Set("filter", fmt.Sprintf("contrast(%g) brightness(%g) saturate(1.2)", cfg.Contrast, cfg.Brightness))
	}
	if e := byID("wallpaperPreset"); !e.IsNull() {
		e.Set("value", cfg.Wallpaper)
	}
	if e := byID("layoutMode"); !e.IsNull() {
		e.Set("value", cfg.Layout)
	}
	wp := map[string]string{"calm": "落ち着いた背景（既定）", "cpc": "CPC部（内蔵背景画像）", "space": "宇宙空間", "deep": "深宇宙ブルー", "grid": "ネオン・グリッド", "custom": "自分の画像"}
	fmtSetText("wallpaperStatus", "現在の背景："+wp[cfg.Wallpaper]+"。設定はこのブラウザのローカル保存領域に保存されます。")
	all := qsa("[data-w]")
	for i := 0; i < all.Length(); i++ {
		el := all.Index(i)
		idx, _ := strconvAtoi(el.Get("dataset").Get("w").String())
		if idx >= 0 && idx < len(cfg.Visible) {
			el.Set("hidden", cfg.Visible[idx] == 0)
		}
	}
}
func syncPrivacyStatus() {
	fmtSetText("privacyStatus", map[bool]string{true: "自動取得を許可中：天気情報は起動時／定期更新時に外部サービスへ接続します。", false: "プライバシー保護中：自動外部通信は停止中です。手動の「更新」操作でのみ取得します。"}[cfg.AutoNetwork])
}
func syncPrivacyScrim() {
	setHidden("privacyScrim", !(cfg.BlurPrivacy && (!doc.Call("hasFocus").Bool() || doc.Get("hidden").Bool())))
}
func initPrivacyModes() {
	setAttr("nexusScreenProtectBtn", "aria-pressed", fmt.Sprint(screenProtected))
	setAttr("nexusAnonModeBtn", "aria-pressed", fmt.Sprint(privacyAnonymous))
	syncPrivacyButtons()
	on("nexusScreenProtectBtn", "click", func(e js.Value) {
		screenProtected = !screenProtected
		storageSet("nexusScreenProtectMode", screenProtected)
		syncPrivacyButtons()
		if screenProtected {
			showScreenOverlay()
		}
	})
	on("nexusScreenProtectToggle", "change", func(e js.Value) {
		screenProtected = byID("nexusScreenProtectToggle").Get("checked").Bool()
		storageSet("nexusScreenProtectMode", screenProtected)
		syncPrivacyButtons()
		if screenProtected {
			showScreenOverlay()
		}
	})
	on("nexusAnonModeBtn", "click", func(e js.Value) {
		if !privacyAnonymous && !confirm("通信匿名モードを有効にすると、NEXUSからの外部通信と外部サイト起動をブロックします。IPアドレス自体を隠すVPN機能ではありません。続けますか？") {
			return
		}
		privacyAnonymous = !privacyAnonymous
		storageSet("nexusCommunicationAnonMode", privacyAnonymous)
		syncPrivacyButtons()
	})
	on("nexusAnonModeToggle", "change", func(e js.Value) {
		want := byID("nexusAnonModeToggle").Get("checked").Bool()
		if want && !privacyAnonymous && !confirm("外部通信・外部サイト起動をブロックします。IPアドレス自体は隠れません。続けますか？") {
			byID("nexusAnonModeToggle").Set("checked", false)
			return
		}
		privacyAnonymous = want
		storageSet("nexusCommunicationAnonMode", privacyAnonymous)
		syncPrivacyButtons()
	})
	on("nexusScreenProtectResume", "click", func(e js.Value) { setHidden("nexusScreenProtectOverlay", true) })
	onDoc("keydown", func(e js.Value) {
		key := e.Get("key").String()
		ctrl := e.Get("ctrlKey").Bool()
		shift := e.Get("shiftKey").Bool()
		if ctrl && shift && strings.ToLower(key) == "l" {
			prevent(e)
			if isHidden("nexusScreenProtectOverlay") {
				showScreenOverlay()
			} else {
				setHidden("nexusScreenProtectOverlay", true)
			}
		}
		if key == "Escape" {
			setHidden("nexusScreenProtectOverlay", true)
		}
	})
	onWindow("blur", func(e js.Value) {
		if screenProtected {
			showScreenOverlay()
		}
		syncPrivacyScrim()
	})
	onDoc("visibilitychange", func(e js.Value) {
		if screenProtected && doc.Get("hidden").Bool() {
			showScreenOverlay()
		}
		syncPrivacyScrim()
	})
	onWindow("focus", func(e js.Value) { syncPrivacyScrim() })
}
func showScreenOverlay() {
	setHidden("nexusScreenProtectOverlay", false)
	focus("nexusScreenProtectResume")
}
func syncPrivacyButtons() {
	setAttr("nexusScreenProtectBtn", "aria-pressed", fmt.Sprint(screenProtected))
	setAttr("nexusAnonModeBtn", "aria-pressed", fmt.Sprint(privacyAnonymous))
	fmtSetText("nexusScreenProtectBtn", map[bool]string{true: "🔒 画面保護 ON", false: "🔒 画面保護 OFF"}[screenProtected])
	fmtSetText("nexusAnonModeBtn", map[bool]string{true: "🕵️ 通信匿名 ON", false: "🕵️ 通信匿名 OFF"}[privacyAnonymous])
	byID("nexusScreenProtectToggle").Set("checked", screenProtected)
	byID("nexusAnonModeToggle").Set("checked", privacyAnonymous)
	fmtSetText("nexusScreenProtectStatus", map[bool]string{true: "画面保護が有効です。Ctrl+Shift+Lで解除できます。", false: "画面保護は無効です。"}[screenProtected])
	fmtSetText("nexusAnonModeStatus", map[bool]string{true: "NEXUSからの外部通信と外部サイト起動をブロック中です。VPNではありません。", false: "外部通信ブロックは無効です。"}[privacyAnonymous])
	fmtSetText("nexusSideScreenState", map[bool]string{true: "ON", false: "OFF"}[screenProtected])
	fmtSetText("nexusSideAnonState", map[bool]string{true: "ON", false: "OFF"}[privacyAnonymous])
}

func initSearchAndApps() {
	renderSearchProviders()
	updateBookmarks()
	updateApps()
	on("en", "click", func(e js.Value) {
		target := e.Get("target")
		if target.IsNull() {
			return
		}
		idx := target.Get("dataset").Get("i")
		if idx.IsUndefined() {
			return
		}
		n, _ := strconvAtoi(idx.String())
		if n >= 0 && n < len(searchProviders) {
			cfg.SearchEngine = n
			storageSet("cfg", cfg)
			renderSearchProviders()
			focus("q")
		}
	})
	on("sf", "submit", func(e js.Value) {
		prevent(e)
		q := strings.TrimSpace(val("q"))
		if q == "" {
			return
		}
		if strings.HasPrefix(q, "https://") || strings.HasPrefix(q, "http://") || looksLikeDomain(q) {
			openURL(q)
			return
		}
		engine := cfg.SearchEngine
		if engine < 0 || engine >= len(searchProviders) {
			engine = 0
		}
		openURL(searchProviders[engine].Prefix + url.QueryEscape(q))
	})
	on("af", "submit", func(e js.Value) {
		prevent(e)
		name := strings.TrimSpace(val("an"))
		u := safeURL(val("au"))
		if name == "" || u == "" || strings.HasPrefix(u, "#") {
			alert("名前と有効な http/https URL を入力してください。")
			return
		}
		if len(bookmarks) >= 80 {
			alert("ブックマークは最大80件です。")
			return
		}
		bookmarks = append(bookmarks, AppLink{name, u})
		storageSet("bm", bookmarks)
		updateBookmarks()
		setVal("an", "")
		setVal("au", "")
	})
	on("eb", "click", func(e js.Value) {
		editing = toggleClassBody("ed")
		setHidden("af", !editing)
		setHidden("aaf", !editing || groups[activeGroup].Name == "ミニゲーム")
		fmtSetText("eb", map[bool]string{true: "✓ 完了", false: "✎ 編集"}[editing])
	})
	on("lb", "click", func(e js.Value) {
		setHidden("lp", !isHidden("lp"))
		if !isHidden("lp") {
			focus("lq")
		}
	})
	on("lq", "input", func(e js.Value) { updateApps() })
	on("tb", "click", func(e js.Value) {
		d := e.Get("target").Get("dataset").Get("i")
		if d.IsUndefined() {
			return
		}
		n, _ := strconvAtoi(d.String())
		if n >= 0 && n < len(groups) {
			activeGroup = n
			updateApps()
		}
	})
	on("ap2", "click", func(e js.Value) { handleAppClick(e) })
	on("aaf", "submit", func(e js.Value) {
		prevent(e)
		if activeGroup < 0 || activeGroup >= len(groups) {
			return
		}
		if groups[activeGroup].Name == "ミニゲーム" {
			alert("ミニゲームには、このHTML内で遊べるゲームだけを表示します。")
			return
		}
		if len(groups[activeGroup].Items) >= 120 {
			alert("このカテゴリは最大120件です。")
			return
		}
		name := strings.TrimSpace(val("aan"))
		u := safeURL(val("aau"))
		if name == "" || u == "" || strings.HasPrefix(u, "#") {
			alert("名前と有効なURLを入力してください。")
			return
		}
		groups[activeGroup].Items = append(groups[activeGroup].Items, AppLink{name, u})
		saveGroups()
		updateApps()
		setVal("aan", "")
		setVal("aau", "")
	})
	on("bk", "click", func(e js.Value) { handleBookmarkClick(e) })
	// Close the app drawer when clicking outside it.
	onDoc("pointerdown", func(e js.Value) {
		target := e.Get("target")
		if target.IsNull() {
			return
		}
		if target.Call("closest", "#lp,#lb,#eb").IsNull() {
			setHidden("lp", true)
		}
	})
	// The built-in garbler has a local route rather than an external URL.
}
func toggleClassBody(name string) bool {
	body := doc.Get("body")
	return body.Get("classList").Call("toggle", name).Bool()
}
func looksLikeDomain(s string) bool {
	return strings.Contains(s, ".") && !strings.ContainsAny(s, " \t\n")
}
func renderSearchProviders() {
	h := ""
	for i, p := range searchProviders {
		cls := ""
		if i == cfg.SearchEngine {
			cls = "on"
		}
		h += fmt.Sprintf(`<button type="button" class="%s" data-i="%d">%s</button>`, cls, i, escape(p.Name))
	}
	setHTML("en", h)
}
func saveGroups() {
	arr := [][]AppLink{}
	for _, g := range groups {
		arr = append(arr, g.Items)
	}
	storageSet("apps", arr)
}
func iconFor(n string) string {
	m := map[string]string{"Gmail": "✉️", "ドキュメント": "📄", "スライド": "📊", "スプレッドシート": "📈", "ドライブ": "💾", "Word": "📘", "Excel": "📗", "PowerPoint": "📙", "Teams": "👥", "Outlook": "📧", "OneNote": "🗒️", "Copilot": "🤖", "Claude": "🧠", "ChatGPT": "💬", "YouTube": "▶️", "GitHub": "🐙", "Google": "G", "Gemini": "✨", "文字化けメーカー": "🧬", "ドライブ（内蔵）": "🚗", "スネーク（内蔵）": "🐍", "ターゲット（内蔵）": "🎯"}
	if v, ok := m[n]; ok {
		return v
	}
	r := []rune(n)
	if len(r) > 0 {
		return string(r[0])
	}
	return "🔗"
}
func tile(a AppLink, i int, editable bool) string {
	u := safeURL(a.URL)
	if u == "" {
		u = "#"
	}
	remove := ""
	move := ""
	if editable {
		remove = fmt.Sprintf(`<button type="button" class="x" data-i="%d" aria-label="削除">×</button>`, i)
		move = fmt.Sprintf(`<button type="button" class="mb l" data-m="%d" data-d="-1">◀</button><button type="button" class="mb r" data-m="%d" data-d="1">▶</button>`, i, i)
	}
	rank := ""
	if i < 9 {
		rank = fmt.Sprintf(`<em>%d</em>`, i+1)
	}
	return fmt.Sprintf(`<a class="t" href="%s" target="_blank" rel="noopener noreferrer" referrerpolicy="no-referrer"><i>%s</i><span>%s</span>%s%s%s</a>`, escape(u), escape(iconFor(a.Name)), escape(a.Name), rank, remove, move)
}
func updateBookmarks() {
	h := ""
	for i, a := range bookmarks {
		h += tile(a, i, editing)
	}
	setHTML("bk", h)
}
func updateApps() {
	tabs := ""
	for i, g := range groups {
		cls := ""
		if i == activeGroup {
			cls = "on"
		}
		tabs += fmt.Sprintf(`<button type="button" class="%s" data-i="%d">%s</button>`, cls, i, escape(g.Name))
	}
	setHTML("tb", tabs)
	if activeGroup < 0 || activeGroup >= len(groups) {
		activeGroup = 0
	}
	q := strings.ToLower(strings.TrimSpace(val("lq")))
	h := ""
	for i, a := range groups[activeGroup].Items {
		if q != "" && !strings.Contains(strings.ToLower(a.Name), q) && !strings.Contains(strings.ToLower(a.URL), q) {
			continue
		}
		h += tile(a, i, editing)
	}
	setHTML("ap2", h)
	setHidden("aaf", !editing || groups[activeGroup].Name == "ミニゲーム")
}
func handleBookmarkClick(e js.Value) {
	target := e.Get("target")
	if target.IsNull() {
		return
	}
	if target.Call("closest", ".x").IsNull() == false {
		prevent(e)
		btn := target.Call("closest", ".x")
		idx, _ := strconvAtoi(btn.Get("dataset").Get("i").String())
		if idx >= 0 && idx < len(bookmarks) {
			bookmarks = append(bookmarks[:idx], bookmarks[idx+1:]...)
			storageSet("bm", bookmarks)
			updateBookmarks()
		}
		return
	}
	if m := target.Call("closest", ".mb"); !m.IsNull() {
		prevent(e)
		idx, _ := strconvAtoi(m.Get("dataset").Get("m").String())
		d, _ := strconvAtoi(m.Get("dataset").Get("d").String())
		moveApp(&bookmarks, idx, d)
		storageSet("bm", bookmarks)
		updateBookmarks()
	}
}
func handleAppClick(e js.Value) {
	target := e.Get("target")
	if target.IsNull() {
		return
	}
	if !target.Call("closest", ".x").IsNull() {
		prevent(e)
		btn := target.Call("closest", ".x")
		idx, _ := strconvAtoi(btn.Get("dataset").Get("i").String())
		if idx >= 0 && idx < len(groups[activeGroup].Items) {
			groups[activeGroup].Items = append(groups[activeGroup].Items[:idx], groups[activeGroup].Items[idx+1:]...)
			saveGroups()
			updateApps()
		}
		return
	}
	if !target.Call("closest", ".mb").IsNull() {
		prevent(e)
		m := target.Call("closest", ".mb")
		idx, _ := strconvAtoi(m.Get("dataset").Get("m").String())
		d, _ := strconvAtoi(m.Get("dataset").Get("d").String())
		moveApp(&groups[activeGroup].Items, idx, d)
		saveGroups()
		updateApps()
		return
	}
	a := target.Call("closest", "a.t[href]")
	if !a.IsNull() {
		href := a.Call("getAttribute", "href").String()
		if strings.HasPrefix(href, "#nexus-garbler") {
			prevent(e)
			openGarbler()
		}
		if strings.HasPrefix(href, "#nexus-game-") {
			prevent(e)
			setHidden("lp", true)
			openGame(href)
		}
	}
}
func moveApp(arr *[]AppLink, idx, delta int) {
	a := *arr
	j := idx + delta
	if idx < 0 || idx >= len(a) || j < 0 || j >= len(a) {
		return
	}
	a[idx], a[j] = a[j], a[idx]
}

func initNavigation() {
	on("nexusSideToggle", "click", func(e js.Value) {
		if mobileLayout() {
			open := !hasClassBody("nexus-sidebar-open")
			setBodyClass("nexus-sidebar-open", open)
			setHidden("nexusSideScrim", !open)
			setAttr("nexusSideToggle", "aria-expanded", fmt.Sprint(open))
		} else {
			collapsed := !hasClassBody("nexus-sidebar-collapsed")
			setBodyClass("nexus-sidebar-collapsed", collapsed)
			setAttr("nexusSideToggle", "aria-expanded", fmt.Sprint(!collapsed))
		}
	})
	on("nexusSideCollapse", "click", func(e js.Value) {
		setBodyClass("nexus-sidebar-open", false)
		setBodyClass("nexus-sidebar-collapsed", true)
		setHidden("nexusSideScrim", true)
	})
	on("nexusSideScrim", "click", func(e js.Value) { setBodyClass("nexus-sidebar-open", false); setHidden("nexusSideScrim", true) })
	nav := qs("#nexusSideNav [data-nxnav]")
	if !nav.IsNull() {
		for _, id := range []string{"weatherCard", "memoCard", "todoCard", "trCard", "nexusSystemMonitor", "codeBridgeModal", "securityPanel", "backupTools", "privacyTools", "nexusSleepModal", "nexusDevModal", "nxDockAssistant", "newsPanel", "dm"} {
			_ = id
		}
	}
	// Event delegation allows the navigation items to stay declarative in HTML.
	onDoc("click", func(e js.Value) {
		t := e.Get("target")
		if t.IsNull() {
			return
		}
		b := t.Call("closest", "[data-nxnav]")
		if b.IsNull() {
			return
		}
		act := b.Get("dataset").Get("nxnav").String()
		switch act {
		case "home":
			win.Call("scrollTo", map[string]any{"top": 0, "behavior": "smooth"})
		case "assistant":
			click("nxAssistantTab")
		case "weather":
			scroll("weatherCard")
		case "rain24":
			setHidden("wx24Panel", false)
			scroll("wx24Panel")
		case "news":
			click("newsTab")
		case "memo":
			scroll("memoCard")
		case "board":
			click("nexusBoardBtn")
		case "todo":
			scroll("todoCard")
		case "calendar":
			scroll("sls")
		case "translate":
			scroll("trCard")
		case "timer":
			scroll("td")
		case "stopwatch":
			scroll("swdisplay")
		case "calculator":
			scroll("calc")
		case "bgm":
			scroll("bgmtrack")
		case "music":
			scroll("mpt")
		case "code":
			click("codeBridgeHeaderBtn")
		case "drawing":
			click("drb")
		case "security":
			click("securityBtn")
		case "privacy":
			scroll("privacyTools")
		case "backup":
			scroll("backupTools")
		case "screen":
			click("nexusScreenProtectBtn")
		case "anon":
			click("nexusAnonModeBtn")
		case "monitor":
			scroll("nexusSystemMonitor")
		case "customize":
			click("sb")
		case "sleep":
			click("nexusSleepBtn")
		case "developer":
			click("nexusDevBtn")
		case "search":
			scroll("sf")
			focus("q")
		}
		if mobileLayout() {
			setBodyClass("nexus-sidebar-open", false)
			setHidden("nexusSideScrim", true)
		}
	})
	on("sb", "click", func(e js.Value) { setHidden("cp", !isHidden("cp")) })
	on("thb", "click", func(e js.Value) {
		if cfg.Theme == "dark" {
			cfg.Theme = "light"
		} else {
			cfg.Theme = "dark"
		}
		storageSet("cfg", cfg)
		applySettings()
	})
	on("siteUpdateToggle", "click", func(e js.Value) { setHidden("siteUpdatePanel", !isHidden("siteUpdatePanel")) })
	on("siteUpdateClose", "click", func(e js.Value) { setHidden("siteUpdatePanel", true) })
	on("commandPaletteBtn", "click", func(e js.Value) { openCommandPalette() })
	on("nexusCommandClose", "click", func(e js.Value) { closeModal("nexusCommandModal") })
	on("nexusCommandInput", "input", func(e js.Value) { renderCommandPalette() })
	on("nexusCommandList", "click", func(e js.Value) {
		target := e.Get("target").Call("closest", "[data-command]")
		if target.IsNull() {
			return
		}
		cmd := target.Get("dataset").Get("command").String()
		closeModal("nexusCommandModal")
		runCommandPalette(cmd)
	})
	on("securityBtn", "click", func(e js.Value) { openModal("securityPanel"); runSecurityReport() })
	on("securityClose", "click", func(e js.Value) { closeModal("securityPanel") })
	on("urlCheckerHeaderBtn", "click", func(e js.Value) { openModal("urlCheckerModal") })
	on("urlCheckerClose", "click", func(e js.Value) { closeModal("urlCheckerModal") })
	on("urlCheckerRun", "click", func(e js.Value) { checkURL() })
	on("urlCheckerClear", "click", func(e js.Value) {
		setVal("urlCheckerInput", "")
		setHTML("urlCheckerSummary", "")
		setHTML("urlCheckerParsed", "")
		setHTML("urlCheckerResults", "")
		setHidden("urlCheckerRisk", true)
	})
	on("gb", "click", func(e js.Value) { openGame("#nexus-game-target") })
	on("drb", "click", func(e js.Value) { openModal("dm"); initDrawingCanvas() })
	on("dxx", "click", func(e js.Value) { closeModal("dm") })
	on("cx", "click", func(e js.Value) { closeModal("dm") })
	on("gx", "click", func(e js.Value) { closeModal("gm") })
	on("nxAssistantTab", "click", func(e js.Value) {
		assistantOpen = !assistantOpen
		setHidden("nxDockAssistant", !assistantOpen)
		setAttr("nxAssistantTab", "aria-expanded", fmt.Sprint(assistantOpen))
		if assistantOpen {
			focus("nxAssistantInput")
		}
	})
	on("newsTab", "click", func(e js.Value) {
		newsOpen = !newsOpen
		setHidden("newsPanel", !newsOpen)
		setAttr("newsTab", "aria-expanded", fmt.Sprint(newsOpen))
		if newsOpen {
			refreshNewsDate()
		}
	})
	on("newsClose", "click", func(e js.Value) {
		newsOpen = false
		setHidden("newsPanel", true)
		setAttr("newsTab", "aria-expanded", "false")
	})
	// Header actions with Go-based controllers.
	on("codeBridgeHeaderBtn", "click", func(e js.Value) { openModal("codeBridgeModal") })
	on("codeBridgeClose", "click", func(e js.Value) { closeModal("codeBridgeModal") })
	on("nexusBoardBtn", "click", func(e js.Value) { openBoard() })
	on("nexusBoardClose", "click", func(e js.Value) { closeModal("nexusBoardModal") })
	on("nexusSleepBtn", "click", func(e js.Value) { openModal("nexusSleepModal") })
	on("nexusSleepClose", "click", func(e js.Value) { closeModal("nexusSleepModal") })
	on("nexusSleepCancel", "click", func(e js.Value) { closeModal("nexusSleepModal") })
	on("nexusDevBtn", "click", func(e js.Value) { openModal("nexusDevModal") })
	on("nexusDevClose", "click", func(e js.Value) { closeModal("nexusDevModal") })
	on("nexusDevClose2", "click", func(e js.Value) { closeModal("nexusDevModal") })
}
func mobileLayout() bool         { return win.Get("innerWidth").Int() <= 760 }
func hasClassBody(c string) bool { return doc.Get("body").Get("classList").Call("contains", c).Bool() }
func setBodyClass(c string, v bool) {
	if v {
		doc.Get("body").Get("classList").Call("add", c)
	} else {
		doc.Get("body").Get("classList").Call("remove", c)
	}
}
func initCommonKeys() {
	onDoc("keydown", func(e js.Value) {
		key := strings.ToLower(e.Get("key").String())
		ctrl := e.Get("ctrlKey").Bool() || e.Get("metaKey").Bool()
		if ctrl && key == "k" {
			prevent(e)
			openCommandPalette()
		}
		if key == "/" {
			target := e.Get("target")
			tag := strings.ToLower(target.Get("tagName").String())
			if tag != "input" && tag != "textarea" {
				prevent(e)
				focus("q")
			}
		}
		if key == "escape" {
			for _, id := range []string{"nexusCommandModal", "nexusBoardModal", "nexusSleepModal", "nexusDevModal", "codeBridgeModal", "securityPanel", "urlCheckerModal", "dm", "gm", "nxGarbler"} {
				setHidden(id, true)
			}
			setHidden("cp", true)
			setHidden("lp", true)
		}
	})
}

func openCommandPalette() {
	openModal("nexusCommandModal")
	setAttr("commandPaletteBtn", "aria-expanded", "true")
	focus("nexusCommandInput")
	renderCommandPalette()
}
func renderCommandPalette() {
	q := strings.ToLower(strings.TrimSpace(val("nexusCommandInput")))
	items := []struct{ Key, Name, Desc string }{{"home", "ホーム", "先頭へ戻る"}, {"weather", "天気", "都道府県の天気"}, {"memo", "メモ", "メモの作成と編集"}, {"todo", "Todo", "日別タスク管理"}, {"calendar", "予定表", "予定の追加と確認"}, {"translate", "翻訳", "文章の翻訳"}, {"timer", "タイマー", "カウントダウン"}, {"stopwatch", "ストップウォッチ", "ラップ計測"}, {"calculator", "電卓", "計算"}, {"code", "CodeBridge", "コード変換・開発"}, {"drawing", "お絵かき", "描画キャンバス"}, {"security", "セキュリティ", "ローカル診断"}, {"backup", "バックアップ", "データの書き出し・復元"}, {"privacy", "プライバシー", "外部通信と画面保護"}, {"board", "掲示板", "ローカル記録"}, {"assistant", "Assistant+", "ローカル操作"}, {"news", "ニュース", "ニュース検索"}, {"developer", "開発者モード", "診断・管理"}}
	h := ""
	n := 0
	for _, it := range items {
		if q != "" && !strings.Contains(strings.ToLower(it.Name+" "+it.Desc+" "+it.Key), q) {
			continue
		}
		n++
		h += fmt.Sprintf(`<li><button type="button" data-command="%s"><b>%s</b><small>%s</small></button></li>`, it.Key, escape(it.Name), escape(it.Desc))
	}
	setHTML("nexusCommandList", h)
	setHidden("nexusCommandEmpty", n > 0)
}
func runCommandPalette(key string) {
	switch key {
	case "home":
		win.Call("scrollTo", map[string]any{"top": 0, "behavior": "smooth"})
	case "weather":
		scroll("weatherCard")
	case "memo":
		scroll("memoCard")
	case "todo":
		scroll("todoCard")
	case "calendar":
		scroll("sls")
	case "translate":
		scroll("trCard")
	case "timer":
		scroll("td")
	case "stopwatch":
		scroll("swdisplay")
	case "calculator":
		scroll("calc")
	case "code":
		openModal("codeBridgeModal")
	case "drawing":
		openModal("dm")
	case "security":
		openModal("securityPanel")
		runSecurityReport()
	case "backup":
		scroll("backupTools")
	case "privacy":
		scroll("privacyTools")
	case "board":
		openBoard()
	case "assistant":
		assistantOpen = true
		setHidden("nxDockAssistant", false)
		focus("nxAssistantInput")
	case "news":
		newsOpen = true
		setHidden("newsPanel", false)
		refreshNewsDate()
	case "developer":
		openModal("nexusDevModal")
	}
}
func refreshSystemMonitor() {
	ls := win.Get("localStorage")
	keys, chars := 0, 0
	if !ls.IsNull() && !ls.IsUndefined() {
		l := ls.Get("length").Int()
		for i := 0; i < l; i++ {
			k := ls.Call("key", i).String()
			v := ls.Call("getItem", k).String()
			keys++
			chars += len(k) + len(v)
		}
	}
	fmtSetText("nexusStorageStat", fmt.Sprintf("%dキー・約%d KiB", keys, (chars*2)/1024))
	fmtSetText("nexusErrorsStat", "Go/WASM実行中（未捕捉エラー数はランタイムに依存）")
	fmtSetText("nexusNetworkStat", map[bool]string{true: "手動更新のみ", false: "自動取得を許可"}[!cfg.AutoNetwork])
	fmtSetText("nexusMemoryStat", "Go/WASMのメモリ値はブラウザから直接取得できません")
}
