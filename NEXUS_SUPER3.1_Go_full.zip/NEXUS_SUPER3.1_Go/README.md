# NEXUS SUPER3.1 — Go / WebAssembly Edition

This project moves the interactive application logic into Go and compiles it to WebAssembly. The existing HTML/CSS are retained as the browser presentation layer. `boot.js` only loads the Go WebAssembly runtime; it does not contain NEXUS feature logic.

## Run

### Windows

Run `run_windows.bat`, or start `NEXUS_SUPER3.1_Go.exe` directly. The executable starts the local server.

### Linux (x86-64)

```sh
./NEXUS_SUPER3.1_Go_linux_amd64
```

### Any platform with Go 1.23+

```sh
go run .
```

Then open `http://127.0.0.1:8080` in a recent Chrome, Edge, Firefox, or Safari browser. Keep the server process running while using NEXUS; press Ctrl+C to stop it.

## Rebuild the browser app

```sh
GOOS=js GOARCH=wasm go build -o web/nexus.wasm ./wasm
```

Then run the server again:

```sh
go run .
```

## Architecture

- `main.go`: Go HTTP launcher. It serves a fixed allow-list of embedded files on localhost.
- `wasm/`: Go implementation of the application behavior, compiled for `js/wasm`.
- `web/index.html`: original NEXUS screen structure and CSS, with the previous inline JavaScript removed.
- `web/wasm_exec.js`: official Go WebAssembly runtime support file for the Go toolchain used to build this package.
- `web/boot.js`: minimal WebAssembly startup loader.
- `web/nexus.wasm`: compiled NEXUS Go application.

## Porting notes

The core controls are implemented in Go/WASM: local settings, bookmark/app groups, search routing, clocks, timer/stopwatch, local BGM and audio-file playback, memo/Todo/calendar, calculator, prefecture weather retrieval, translation API handoff, drawing canvas, garbler, Assistant+ local commands, news links, JSON backup/restore with optional AES-GCM encryption, URL format checks, security report, developer controls, sleep restriction, and board records.

This is a Go/WASM port, not a byte-for-byte behavioral clone of the original. Some complex interactions are reduced: mini-games are a small Go implementation, drawing has a reduced tool set, and CodeBridge conversions are heuristic drafts rather than compiler-grade source translation. Browser-only presentation and platform APIs necessarily remain at the boundary: HTML/CSS render the screen, `wasm_exec.js` provides the official Go runtime, and `boot.js` starts it. The original application JavaScript has been removed from `index.html`; no NEXUS feature logic is retained in JavaScript.

## Privacy and safety

The server binds to `127.0.0.1:8080` by default. Use `-addr` only when you intentionally want to expose the UI on another interface. Backup exports can include personal data. The security report is a local configuration summary, not a device malware scanner. Weather requires a manual request or enabling its auto-network preference.

## Verification

The Go server and Go/WASM package build successfully. The local HTTP smoke test verified `/`, `/nexus.wasm`, `/health`, and the 404 behavior for unknown paths. Browser-level interaction testing should still be done in the target browser/device before production use.
