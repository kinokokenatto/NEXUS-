// NEXUS SUPER3.1 Go launcher.
// All interactive application logic is compiled from ./wasm to Go WebAssembly.
// HTML/CSS remain the browser presentation layer; boot.js is only a WASM loader.
package main

import (
	"embed"
	"flag"
	"fmt"
	"log"
	"net"
	"net/http"
	"path"
	"strings"
)

//go:embed web/*
var webAssets embed.FS

func main() {
	addr := flag.String("addr", "127.0.0.1:8080", "listen address (default: localhost only)")
	flag.Parse()

	allowed := map[string]string{
		"index.html":   "text/html; charset=utf-8",
		"boot.js":      "text/javascript; charset=utf-8",
		"wasm_exec.js": "text/javascript; charset=utf-8",
		"nexus.wasm":   "application/wasm",
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		_, _ = fmt.Fprintln(w, "NEXUS SUPER3.1 Go/WASM is ready")
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		name := strings.TrimPrefix(path.Clean("/"+r.URL.Path), "/")
		if name == "." || name == "" {
			name = "index.html"
		}
		contentType, ok := allowed[name]
		if !ok {
			http.NotFound(w, r)
			return
		}
		data, err := webAssets.ReadFile("web/" + name)
		if err != nil {
			http.NotFound(w, r)
			return
		}

		w.Header().Set("Content-Type", contentType)
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=(), bluetooth=()")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Cross-Origin-Resource-Policy", "same-origin")
		if name == "index.html" {
			w.Header().Set("Cache-Control", "no-store")
			w.Header().Set("Content-Security-Policy", "default-src 'none'; script-src 'self' 'wasm-unsafe-eval'; style-src 'unsafe-inline'; img-src data: blob: file:; media-src data: blob: file:; font-src data:; connect-src 'self' https://api.open-meteo.com https://speed.cloudflare.com; object-src 'none'; base-uri 'none'; form-action 'none'; frame-src blob:; worker-src 'none'; manifest-src 'none'")
		} else {
			w.Header().Set("Cache-Control", "public, max-age=3600")
		}
		if r.Method == http.MethodHead {
			w.Header().Set("Content-Length", fmt.Sprint(len(data)))
			return
		}
		_, _ = w.Write(data)
	})

	// Keep the default listener on loopback unless the user explicitly chooses otherwise.
	if host, _, err := net.SplitHostPort(*addr); err == nil && host != "localhost" && host != "127.0.0.1" && host != "::1" {
		log.Printf("WARNING: NEXUS will listen on %s; this may expose it to your network", host)
	}
	log.Printf("NEXUS SUPER3.1 Go/WASM: http://%s", *addr)
	log.Fatal(http.ListenAndServe(*addr, mux))
}
